<?php
/**
 * MÀN CẤU HÌNH TRONG WP-ADMIN — chỗ khai "ai được làm gì" của trang Nội bộ.
 *
 * Anh Thắng 26/08/2026: *"phần quyền người vào chỗ nào"*. Đây là chỗ đó.
 *
 * 🔴 ĐẶT Ở WP-ADMIN, KHÔNG ĐẶT TRÊN CHÍNH TRANG NỘI BỘ.
 *    Nếu khai quyền ngay trên trang nội bộ thì có một cách tự khoá mình ra ngoài: hạ bậc "Vào
 *    trang" lên Admin trong khi mình không phải Admin, và từ đó không ai mở lại được nữa vì
 *    cái nút mở nằm sau đúng cánh cửa vừa khoá. wp-admin là cửa riêng, không bị khoá bởi chính
 *    bảng này.
 *
 * ⚠️ MÀN NÀY KHÔNG CÓ MỘT DÒNG SCRIPT NÀO — cùng luật với màn quản trị chấm công.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class VHNB_Admin {

	const NONCE = 'vhnb_cfg';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
	}

	public static function menu() {
		add_menu_page(
			'Nội bộ K&H', 'Nội bộ K&H', 'manage_options',
			'vhnb-cau-hinh', array( __CLASS__, 've' ), 'dashicons-groups', 58
		);
	}

	/**
	 * KHỐI "NÚT NÀO HIỆN TRÊN THANH ĐẦU TRANG". Cùng form với phần trên, cùng một nút Lưu.
	 */
	private static function khoi_thanh() {
		if ( ! class_exists( 'VHNB_Thanh' ) ) { return; }
		$ds = VHNB_Thanh::ds_khai();

		echo '<h2>Nút trên thanh đầu trang</h2>';
		if ( ! $ds ) {
			echo '<p>Chưa dò thấy trang nào để bày. Khai ở plugin <b>Cổng K&amp;H</b>.</p>';
			return;
		}
		echo '<p style="max-width:780px">Bỏ tích là nút ấy <b>không hiện trên thanh</b> nữa. '
			. '🔴 <b>Đây không phải phân quyền.</b> Người có quyền vào trang ấy vẫn vào được bằng '
			. 'địa chỉ, và vẫn thấy nó ở <b>Cổng K&amp;H</b> — khối này thuần là dọn cho thanh đỡ '
			. 'dài. Muốn CẤM thì khai ở bảng quyền phía trên, hoặc ở chính plugin của trang ấy.</p>';

		echo '<table class="widefat striped" style="max-width:640px"><thead><tr>'
			. '<th style="width:70px">Hiện</th><th>Trang</th><th>Địa chỉ</th></tr></thead><tbody>';
		foreach ( $ds as $t ) {
			$id = 'th_' . md5( (string) $t['url'] );
			echo '<tr><td>';
			if ( ! empty( $t['laCong'] ) ) {
				/* 🔴 CỔNG KHÔNG ẨN ĐƯỢC. Nó là trang liệt kê mọi app; ẩn nốt nó thì mấy trang
				   vừa ẩn không còn đường nào tới ngoài gõ tay địa chỉ. Ô tích để `disabled` và
				   kèm một ô ẩn gửi giá trị lên, không thì bỏ trống = bị coi là "không tích". */
				echo '<input type="checkbox" checked disabled> '
					. '<input type="hidden" name="thanh[]" value="' . esc_attr( $t['url'] ) . '">';
			} else {
				echo '<input type="checkbox" id="' . esc_attr( $id ) . '" name="thanh[]" value="'
					. esc_attr( $t['url'] ) . '"' . checked( ! empty( $t['hien'] ), true, false ) . '>';
			}
			echo '</td><td><label for="' . esc_attr( $id ) . '">'
				. esc_html( trim( $t['icon'] . ' ' . $t['ten'] ) ) . '</label>'
				. ( ! empty( $t['laCong'] ) ? ' <span class="description">— luôn hiện, là đường tới '
					. 'mọi trang còn lại</span>' : '' )
				. '</td>'
				. '<td class="description"><code>' . esc_html( $t['url'] ) . '</code></td></tr>';
		}
		echo '</tbody></table>';
		echo '<p class="description" style="max-width:780px">⚠️ Trang nào <b>đổi đường dẫn</b> thì '
			. 'nút của nó <b>hiện lại</b> (khoá nhớ theo địa chỉ). Cố ý: thừa một nút thì nhìn thấy '
			. 'ngay và bỏ tích lại, còn mất một nút thì không ai biết để đi tìm.</p>';
	}

	/**
	 * KHỐI "NHẮC CHỖ CHẤM CÔNG". Nằm TRONG cùng cái form với phần trên — cố ý.
	 *
	 * 🔴 KHÔNG LỒNG <form> TRONG <form>. HTML không cho phép và trình duyệt KHÔNG báo lỗi: nó
	 *    lặng lẽ vứt thẻ bên trong rồi gộp mọi ô nhập vào form ngoài. Bộ chấm công đã trả giá
	 *    cho đúng lỗi này ngày 22/08/2026 — bấm Lưu ở khối này thì trình duyệt đòi điền một ô
	 *    `required` tận cuối trang, chẳng liên quan gì. Một form, một nút Lưu.
	 */
	private static function khoi_nhac() {
		if ( ! class_exists( 'VHNB_Nhac' ) ) { return; }
		$c    = VHNB_Nhac::cai();
		$dich = VHNB_Nhac::dich();

		echo '<h2>Nhắc chỗ chấm công</h2>';
		echo '<p style="max-width:780px">Nhân viên cũ quen vào trang này để chấm công. Hai trang '
			. 'dùng <b>chung một mã PIN</b> nên vào nhầm vẫn đăng nhập được — không có câu lỗi nào, '
			. 'và họ đứng tìm một cái nút không có ở đây. Dải này nói chỗ chấm công thật, hiện vài '
			. 'giây ở <b>đáy màn</b> rồi tự đi; không che, không chặn thao tác nào.</p>';

		echo '<table class="form-table"><tbody>';

		echo '<tr><th scope="row">Bật dải nhắc</th><td>'
			. '<label><input type="checkbox" name="nhac_bat" value="1"'
			. checked( ! empty( $c['bat'] ), true, false ) . '> Hiện trên mọi trang Nội bộ</label>'
			. '<p class="description">Người bấm <b>“Đừng hiện nữa”</b> thì máy của họ nhớ, lần sau '
			. 'không thấy nữa. Tắt ô này là im với tất cả.</p></td></tr>';

		echo '<tr><th scope="row"><label for="nhac_giay">Tự đi sau</label></th><td>'
			. '<input id="nhac_giay" name="nhac_giay" type="number" min="' . (int) VHNB_Nhac::GIAY_IT
			. '" max="' . (int) VHNB_Nhac::GIAY_NHIEU . '" style="width:90px" value="'
			. esc_attr( (string) $c['giay'] ) . '"> giây'
			. '<p class="description">Có một vạch rút ngắn dần chạy suốt bấy nhiêu giây, để người ta '
			. 'biết nó sắp tự đi thay vì phải dừng việc đi tìm nút đóng. '
			. 'Bấm phát video thì <b>dừng đếm</b> — không thì dải tự đóng giữa lúc đang xem.</p></td></tr>';

		echo '<tr><th scope="row"><label for="nhac_dich">Địa chỉ trang chấm công</label></th><td>'
			. '<input id="nhac_dich" name="nhac_dich" type="url" class="large-text" value="'
			. esc_attr( (string) $c['dich'] ) . '" placeholder="' . esc_attr( $dich ) . '">'
			. '<p class="description">Để trống là <b>tự hỏi plugin Chấm Công</b> — nên đường dẫn bên '
			. 'ấy đổi thì dải này theo ngay. Chỉ khai tay khi hai plugin nằm trên hai website khác '
			. 'nhau. ' . ( '' === $dich
				? '<b style="color:#b32d2e">Hiện chưa biết dẫn đi đâu — dải sẽ KHÔNG hiện cho tới khi '
					. 'có địa chỉ.</b>'
				: 'Đang dẫn tới <code>' . esc_html( $dich ) . '</code>.' )
			. '</p></td></tr>';

		echo '<tr><th scope="row"><label for="nhac_video">Video hướng dẫn</label></th><td>'
			. '<input id="nhac_video" name="nhac_video" type="url" class="large-text" value="'
			. esc_attr( (string) $c['video'] ) . '" placeholder="để trống = không có video">'
			. '<p class="description">Tải video lên <b>Thư viện Media</b> của WordPress rồi dán địa '
			. 'chỉ vào đây. <b>Đừng nhét video vào plugin</b>: một tệp 4 MB làm mỗi lượt tự cập nhật '
			. 'tải thêm 4 MB, và mỗi bản phát hành phình theo.<br>'
			. 'Địa chỉ kết thúc bằng <code>.mp4</code>/<code>.webm</code> thì phát ngay trong dải '
			. '(<b>không tự tải</b> — bấm mới tải, vì ở cơ sở người ta dùng 3G). Địa chỉ khác '
			. '(YouTube, Drive) thì hiện thành một đường dẫn mở tab mới.</p></td></tr>';

		echo '<tr><th scope="row"><label for="nhac_han">Tự tắt sau ngày</label></th><td>'
			. '<input id="nhac_han" name="nhac_han" type="date" value="'
			. esc_attr( (string) $c['han'] ) . '">'
			. '<p class="description">🔴 <b>Nên đặt.</b> Đây là thông báo <b>chuyển đổi</b>, không phải '
			. 'nội dung thường trực. Không có hạn thì sang năm nó vẫn nằm đó nhắc một việc không còn '
			. 'ai nhầm nữa — và lúc ấy nó thành thứ mọi người đã quen bỏ qua, nên lần sau có thông báo '
			. 'thật cũng không ai đọc. Để trống = không bao giờ tự tắt.</p></td></tr>';

		echo '<tr><th scope="row"><label for="nhac_tieu">Dòng đậm</label></th><td>'
			. '<input id="nhac_tieu" name="nhac_tieu" class="large-text" maxlength="120" value="'
			. esc_attr( (string) $c['tieu'] ) . '"></td></tr>';

		echo '<tr><th scope="row"><label for="nhac_chu">Dòng giải thích</label></th><td>'
			. '<textarea id="nhac_chu" name="nhac_chu" class="large-text" rows="3">'
			. esc_textarea( (string) $c['chu'] ) . '</textarea>'
			. '<p class="description">Chữ thuần, không thẻ HTML.</p></td></tr>';

		echo '</tbody></table>';

		if ( ! empty( $c['bat'] ) && ! VHNB_Nhac::con_han() ) {
			echo '<div class="notice notice-warning inline"><p><b>Dải đang bật nhưng đã quá hạn '
				. esc_html( (string) $c['han'] ) . '</b> nên không hiện nữa. Đổi ngày hoặc bỏ tích '
				. 'cho gọn.</p></div>';
		}
	}

	public static function ve() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Không đủ quyền.' ); }
		$bao = '';

		if ( isset( $_POST['vhnb_luu'] ) ) {
			check_admin_referer( self::NONCE );
			$map = array();
			foreach ( VHNB_Quyen::VIEC as $k => $_v ) {
				$map[ $k ] = isset( $_POST['q'][ $k ] ) ? sanitize_text_field( wp_unslash( $_POST['q'][ $k ] ) ) : '';
			}
			VHNB_Quyen::dat( $map );
			/* Đường dẫn trang: để trống thì `VHNB_Trang::slug()` tự về mặc định, nên KHÔNG cần
			   chặn rỗng ở đây — chặn hai nơi là hai luật, và hai luật thì lệch. */
			update_option( 'vhnb_slug', isset( $_POST['slug'] )
				? sanitize_title( wp_unslash( $_POST['slug'] ) ) : '' );

			/* Nút nào hiện trên thanh đầu trang. Biểu mẫu gửi lên danh sách được HIỆN (ô tích),
			   nên cái bị ẩn = tất cả trừ cái được tích. Đọc ngược lại (gửi cái bị ẩn) thì trang
			   mới mọc ra sau này mặc định bị ẩn — mà mặc định phải là HIỆN. */
			if ( class_exists( 'VHNB_Thanh' ) && class_exists( 'VHNB_Trang' ) ) {
				$hien = isset( $_POST['thanh'] ) ? (array) wp_unslash( $_POST['thanh'] ) : array();
				$hien = array_map( 'strval', $hien );
				$an   = array();
				foreach ( VHNB_Trang::ds_trang_khac() as $tr ) {
					if ( ! in_array( (string) $tr['url'], $hien, true ) ) { $an[] = (string) $tr['url']; }
				}
				VHNB_Thanh::dat_an( $an );
			}

			/* Dải nhắc chỗ chấm công. Ô tích KHÔNG gửi gì khi không tích, nên đọc bằng `isset`
			   chứ không bằng giá trị — đọc giá trị thì bỏ tích xong bấm Lưu là nó vẫn bật. */
			if ( class_exists( 'VHNB_Nhac' ) ) {
				VHNB_Nhac::dat( array(
					'bat'   => isset( $_POST['nhac_bat'] ),
					'giay'  => isset( $_POST['nhac_giay'] ) ? (int) $_POST['nhac_giay'] : 0,
					'dich'  => isset( $_POST['nhac_dich'] ) ? wp_unslash( $_POST['nhac_dich'] ) : '',
					'video' => isset( $_POST['nhac_video'] ) ? wp_unslash( $_POST['nhac_video'] ) : '',
					'tieu'  => isset( $_POST['nhac_tieu'] ) ? wp_unslash( $_POST['nhac_tieu'] ) : '',
					'chu'   => isset( $_POST['nhac_chu'] ) ? wp_unslash( $_POST['nhac_chu'] ) : '',
					'han'   => isset( $_POST['nhac_han'] ) ? wp_unslash( $_POST['nhac_han'] ) : '',
				) );
			}
			update_option( 'vhnb_rw', 1 );   // đổi đường dẫn -> phải ghi lại bộ luật đường

			/* Trang chủ + phần công khai. Anh Thắng 30/08/2026: *"cho trang này là trang chủ
			   luôn, nhân viên đăng nhập vào sẽ thấy trang này"* và *"thấy trang chủ, nhưng
			   thông tin chung… như hướng dẫn sử dụng chẳng hạn"*. */
			$lam_tc = empty( $_POST['trang_chu'] ) ? 0 : 1;
			update_option( 'vhnb_trang_chu', $lam_tc );
			/* 🔴 MỘT TRANG CHỦ CHỈ CÓ MỘT CHỦ.
			   Plugin Trang cổng cũng có ô "dùng làm trang chủ", cũng móc `template_redirect`,
			   cũng kiểm `is_front_page()`. Bật cả hai thì cái nào chạy trước thắng — mà thứ tự
			   ấy do thứ tự nạp plugin quyết định, tức là do TÊN THƯ MỤC. Không ai đoán được, và
			   đổi tên thư mục một ngày nào đó là trang chủ đổi theo mà chẳng ai hiểu vì sao.
			   Nên: bật cái này thì TẮT cái kia, và nói ra ngay. */
			if ( $lam_tc && get_option( 'vhtc_trang_chu' ) ) {
				update_option( 'vhtc_trang_chu', 0 );
				$bao_them = ' Đã tắt "dùng làm trang chủ" của <b>Trang cổng</b> — một trang chủ '
					. 'chỉ có một chủ. Trang cổng vẫn mở được ở đường dẫn riêng của nó.';
			}
			update_option( 'vhnb_loi_chao', isset( $_POST['loi_chao'] )
				? sanitize_text_field( wp_unslash( $_POST['loi_chao'] ) ) : '' );
			/* 🔴 HƯỚNG DẪN LÀ VĂN BẢN THUẦN, KHÔNG PHẢI HTML. Ô này in ra TRANG CHỦ CÔNG KHAI —
			   ai trên internet cũng đọc được. `wp_kses_post` vẫn cho qua khá nhiều thẻ; ở đây
			   không cần thẻ nào cả, nên cắt sạch bằng `sanitize_textarea_field` và để phần vẽ
			   tự bẻ dòng thành gạch đầu dòng. */
			update_option( 'vhnb_huong_dan', isset( $_POST['huong_dan'] )
				? sanitize_textarea_field( wp_unslash( $_POST['huong_dan'] ) ) : '' );
			$bao = 'Đã lưu.';
			if ( isset( $bao_them ) ) { $bao .= $bao_them; }
		}

		$cf = VHNB_Quyen::cai_dat();
		echo '<div class="wrap"><h1>Nội bộ K&amp;H</h1>';

		/* ═══════════════════════════════════════════════════════════════════════════════════
		 * BẢN ĐANG CHẠY — in ra ngay đầu màn, và đây KHÔNG phải trang trí.
		 *
		 * 🔴 17/09/2026: cài bản 1.21.0 lên hosting xong mà khối mới không hiện, và không có
		 *    cách nào biết vì sao — tệp trong .zip thì đúng, nên chỉ còn ba khả năng (chưa bấm
		 *    Thay thế, trình duyệt giữ trang cũ, hoặc OPcache của hosting còn giữ mã cũ) và cả
		 *    ba nhìn từ màn hình giống hệt nhau. Mất một vòng hỏi đi hỏi lại chỉ để biết cái
		 *    đang chạy là bản nào.
		 *
		 *    Một dòng số bản đọc từ CHÍNH MÃ ĐANG CHẠY trả lời câu đó bằng mắt. Nó khác hẳn số
		 *    ở màn Plugins: màn kia đọc phần chú thích đầu tệp, còn dòng này đọc hằng mà PHP
		 *    thật sự đã nạp — lệch nhau là biết ngay OPcache đang giữ mã cũ.
		 * ═══════════════════════════════════════════════════════════════════════════════════ */
		$co_nhac = class_exists( 'VHNB_Nhac' );
		echo '<p style="color:var(--chu-mo,#646970)">Bản đang chạy: <code>'
			. esc_html( defined( 'VHNB_VERSION' ) ? VHNB_VERSION : '?' ) . '</code>'
			. ' · khối <b>Nhắc chỗ chấm công</b>: '
			. ( $co_nhac ? 'có' : '<b style="color:#b32d2e">CHƯA CÓ</b>' ) . '</p>';
		if ( ! $co_nhac ) {
			echo '<div class="notice notice-warning"><p><b>Mã đang chạy chưa có khối Nhắc chỗ '
				. 'chấm công.</b> Bản cài có thể chưa thay xong, hoặc hosting còn giữ mã cũ trong '
				. 'bộ nhớ đệm (OPcache). Thử theo thứ tự: tải lại trang này bằng '
				. '<kbd>Ctrl+F5</kbd> → vào <b>Plugin</b> tắt rồi bật lại <b>Nội Bộ K&amp;H</b> → '
				. 'nếu vẫn vậy thì cài lại bản .zip một lượt nữa.</p></div>';
		}
		if ( '' !== $bao ) {
			/* Lời báo có thể kèm một chữ <b> (tên plugin vừa bị tắt) — cho đúng thẻ ấy, không
			   mở cửa cho thẻ nào khác. */
			echo '<div class="notice notice-success"><p>'
				. wp_kses( $bao, array( 'b' => array() ) ) . '</p></div>';
		}

		echo '<p>Trang nội bộ dùng chung mã PIN với hệ chấm công, và dùng chung <b>thang năm bậc</b> '
			. 'của hệ đó: Nhân viên → Cửa hàng trưởng → Quản lý → Kế toán → Admin. '
			. 'Mỗi việc dưới đây khai <b>bậc thấp nhất</b> được làm; bậc trên luôn làm được việc của bậc dưới.</p>';

		if ( ! class_exists( 'VHCC_Vai' ) ) {
			echo '<div class="notice notice-warning"><p><b>Chưa cài plugin Chấm Công.</b> '
				. 'Không có bộ đo bậc nên các chốt dưới đây tạm thời <b>cho qua hết</b> — '
				. 'khai gì cũng chưa có tác dụng cho tới khi cài plugin ấy.</p></div>';
		}

		echo '<form method="post">';
		wp_nonce_field( self::NONCE );
		/* 🔴 NÓI THẲNG RA LUẬT "AI VÀO ĐƯỢC" — nó KHÔNG có ô nào ở đây, và người quản trị đi tìm
		   một cái ô không tồn tại thì sẽ tưởng mình khai thiếu. Anh Thắng 30/08/2026: *"trang nội
		   bộ là chung công ty nên ai cũng vào được hết, có mật khẩu là vào, đó là lý do anh đặt
		   trang chủ mà"*. */
		echo '<p style="max-width:760px;background:#f0f9ff;border-left:4px solid #0ea5e9;'
			. 'padding:10px 14px;margin:0 0 14px">'
			. '<b>Vào trang thì ai có PIN cũng vào được</b> — đây là trang chung của công ty, '
			. 'không khoá theo vai. Mấy ô dưới đây chỉ quyết định ai được <i>làm gì</i> khi đã vào. '
			. 'Cần chặn riêng một người thì mở <b>Quản lý nhân sự</b> bên trang chấm công, khoá '
			. 'đúng người đó.</p>';
		echo '<table class="form-table"><tbody>';
		foreach ( VHNB_Quyen::VIEC as $k => $v ) {
			echo '<tr><th scope="row"><label for="q_' . esc_attr( $k ) . '">'
				. esc_html( $v['nhan'] ) . '</label></th><td>'
				. '<select id="q_' . esc_attr( $k ) . '" name="q[' . esc_attr( $k ) . ']">';
			foreach ( VHNB_Quyen::BAC_DS as $ma => $ten ) {
				echo '<option value="' . esc_attr( $ma ) . '"' . selected( $ma, $cf[ $k ], false ) . '>'
					. esc_html( $ten ) . ' trở lên</option>';
			}
			echo '</select>';
			if ( $v['md'] !== $cf[ $k ] ) {
				/* Nói ra chỗ đã khác mặc định. Sáu tháng sau không ai nhớ mình đã đổi gì, và
				   "vì sao người này không đăng được bài" bắt đầu từ đúng câu hỏi ấy. */
				echo ' <span style="color:#b45309">— đã đổi khác mặc định ('
					. esc_html( VHNB_Quyen::BAC_DS[ $v['md'] ] ) . ')</span>';
			}
			echo '</td></tr>';
		}
		echo '<tr><th scope="row"><label for="slug">Đường dẫn trang</label></th><td>'
			. '<code>' . esc_html( home_url( '/' ) ) . '</code>'
			. '<input id="slug" name="slug" value="' . esc_attr( (string) get_option( 'vhnb_slug' ) ) . '" '
			. 'placeholder="noi-bo" style="width:180px"> <code>/</code>'
			. '<p class="description">Để trống = <code>noi-bo</code>. Đổi xong WordPress tự ghi lại bộ luật đường.</p>'
			. '</td></tr>';
		if ( ! VHNB_Trang::lam_trang_chu() && get_option( 'vhtc_trang_chu' ) ) {
			echo '<div class="notice notice-info inline" style="margin:12px 0"><p>'
				. '<b>Trang cổng</b> đang giữ trang chủ. Tích ô dưới đây là Nội bộ nhận trang chủ '
				. 'và Trang cổng tự nhường — không phải vào bên kia tắt tay.</p></div>';
		}
		echo '<tr><th scope="row">Dùng làm trang chủ</th><td>'
			. '<label><input type="checkbox" name="trang_chu" value="1"'
			. checked( VHNB_Trang::lam_trang_chu(), true, false ) . '> Vào '
			. esc_html( home_url( '/' ) ) . ' là ra thẳng trang Nội bộ</label>'
			. '<p class="description">Người <b>chưa đăng nhập</b> thấy phần công khai: lời chào, '
			. 'hướng dẫn sử dụng và nút đăng nhập — <b>không</b> thấy bài đăng, nhóm hay tên ai. '
			. 'Đăng nhập rồi mới ra bảng tin.<br>'
			/* Câu này để anh Thắng khỏi sợ bật rồi không lùi được — nỗi sợ đó làm người ta không
			   dám bấm, rồi tính năng nằm đó không ai dùng. */
			. '<b>Bật nhầm không sao:</b> wp-admin không bị ảnh hưởng, vào lại đây bỏ tích là xong. '
			. 'Đường dẫn <code>/' . esc_html( VHNB_Trang::slug() ) . '</code> vẫn dùng được như cũ.</p>'
			. '</td></tr>';

		echo '<tr><th scope="row"><label for="loi_chao">Lời chào</label></th><td>'
			. '<input id="loi_chao" name="loi_chao" class="large-text" value="'
			. esc_attr( (string) get_option( 'vhnb_loi_chao', '' ) ) . '" placeholder="'
			. esc_attr( VHNB_Trang::loi_chao() ) . '">'
			. '<p class="description">Một câu dưới tiêu đề ở phần công khai. Để trống = dùng câu mặc định.</p>'
			. '</td></tr>';

		$hd_dang = get_option( 'vhnb_huong_dan', null );
		echo '<tr><th scope="row"><label for="huong_dan">Hướng dẫn sử dụng</label></th><td>'
			. '<textarea id="huong_dan" name="huong_dan" class="large-text" rows="7">'
			. esc_textarea( null === $hd_dang ? VHNB_Trang::HD_MAC_DINH : (string) $hd_dang )
			. '</textarea>'
			. '<p class="description"><b>Mỗi dòng là một gạch đầu dòng</b> trên trang. '
			. 'Chỉ chữ thường, không dùng thẻ HTML — khối này hiện trên trang chủ công khai. '
			. 'Xoá hết rồi lưu = bỏ hẳn khối hướng dẫn.</p>'
			. '</td></tr>';

		echo '</tbody></table>';

		self::khoi_thanh();
		self::khoi_nhac();

		submit_button( 'Lưu', 'primary', 'vhnb_luu' );
		echo '</form>';

		echo '<h2>Thông báo</h2>';
		echo '<p>Chuông ở đầu trang nội bộ nhận tin từ <b>chính trang này</b> (ai bình luận / thả tim '
			. 'bài của bạn, ai mời bạn vào nhóm, có bài mới trong nhóm bạn ở) và từ <b>plugin khác '
			. 'đẩy sang</b> — chấm công, chi phí. Tin giữ ' . (int) VHNB_Bao::NGAY_GIU . ' ngày rồi tự dọn.</p>';
		echo '</div>';
	}
}
