<?php
/**
 * ĐẨY NGƯỜI TỪ SỔ NHÂN SỰ SANG HỆ VẬN HÀNH CHI PHÍ.
 *
 * =================================================================================================
 * Anh Thắng 28/08/2026: *"bên quản lý nhân sự chưa cho đẩy nhân sự sang vận hành chi phí"*, rồi
 * *"Đồng bộ nhân sự với hệ thống vận hành chi phí luôn nhé em"*.
 *
 * Bảng "Ai vào được trang nào" đã có bốn cột — Quản trị chấm công · Trạm · Nội bộ · Ghế massage —
 * mà thiếu đúng cột chi phí. Nên bên ấy vẫn phải khai tay từng người ở màn 🔐 Người dùng & Phân
 * quyền: gõ lại tên, gõ lại PIN, chọn lại cơ sở. Hai sổ chép tay là hai sổ lệch nhau.
 *
 * =================================================================================================
 * 🔴 KHÁC HỆ GHẾ Ở MỘT ĐIỂM CỐT TỬ: SỔ BÊN CHI PHÍ CÓ NGƯỜI THẬT ĐANG DÙNG.
 * =================================================================================================
 * Hệ ghế có một sổ riêng do chính mình dựng ra. Còn `CH_NguoiDung` bên chi phí là sổ ĐANG CHẠY —
 * ảnh anh gửi có Admin, hai Kế toán, Quản lý, và hai chục nhân viên cơ sở, mỗi người một PIN mà
 * họ đang gõ hằng ngày. Nên:
 *
 * ⚠️ CHỈ THÊM VÀ SỬA HÀNG CỦA NGƯỜI ĐƯỢC ĐẨY. Không đụng một hàng nào khác, không sắp xếp lại,
 *    không dọn "cho gọn". Ghi đè cả sổ là xoá sạch PIN của những người bên ấy tự khai — và họ
 *    chỉ phát hiện ra lúc đứng gõ PIN vào sáng hôm sau.
 *
 * ⚠️ GIỮ NGUYÊN NHỮNG CỘT BÊN ẤY TỰ KHAI: TK Có · Mã đối tượng · Đơn vị · Xem đơn vị. Đó là
 *    thông tin KẾ TOÁN, sổ nhân sự không biết và không được đoán. Đẩy mà xoá chúng là kế toán
 *    mất bảng khai của mình mà không ai báo.
 *
 * ⚠️ KHOÁ THEO MÃ NV, KHÔNG THEO TÊN. Sổ bên chi phí khoá theo tên, nhưng 400 nhân sự thì trùng
 *    tên là chuyện có thật (bảng nhân sự đang có 14 hồ sơ trùng tên). Nên giữ mã NV ở một sổ
 *    riêng bên này — đó là sợi dây duy nhất nối một hàng bên ấy về đúng một người.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class VHCC_DayChiPhi {

	/** Tên cột trên bảng "Ai vào được trang nào". */
	const COT = 'chi_phi';

	/** Sổ ghi mã NV của những người đã đẩy: [ maNV => tên đã ghi sang ]. */
	const O_DA_DAY = 'vhcc_day_chi_phi';

	/**
	 * 🔴 BẬC ADMIN, cùng bậc với đẩy sang hệ ghế và vì cùng một lý do: màn chi phí có ngăn TIỀN
	 *    (duyệt chi, quyết toán), và PIN đẩy sang là PIN chấm công dùng chung. Đẩy nhầm một
	 *    người là mở cửa buồng tiền cho họ.
	 */
	const QUYEN = 'he_thong';

	/** Vị trí các cột trong `CH_NguoiDung` — xem `VHCP_Cfg::headers()`. */
	const C_TEN = 0;
	const C_PIN = 1;
	const C_VAI = 2;
	const C_COSO = 3;
	const C_BO_PHAN = 6;
	/* Ô Mã NV — thêm bên chi phí 13/09/2026 (bản 1.155.0). Đây là sợi dây nối một hàng bên ấy
	   về đúng một người bên này, và nó chính là thứ cho phép một PIN vào được cả hai trang.
	   Đẩy mà bỏ trống ô này là hai bên lại phải nhận nhau bằng TÊN — đúng chỗ vốn hay lệch. */
	const C_MA_NV = 9;
	/** Số ô của một hàng `CH_NguoiDung`: ten·pin·vai·coso·tkCo·maDt·boPhan·donVi·xemDonVi·maNv */
	const SO_O = 10;

	/* ====================================================================== hỏi trạng thái */

	/**
	 * Có plugin chi phí trên site này không, và nó có đủ hàm để ghi không.
	 *
	 * ⚠️ Dò TỪNG HÀM, không dò mỗi tên lớp: bốn plugin cài độc lập nên bản có thể lệch nhau, và
	 *    gọi một hàm không tồn tại là Fatal — trắng cả trang, không phải một ô hỏng.
	 */
	public static function co_he_chi_phi() {
		return class_exists( 'VHCP_Cfg' )
			&& method_exists( 'VHCP_Cfg', 'read' )
			&& method_exists( 'VHCP_Cfg', 'write' )
			&& defined( 'VHCP_Cfg::USER' );
	}

	/** Sổ mã NV đã đẩy: [ maNV(chữ hoa) => tên đã ghi sang ]. */
	public static function da_day_ds() {
		$x = get_option( self::O_DA_DAY );
		return is_array( $x ) ? $x : array();
	}

	public static function da_day( $ma_nv ) {
		$ma = strtoupper( trim( (string) $ma_nv ) );
		if ( '' === $ma ) { return false; }
		$ds = self::da_day_ds();
		return isset( $ds[ $ma ] );
	}

	/** Ô trên bảng: 'mo' nếu đã đẩy, '' nếu chưa. */
	public static function o( $ma_nv ) {
		return self::da_day( $ma_nv ) ? 'mo' : '';
	}

	/* ====================================================================== ánh xạ vai */

	/**
	 * VAI BÊN CHẤM CÔNG -> VAI BÊN CHI PHÍ.
	 *
	 * Đi theo đúng bảng mà chính app chi phí đang dùng cho đăng nhập một lần
	 * (`VHCP_Auth::resolve_sso_user`) — hai đường vào cùng một hệ mà ánh xạ khác nhau thì cùng
	 * một người vào bằng hai cửa lại ra hai quyền.
	 *
	 * ⚠️ CỬA HÀNG TRƯỞNG -> 'Nhân viên', KHÔNG phải 'Quản lý'. Bên chi phí, 'Quản lý' duyệt được
	 *    chi của mọi cơ sở. Cửa hàng trưởng là người ĐỀ NGHỊ chi, không phải người duyệt.
	 */
	public static function vai_chi_phi( $vai_cc ) {
		$ma = class_exists( 'VHCC_Vai' ) && method_exists( 'VHCC_Vai', 'ma' )
			? VHCC_Vai::ma( $vai_cc ) : '';
		$b  = array(
			'ADMIN'   => 'Admin',
			'QUAN_LY' => 'Quản lý',
			'KE_TOAN' => 'Kế toán cá nhân',
		);
		return isset( $b[ $ma ] ) ? $b[ $ma ] : 'Nhân viên';
	}

	/* ====================================================================== dựng hàng */

	/**
	 * Hồ sơ để đẩy: [ ho_ten, pin, vai_cc, coso, bo_phan ]. null nếu không đẩy được.
	 *
	 * ⚠️ PIN Ở `nhan_vien.pin_dang_nhap`, KHÔNG ở `phan_quyen.pin`. Đã tra nhầm một lần
	 *    (28/08/2026, anh Thắng: *"Anh thấy lưu mà bên Posh chưa qua"*) — bảng `phan_quyen` là
	 *    sổ CŨ nạp từ Sheets, còn hồ sơ nhân sự mới là nơi cấp PIN bây giờ.
	 */
	public static function ho_so_day( $ma_nv ) {
		$ma = trim( (string) $ma_nv );
		if ( '' === $ma ) { return null; }
		$hs = VHCC_NhanSu::ho_so( $ma );
		if ( ! $hs ) { return null; }

		$pin = trim( (string) $hs['pin_dang_nhap'] );
		/* Sổ cũ ghi PIN từ Google Sheets nên có hàng ra "1234.0" — rửa đuôi, không thì bên kia
		   nhận một chuỗi không ai gõ được. */
		if ( preg_match( '/^(\d+)\.0*$/', $pin, $m ) ) { $pin = $m[1]; }
		if ( ! preg_match( '/^\d{4,8}$/', $pin ) ) { return null; }

		$ten = trim( (string) $hs['ho_ten'] );
		if ( '' === $ten ) { return null; }

		/* ═════════════════════════════════════════════════════════════════════════════════
		 * 🔴 PHÒNG BAN LẤY TỪ CỘT `phong_ban`, KHÔNG PHẢI `chuc_vu`.
		 *
		 * Bản trước lấy thẳng `chuc_vu` nhét vào ô Bộ phận bên chi phí. Nhưng chức vụ là
		 * *Thu ngân · Ca trưởng · Giám sát · Bảo vệ · Pha chế* — việc người ta LÀM. Còn ô Bộ
		 * phận bên kia nhận đúng bảy tên *Cơ sở · Văn phòng · Kỹ thuật · Marketing · Công tác ·
		 * Setup · Máy tự động*, và nó là thứ quyết định người ấy thấy MẢNG CHI PHÍ nào.
		 *
		 * Hai bộ chỉ trùng đúng một tên ("Kỹ thuật"). Nên đẩy một Thu ngân sang là ô Bộ phận
		 * của họ thành "Thu ngân", rồi chốt phòng ban bên ấy đi tìm loại chi phí thuộc phòng
		 * ban "Thu ngân" — không có cái nào. Màn chi phí của người ấy gần như trắng, và không
		 * có một câu lỗi nào chỉ ra vì sao.
		 *
		 * Anh Thắng chốt luật 13/09/2026: *"quyết định bộ phận do nhân sự quyết định, bên chi
		 * phí chỉ biết bộ phận đó có được quyền không thôi"*. Nên sổ nhân sự nay có cột
		 * `phong_ban` riêng, khai bằng đúng danh mục của bên ấy — xem `VHCC_NhanSu::phong_ban_ds()`.
		 *
		 * ⚠️ CHƯA KHAI THÌ ĐỂ RỖNG, ĐỪNG ĐOÁN. Rỗng bên chi phí nghĩa là "không bó phòng ban",
		 *    tức người ấy thấy mọi mảng — rộng hơn ý muốn, nhưng KHÔNG làm ai mất việc. Đoán
		 *    bừa một phòng ban thì cắt mất đúng mảng họ cần mà chẳng ai biết. Màn soát bên chi
		 *    phí bày riêng những người chưa khai để đi khai nốt.
		 * ═════════════════════════════════════════════════════════════════════════════════ */
		return array(
			'ho_ten'  => $ten,
			'ma_nv'   => trim( (string) $hs['ma_nv'] ),
			'pin'     => $pin,
			'vai_cc'  => (string) $hs['vai_tro'],
			'coso'    => VHCC_NhanSu::chuan_coso( (string) $hs['cua_hang'] ),
			'bo_phan' => method_exists( 'VHCC_NhanSu', 'phong_ban_chuan' )
				? VHCC_NhanSu::phong_ban_chuan( isset( $hs['phong_ban'] ) ? $hs['phong_ban'] : '' )
				: '',
		);
	}

	/* ====================================================================== đẩy / gỡ */

	public static function dat( $u, $ma_nv, $dat ) {
		if ( ! VHCC_Vai::duoc( $u, self::QUYEN ) ) {
			return array( 'ok' => false,
				'error' => 'Đẩy người sang hệ Vận hành chi phí cần vai Admin — màn ấy có ngăn tiền.' );
		}
		/* ⚠️ GÁC `method_exists` CÙNG THÂN HÀM với lời gọi — luật của `tools/test/kiem-goi-cheo.php`.
		   `co_he_chi_phi()` đã kiểm y hệt, nhưng gác ở HÀM KHÁC thì người đọc sau (và bộ soi)
		   không thấy được, mà bốn plugin cài độc lập nên bản có thể lệch nhau bất cứ lúc nào. */
		if ( ! class_exists( 'VHCP_Cfg' ) || ! method_exists( 'VHCP_Cfg', 'read' )
			|| ! method_exists( 'VHCP_Cfg', 'write' ) || ! defined( 'VHCP_Cfg::USER' ) ) {
			return array( 'ok' => false,
				'error' => 'Chưa cài plugin Vận hành chi phí trên site này (hoặc bản bên ấy quá cũ).' );
		}
		$ma  = strtoupper( trim( (string) $ma_nv ) );
		$dat = (string) $dat;
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu Mã NV.' ); }

		$ds_day = self::da_day_ds();
		$rows   = (array) VHCP_Cfg::read( VHCP_Cfg::USER );

		/* --- GỠ --- */
		if ( 'mo' !== $dat ) {
			if ( ! isset( $ds_day[ $ma ] ) ) { return array( 'ok' => true, 'doi' => 0 ); }
			$ten_cu = (string) $ds_day[ $ma ];
			$moi    = array();
			foreach ( $rows as $r ) {
				$r = (array) $r;
				if ( 0 === strcasecmp( trim( (string) ( isset( $r[ self::C_TEN ] ) ? $r[ self::C_TEN ] : '' ) ), $ten_cu ) ) {
					continue;
				}
				$moi[] = $r;
			}
			VHCP_Cfg::write( VHCP_Cfg::USER, $moi );
			unset( $ds_day[ $ma ] );
			update_option( self::O_DA_DAY, $ds_day, false );
			return array( 'ok' => true, 'doi' => 1, 'viec' => 'go' );
		}

		/* --- ĐẨY --- */
		$hs = self::ho_so_day( $ma );
		if ( ! $hs ) {
			return array( 'ok' => false, 'error' => 'Người mang mã ' . $ma . ' chưa có PIN chấm công '
				. '(4–8 số) — cấp PIN cho họ ở màn Hồ sơ & tài khoản rồi đẩy lại.' );
		}
		/* =====================================================================================
		 * 🔴 PIN TRÙNG NGƯỜI KHÁC: SỔ NHÂN SỰ THẮNG, HÀNG BÊN KIA BỊ XOÁ PIN.
		 * =====================================================================================
		 * Anh Thắng 28/08/2026: *"Sau khi đẩy qua sẽ lấy PIN bên nhân sự luôn"* — và khi được
		 * hỏi phải làm gì với hàng bị trùng, anh chốt: xoá PIN của hàng bên kia.
		 *
		 * Vì sao không để hai hàng cùng PIN: cổng đăng nhập bên ấy tra THEO PIN, nên ai gõ vào
		 * cũng rơi vào hàng đứng trước — một trong hai người mất tài khoản mà không có gì báo.
		 * Bản trước chối cả lượt đẩy; anh phải tự đi tìm và sửa từng ca.
		 *
		 * ⚠️ XOÁ PIN, KHÔNG XOÁ HÀNG. Hàng ấy có thể mang TK Có, Mã đối tượng, Đơn vị do kế
		 *    toán khai — xoá hàng là mất bảng khai ấy. Xoá PIN thì người đó tạm thời không đăng
		 *    nhập được, còn mọi thứ khác nguyên vẹn; cấp PIN mới là dùng lại được ngay.
		 *
		 * ⚠️ PHẢI KỂ TÊN NGƯỜI BỊ XOÁ PIN RA. Im lặng là sáng hôm sau có người gõ PIN không vào
		 *    được và không ai biết vì sao — đúng kiểu hỏng mà cả khối này sinh ra để tránh.
		 */
		$ten_cu   = isset( $ds_day[ $ma ] ) ? (string) $ds_day[ $ma ] : $hs['ho_ten'];
		$mat_pin  = array();
		foreach ( $rows as $i_r => $r ) {
			$r = (array) $r;
			$t = trim( (string) ( isset( $r[ self::C_TEN ] ) ? $r[ self::C_TEN ] : '' ) );
			$p = trim( (string) ( isset( $r[ self::C_PIN ] ) ? $r[ self::C_PIN ] : '' ) );
			if ( $p !== $hs['pin'] ) { continue; }
			if ( 0 === strcasecmp( $t, $ten_cu ) || 0 === strcasecmp( $t, $hs['ho_ten'] ) ) { continue; }
			$r[ self::C_PIN ] = '';
			$rows[ $i_r ]     = $r;
			$mat_pin[]        = $t;
		}

		$thay = false;
		foreach ( $rows as $i => $r ) {
			$r = (array) $r;
			$t = trim( (string) ( isset( $r[ self::C_TEN ] ) ? $r[ self::C_TEN ] : '' ) );
			if ( 0 !== strcasecmp( $t, $ten_cu ) && 0 !== strcasecmp( $t, $hs['ho_ten'] ) ) { continue; }
			/* 🔴 SỬA ĐÚNG BỐN Ô, GIỮ NGUYÊN PHẦN CÒN LẠI. TK Có · Mã đối tượng · Đơn vị · Xem
			   đơn vị là bảng khai của KẾ TOÁN — sổ nhân sự không biết và không được đoán. */
			/* Hàng cũ có thể chỉ 9 ô (sổ trước khi có cột Mã NV) — nới cho đủ trước khi ghi ô
			   thứ 10, không thì `$r[9]` đẻ ra một khoá rời và `array_values` lúc lưu xếp lại
			   sai chỗ. */
			$r = array_pad( array_values( $r ), self::SO_O, '' );
			$r[ self::C_TEN ]     = $hs['ho_ten'];
			$r[ self::C_PIN ]     = $hs['pin'];
			$r[ self::C_VAI ]     = self::vai_chi_phi( $hs['vai_cc'] );
			$r[ self::C_COSO ]    = $hs['coso'];
			if ( '' !== $hs['bo_phan'] ) { $r[ self::C_BO_PHAN ] = $hs['bo_phan']; }
			/* ⚠️ MÃ NV GHI ĐÈ LUÔN, không gác "chỉ ghi khi rỗng" như ô Bộ phận. Mã là danh
			   tính, không phải lựa chọn của kế toán: hàng này vừa được nhận ra là của người
			   mang mã ấy, nên mã ấy đúng theo định nghĩa. */
			$r[ self::C_MA_NV ]   = $hs['ma_nv'];
			$rows[ $i ] = $r;
			$thay = true;
			break;
		}
		if ( ! $thay ) {
			/* ⚠️ ĐỘT BIẾN TƯƠNG ĐƯƠNG: hạ `self::SO_O` xuống 9 KHÔNG đổi kết quả — gán `$hang[9]`
			   ngay dưới tự nới mảng, và khoá vẫn liên tục 0..9 nên `array_values` giữ nguyên
			   thứ tự. Vẫn khai đúng số ô vì nó nói ra ý định: hàng này có mười ô, và người sửa
			   sau đọc con số ấy chứ không phải đếm những dòng gán bên dưới. */
			$hang = array_fill( 0, self::SO_O, '' );
			$hang[ self::C_TEN ]     = $hs['ho_ten'];
			$hang[ self::C_PIN ]     = $hs['pin'];
			$hang[ self::C_VAI ]     = self::vai_chi_phi( $hs['vai_cc'] );
			$hang[ self::C_COSO ]    = $hs['coso'];
			$hang[ self::C_BO_PHAN ] = $hs['bo_phan'];
			$hang[ self::C_MA_NV ]   = $hs['ma_nv'];
			$rows[] = $hang;
		}
		VHCP_Cfg::write( VHCP_Cfg::USER, array_values( $rows ) );
		$ds_day[ $ma ] = $hs['ho_ten'];
		update_option( self::O_DA_DAY, $ds_day, false );
		return array( 'ok' => true, 'doi' => 1, 'viec' => $thay ? 'capnhat' : 'them',
			'mat_pin' => $mat_pin );
	}

	/**
	 * BẢN SAO BÊN CHI PHÍ PHẢI THEO BẢN GỐC — gọi sau mỗi lần sửa hồ sơ / đổi vai / chuyển cơ sở.
	 *
	 * 🔴 CỐ Ý KHÔNG KIỂM QUYỀN ĐẨY, y như `VHCC_DayGhe::dong_bo()`. Hàm này không MỞ đường cho
	 *    ai: nó chỉ giữ cho bản sao của một người ĐÃ ĐƯỢC ĐẨY khớp với bản gốc. Bắt nó đòi vai
	 *    Admin thì Cửa hàng trưởng đổi PIN cho nhân viên mình xong, bản sao đứng im — cái chốt
	 *    ấy không bảo vệ được gì mà chỉ đẻ ra lệch.
	 *
	 * ⚠️ HỒ SƠ MẤT PIN THÌ GỠ LUÔN. Xoá PIN của một người thường là để chặn họ đăng nhập; giữ
	 *    bản sao mang PIN cũ là để hở đúng cánh cửa vừa định đóng.
	 */
	/**
	 * Đẩy / gỡ một loạt theo bảng vừa gửi lên: [ maNV => 'mo' | '' ].
	 *
	 * ⚠️ BỎ QUA NGƯỜI KHÔNG ĐỔI. Bảng gửi lên có cả trăm hàng mà thường chỉ vài hàng đổi; ghi
	 *    lại cả sổ chi phí cho mỗi hàng là hàng trăm lượt đọc-ghi cho một cú bấm.
	 */
	public static function luu_nhieu( $u, $bang ) {
		if ( ! VHCC_Vai::duoc( $u, self::QUYEN ) ) {
			return array( 'ok' => false, 'doi' => 0,
				'error' => 'Đẩy người sang hệ Vận hành chi phí cần vai Admin.' );
		}
		$doi     = 0;
		$loi     = array();
		$mat_pin = array();
		foreach ( (array) $bang as $ma => $dat ) {
			$ma  = trim( (string) $ma );
			$dat = (string) $dat;
			if ( '' === $ma ) { continue; }
			if ( self::o( $ma ) === ( 'mo' === $dat ? 'mo' : '' ) ) { continue; }
			$kq = self::dat( $u, $ma, $dat );
			if ( empty( $kq['ok'] ) ) { $loi[] = $kq['error']; continue; }
			$doi += (int) ( isset( $kq['doi'] ) ? $kq['doi'] : 0 );
			foreach ( (array) ( isset( $kq['mat_pin'] ) ? $kq['mat_pin'] : array() ) as $t_mp ) {
				$mat_pin[ $t_mp ] = true;
			}
		}
		return array( 'ok' => true, 'doi' => $doi, 'loi' => $loi,
			'mat_pin' => array_keys( $mat_pin ) );
	}

	public static function dong_bo( $ma_nv ) {
		$ma = strtoupper( trim( (string) $ma_nv ) );
		if ( '' === $ma || ! self::da_day( $ma ) || ! self::co_he_chi_phi() ) {
			return array( 'ok' => true, 'doi' => 0 );
		}
		$gia_admin = array( 'name' => 'dong_bo', 'role' => 'Admin' );
		$hs = self::ho_so_day( $ma );
		return self::dat( $gia_admin, $ma, $hs ? 'mo' : '' );
	}
}
