<?php
/**
 * NHÂN SỰ: hồ sơ · cơ sở · bộ phận — đọc/ghi trên MySQL.
 *
 * =============================================================================================
 * QUYỀN CHIA HAI BẬC, VÀ ĐỪNG GỘP LẠI
 * =============================================================================================
 * Anh Thắng 07/08/2026: *"quyền quản lý nhân viên cửa hàng anh sẽ bàn giao cho cửa đó luôn"*, rồi
 * *"chọn cht phân quyền theo mức"*. Nên có ĐÚNG hai cửa, và ranh giới không phải cho gọn:
 *
 *   `co_sua_ho_so`   Admin · Quản lý · Cửa hàng trưởng
 *       Việc HÀNG NGÀY trong phạm vi cửa hàng mình: sửa SĐT, địa chỉ, chức vụ, nhiệm vụ, trạng
 *       thái làm việc của người ĐANG ở cửa hàng đó.
 *
 *   `co_quan_tri_nv` Admin · Quản lý
 *       Việc ra NGOÀI phạm vi một cửa hàng:
 *         · TẠO hồ sơ mới      — Mã NV dùng chung CẢ CHUỖI, cấp trùng là gộp công hai người;
 *         · ĐỔI cửa hàng       — chuyển người giữa hai cửa hàng là chuyển cả công và lương;
 *         · XOÁ hồ sơ, mã song song, nhập hàng loạt, duyệt yêu cầu.
 *
 *   `co_xem_luong`   Admin · Quản lý
 *       Ô Lương cơ bản + số tài khoản + ngân hàng. Cửa hàng trưởng KHÔNG thấy — họ sửa hồ sơ
 *       người của mình được, nhưng lương thì không.
 *
 * ⚠️ Cửa hàng trưởng sửa được hồ sơ KHÔNG có nghĩa là sửa được của bất kỳ ai: còn phải qua
 *    `co_quyen_coso`. Thiếu chốt đó thì một cửa hàng trưởng sửa hồ sơ người cửa hàng khác.
 * ⚠️ Vai trò NHÂN VIÊN không xem được hồ sơ ai, kể cả cửa hàng ghi trong dòng phân quyền của họ —
 *    cửa hàng đó chỉ để biết chấm công online ghi vào đâu, KHÔNG phải quyền xem.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class VHCC_NhanSu {

	const R_ADMIN   = 'ADMIN';
	const R_QUAN_LY = 'QUAN_LY';
	const R_CHT     = 'CUA_HANG_TRUONG';
	const R_NV      = 'NHAN_VIEN';
	const R_KE_TOAN = 'KE_TOAN';

	const LOI_QT = 'Việc này chỉ Admin / Quản lý làm được (ảnh hưởng ngoài phạm vi cửa hàng).';

	/** Ô chỉ Admin/Quản lý được thấy và sửa. */
	const O_LUONG = array( 'luong_co_ban', 'so_tai_khoan', 'ngan_hang' );

	/**
	 * ⚠️ CÒN ĐÂY CHỈ ĐỂ MÃ CŨ KHÔNG GÃY. Đừng dùng để phân quyền — dùng `VHCC_Vai::cua()`.
	 *
	 * 🔴 Bản cũ của hàm này là `strtoupper( $u['role'] )` rồi so với 'QUAN_LY' / 'KE_TOAN'.
	 *    Thẻ phiên mang vai trò dạng tên tiếng Việt ('Quản lý'), và `strtoupper` của PHP KHÔNG
	 *    nâng được chữ có dấu — 'Quản lý' thành 'QUảN Lý', không khớp gì cả. Kết quả: mọi vai
	 *    trừ 'Admin' đều bị chối ở mọi cửa hỏi qua tệp này, im lặng, suốt nhiều tháng. Đó chính
	 *    là *"xung đột phân quyền"* anh Thắng gặp.
	 */
	private static function vt( $u ) {
		return VHCC_Vai::cua( $u );
	}

	/**
	 * Sửa được HỒ SƠ nhân sự (thông tin cá nhân, hợp đồng, PIN).
	 * Từ 25/08/2026: **Kế toán trở lên**. Trước đây Cửa hàng trưởng cũng sửa được; mô hình anh
	 * Thắng chốt không giao việc hồ sơ cho cửa hàng — họ chấm công, xem công, lên lịch, báo lỗi.
	 * ⚠️ Đây KHÔNG phải quyền sửa LỊCH LÀM VIỆC. Lịch hỏi `lich_lam` (Cửa hàng trưởng trở lên).
	 */
	public static function co_sua_ho_so( $u ) {
		return VHCC_Vai::duoc( $u, 'ho_so' );
	}

	/** Việc ảnh hưởng NGOÀI phạm vi một cửa hàng: tăng cường, khoá bảng, xoá thống kê. Quản lý+. */
	public static function co_quan_tri_nv( $u ) {
		return VHCC_Vai::duoc( $u, 'ngoai_coso' );
	}

	/** Thấy ô Lương cơ bản / số tài khoản / ngân hàng trong hồ sơ. Kế toán+. */
	public static function co_xem_luong( $u ) {
		return VHCC_Vai::duoc( $u, 'xem_luong_hs' );
	}

	/**
	 * Người này có quyền trên cơ sở đó không.
	 *
	 * ⚠️ NHÂN VIÊN trả false LUÔN — trước cả phép so danh sách cơ sở. Cửa hàng ghi trong dòng
	 *    phân quyền của nhân viên chỉ để biết chấm công ghi vào đâu, KHÔNG phải quyền xem.
	 * ⚠️ Quản lý trở lên: MỌI cơ sở, không cần khai — đúng `cong_tat_ca` trong bảng vai.
	 *    Cửa hàng trưởng: chỉ những cơ sở đã khai cho họ.
	 */
	public static function co_quyen_coso( $u, $coso ) {
		if ( ! VHCC_Vai::duoc( $u, 'cong_coso' ) ) { return false; }   // Nhân viên dừng ở đây
		if ( VHCC_Vai::duoc( $u, 'cong_tat_ca' ) ) { return self::qua_bo_mang( $u, $coso ); }
		$coso = self::chuan_coso( $coso );
		if ( '' === $coso ) { return false; }
		foreach ( self::ds_coso_quan_cua( $u ) as $x ) {
			if ( strtolower( $x ) === strtolower( $coso ) ) { return true; }
		}
		return false;
	}

	/** Nhớ trong một lượt. `quen_coso_quan()` xoá — xem cảnh báo ở đó. */
	private static $nho_quan = null;

	/**
	 * XOÁ BỘ NHỚ ĐỆM CƠ SỞ QUẢN LÝ.
	 *
	 * ⚠️ PHẢI GỌI SAU MỌI LƯỢT LƯU CƠ SỞ. Sửa hồ sơ rồi mà cổng còn nhớ danh sách cũ thì trong
	 *    đúng lượt ấy người ta vẫn quản được cơ sở vừa gỡ — và cái màn vẽ ra ngay sau đó nói
	 *    ngược lại với thứ vừa lưu.
	 */
	public static function quen_coso_quan() { self::$nho_quan = array(); }

	/**
	 * CƠ SỞ NGƯỜI ĐANG ĐĂNG NHẬP QUẢN LÝ — đọc từ hồ sơ, không từ thẻ phiên.
	 *
	 * 🔴 ĐÂY LÀ CÁI CỔNG. Anh Thắng 18/09/2026: *"nếu chấm công thì xem quản thân chứ, còn quản
	 *    lý mới xem được cả cửa hàng"*. Trước bản này chỗ này hỏi `ds_coso_cua()` — thẻ phiên
	 *    chở MỌI cơ sở đã tích — nên chấm công ở đâu là quản được ở đó.
	 *
	 * ⚠️ NHỚ TRONG MỘT LƯỢT. Hàm này bị gọi mỗi hàng của mỗi bảng; hỏi cơ sở dữ liệu từng lượt
	 *    là một bảng 200 người thành 200 truy vấn.
	 *
	 * ⚠️ KHÔNG CÓ MÃ NV THÌ LÙI VỀ LỐI CŨ. Tài khoản dựng ở màn Người dùng không gắn mã nên
	 *    không tra được hồ sơ — khoá cứng họ lại là mấy tài khoản quản trị cũ mất sạch quyền
	 *    ngay lúc cài bản này, mà không ai hiểu vì sao.
	 */
	public static function ds_coso_quan_cua( $u ) {
		if ( null === self::$nho_quan ) { self::$nho_quan = array(); }
		$nho = &self::$nho_quan;
		$ma = strtoupper( trim( (string) ( isset( $u['ma_nv'] ) ? $u['ma_nv'] : '' ) ) );
		if ( '' === $ma ) { return self::ds_coso_cua( $u ); }
		if ( isset( $nho[ $ma ] ) ) { return $nho[ $ma ]; }
		$hs = self::ho_so( $ma );
		if ( ! $hs ) { return self::ds_coso_cua( $u ); }
		$nho[ $ma ] = self::ds_coso_quan( $hs );
		return $nho[ $ma ];
	}

	public static function ds_coso_cua( $u ) {
		$ds = array();
		foreach ( explode( ',', isset( $u['coso'] ) ? (string) $u['coso'] : '' ) as $x ) {
			$x = self::chuan_coso( $x );
			if ( '' !== $x ) { $ds[] = $x; }
		}
		return $ds;
	}

	/* ══════════════════════════════════════════════════════════════════════════════════════════
	 * BÓ PHẠM VI THEO MẢNG — "Kế toán KVC chỉ thấy KVC"
	 * ══════════════════════════════════════════════════════════════════════════════════════════
	 * Anh Thắng 13/09/2026, khi tách Kế toán / Vận hành / Kỹ thuật thành hai phòng theo mảng:
	 * *"làm sao phân vai trò cho nv phòng ban đó làm gì"*.
	 *
	 * 🔴 TÁCH PHÒNG THEO MẢNG MÀ KHÔNG BÓ PHẠM VI THÌ CÁI TÊN CHỈ LÀ CÁI NHÃN. Từ bậc Quản lý
	 *    trở lên, `cong_tat_ca` trả `true` cho MỌI cơ sở — không hỏi mảng một câu nào. Nên
	 *    "KVC · Phòng Kế Toán" vẫn xem được công, lương, hồ sơ và số tài khoản của cả mảng MTD.
	 *    Cách duy nhất trước bản này là hạ họ xuống Cửa hàng trưởng rồi tick `coso_ql` — nhưng
	 *    làm vậy họ mất luôn quyền lương và hồ sơ, tức là hết làm được việc kế toán.
	 *
	 * =========================================================================================
	 * 🔴 MẶC ĐỊNH TẮT, VÀ MỌI CHỖ KHÔNG CHẮC ĐỀU MỞ
	 * =========================================================================================
	 * Đây là một cái siết, mà siết nhầm thì người ta mở màn hình ra thấy sổ trống trơn và không
	 * có một dòng nào nói vì sao. Nên:
	 *   · chưa khai phòng nào thì KHÔNG ai bị bó — cài bản này lên không đổi quyền của một ai;
	 *   · người chưa suy ra mảng nào thì KHÔNG bó (bó là khoá sạch, vì không mảng nào khớp);
	 *   · cơ sở chưa ai khai mảng thì CHO QUA — cơ sở mới mở mà chưa kịp khai là cả phòng mất
	 *     đường vào nó, đúng lúc đang cần nhất.
	 * Siết hụt thì thấy được và sửa được; siết oan thì âm thầm chặn việc của người ta.
	 * ══════════════════════════════════════════════════════════════════════════════════════════ */

	/** Khoá lưu: danh sách BỘ PHẬN mà người của nó chỉ thấy cơ sở thuộc mảng của chính họ. */
	const BO_MANG_O = 'vhcc_bo_theo_mang';

	/** Những bộ phận đang bị bó theo mảng. Rỗng = không ai bị bó. */
	public static function bo_mang_ds() {
		$v = get_option( self::BO_MANG_O, null );
		if ( ! is_array( $v ) ) { return array(); }
		$ra = array();
		foreach ( $v as $x ) { $x = trim( (string) $x ); if ( '' !== $x ) { $ra[] = $x; } }
		return $ra;
	}

	/** Bật / tắt bó theo mảng cho một bộ phận. */
	public static function dat_bo_mang( $u, $bo_phan, $bat ) {
		if ( ! VHCC_Vai::duoc( $u, 'ho_so' ) ) {
			return array( 'ok' => false, 'error' => 'Bó phạm vi theo mảng cần vai Kế toán trở lên.' );
		}
		$b = trim( (string) $bo_phan );
		if ( '' === $b || ! in_array( $b, self::ds_bo_phan(), true ) ) {
			return array( 'ok' => false, 'error' => 'Không có phòng ban "' . $b . '".' );
		}
		$ds = self::bo_mang_ds();
		$co = in_array( $b, $ds, true );
		if ( (bool) $bat === $co ) { return array( 'ok' => false, 'error' => 'Chưa đổi gì.' ); }
		if ( $bat ) {
			$ds[] = $b;
		} else {
			$ra = array();
			foreach ( $ds as $x ) { if ( $x !== $b ) { $ra[] = $x; } }
			$ds = $ra;
		}
		update_option( self::BO_MANG_O, array_values( $ds ) );
		self::ghi_nhat_ky_bp( $u, 'bo_theo_mang', $b, $bat ? 'bật' : 'tắt' );
		return array( 'ok' => true, 'bo_phan' => $b, 'bat' => (bool) $bat );
	}

	/**
	 * NGƯỜI NÀY BỊ BÓ VÀO NHỮNG MẢNG NÀO — `null` nghĩa là KHÔNG bó.
	 *
	 * ⚠️ Trả `null` ở mọi chỗ không chắc: chưa khai phòng nào, người không có mã, phòng của họ
	 *    không nằm trong danh sách bó, hoặc họ chưa suy ra mảng nào. Xem khối chú thích ở trên.
	 */
	public static function bo_theo_mang( $u ) {
		$ds_bo = self::bo_mang_ds();
		if ( ! $ds_bo ) { return null; }
		$ma = trim( (string) ( isset( $u['ma_nv'] ) ? $u['ma_nv'] : '' ) );
		if ( '' === $ma ) { return null; }
		if ( ! class_exists( 'VHCC_Cong' ) || ! method_exists( 'VHCC_Cong', 'nhom_cua' ) ) { return null; }
		$n = VHCC_Cong::nhom_cua( $ma );
		if ( '' === $n['boPhan'] || ! in_array( $n['boPhan'], $ds_bo, true ) ) { return null; }
		/* 🔴 KHÔNG SUY RA MẢNG NÀO THÌ ĐỪNG BÓ. Bó một danh sách rỗng là khoá sạch mọi cơ sở —
		   người ấy mở màn hình ra thấy trống trơn và không có dòng nào nói vì sao. */
		return $n['dsMang'] ? $n['dsMang'] : null;
	}

	/** Cơ sở này có nằm trong mảng mà người xem bị bó vào không. */
	private static function qua_bo_mang( $u, $coso ) {
		$bo = self::bo_theo_mang( $u );
		if ( null === $bo ) { return true; }
		$m = self::mang_theo_coso( $coso );
		/* Cơ sở chưa ai khai mảng thì CHO QUA — cơ sở mới mở mà chưa kịp khai là cả phòng mất
		   đường vào nó, đúng lúc đang cần nhất. Thiếu khai thì thấy được ở dải đếm và sửa được. */
		if ( '' === $m ) { return true; }
		return in_array( $m, $bo, true );
	}

	/**
	 * MỘT tên cơ sở, đã chuẩn hoá.
	 *
	 * 🔴 CẮT TẠI DẤU PHẨY ĐẦU TIÊN. Anh Thắng 30/08/2026: *"Nhân viên chỉ có 2 cơ sở, tại sao
	 *    sinh ra 2 hàng chấm công"*. Thẻ phiên của người làm ở hai nơi mang CẢ HAI tên nối
	 *    bằng `', '` — `VHCC_Auth::users_cua()` cố ý nối vậy để `ds_coso_cua()` tách ra được.
	 *    Nhưng hàm này là cửa của những nơi cần MỘT tên, và chúng nhận nguyên chuỗi ghép rồi
	 *    dùng như một cơ sở có thật: bảng chấm công đẻ ra hàng mang tên
	 *    `"POSH_HCM, (PART TIME )_POSH+JP"`, ô xổ cơ sở của màn quản trị (đọc `SELECT DISTINCT
	 *    coso`) hiện luôn cái tên ma ấy, và chọn phải nó thì hàng chính TRỐNG còn toàn bộ công
	 *    thật rơi xuống hàng "cũng làm ở".
	 *
	 * ⚠️ CẮT chứ không phải báo lỗi: dữ liệu cũ trong sổ đã có những tên như vậy rồi, ném lỗi
	 *    ở đây là khoá cửa chấm công của chính những người đang vấp. Cắt thì họ chấm được ngay,
	 *    vào đúng cơ sở chính — còn danh sách ĐỦ cả hai cơ sở là việc của `ds_coso_cua()`.
	 *
	 * ⚠️ Tên cơ sở KHÔNG được chứa dấu phẩy — cả hệ thống đã ngầm định thế từ lâu, vì
	 *    `ds_coso_cua()` và `ds_coso_cua_nv()` đều `explode(',')`. Nên cắt ở đây không làm mất
	 *    một cái tên hợp lệ nào.
	 */
	public static function chuan_coso( $s ) {
		$s = (string) $s;
		$phay = strpos( $s, ',' );
		if ( false !== $phay ) { $s = substr( $s, 0, $phay ); }
		/* 🔴 CẮT KHOẢNG TRẮNG TRƯỚC, GỠ TIỀN TỐ SAU — thứ tự này không đổi được.
		   Làm ngược lại thì `^CS_` không khớp phần tử thứ hai trở đi của chuỗi nối bằng `', '`:
		   `ds_coso_cua()` tách `'CS_A, CS_B'` ra thành `'CS_A'` và `' CS_B'`, cái sau còn
		   nguyên dấu cách đầu nên gỡ hụt tiền tố và ở lại là `'CS_B'`. Trong khi hồ sơ của
		   người bên ấy đã chuẩn hoá thành `'B'`. Hai chuỗi khác nhau -> `co_quyen_coso()` chối,
		   và người làm ở hai nơi CHỈ THẤY MỘT — đúng cái anh Thắng vấp ngày 30/08. Lỗi im
		   lặng: cơ sở đầu tiên vẫn đúng nên nhìn qua tưởng hệ chạy. */
		return trim( preg_replace( '/^CS_/', '', trim( $s ) ) );
	}

	/**
	 * MỌI CƠ SỞ MỘT HỒ SƠ LÀM VIỆC — không phân biệt chính với phụ.
	 *
	 * 🔴 Anh Thắng 31/08/2026: *"việc phân thêm cơ sở phụ nó đang bị lẫn lộn. Thay vì việc cơ sở
	 *    phụ. Thì nhân viên sẽ được tích vào cơ sở nào thì sẽ được có mặt làm việc đầy đủ tại
	 *    chi nhánh đó"*.
	 *
	 *    Trước đó `cua_hang` là cơ sở "thật", còn `coso_phu` chỉ là ghi chú: mọi câu lọc theo cơ
	 *    sở đều hỏi mỗi `cua_hang`, nên người tích cơ sở B làm phụ KHÔNG hiện trong danh sách
	 *    nhân sự của B, cửa hàng trưởng B không thấy họ, và bảng đếm "ai chưa khai lương" của B
	 *    cũng bỏ sót. Tích một ô mà không có mặt ở đâu cả — đúng nghĩa lẫn lộn.
	 *
	 * ⚠️ HAI CỘT VẪN CÒN, vì chúng là hình dạng dữ liệu mà hệ ghế, sổ lương và bản kéo từ sheet
	 *    đang đọc. Nhưng từ đây MỌI câu hỏi "người này làm ở đâu" đi qua hàm này, và nó trả về
	 *    một danh sách BÌNH ĐẲNG. `cua_hang` chỉ còn là "cơ sở đứng đầu danh sách".
	 */
	public static function ds_coso_hs( $hs ) {
		$ds  = array();
		$goc = array(
			isset( $hs['cua_hang'] ) ? (string) $hs['cua_hang'] : '',
			isset( $hs['coso_phu'] ) ? (string) $hs['coso_phu'] : '',
		);
		foreach ( $goc as $chuoi ) {
			foreach ( explode( ',', $chuoi ) as $x ) {
				$x = self::chuan_coso( $x );
				if ( '' === $x ) { continue; }
				$k = self::chu_thuong( $x );
				if ( ! isset( $ds[ $k ] ) ) { $ds[ $k ] = $x; }
			}
		}
		return array_values( $ds );
	}

	/**
	 * CƠ SỞ "CHỈ QUẢN LÝ — KHÔNG CHẤM CÔNG" của một hồ sơ.
	 *
	 * 🔴 Anh Thắng 09/09/2026, trước khối "Cơ sở được chấm công" của mình đang liệt kê SÁU cơ
	 *    sở: *"đối với cửa hàng chỉ quản lý nhân viên không chấm công thì làm sao để loại ra
	 *    khỏi bảng chấm công, nhưng vẫn quản lý được nhân viên cơ sở đó"*.
	 *
	 *    Từ 31/08/2026 một ô tích mang BA nghĩa cùng lúc: nơi người ta LÀM, nơi người ta QUẢN,
	 *    và nơi người ta CHẤM. Ba nghĩa ấy trùng nhau với gần hết mọi người — nhưng không trùng
	 *    với người quản nhiều cơ sở mà chỉ đứng làm ở một hai nơi. Với họ, ô tích cần thiết cho
	 *    vế QUẢN lại kéo theo vế CHẤM: ô xổ cơ sở lúc lưu dài sáu dòng (bấm nhầm là công rơi
	 *    sang cửa hàng khác), và lưới bảng công của cả sáu cơ sở đều mọc một hàng trống tên họ.
	 *
	 * 🔴 CỜ NÀY LÀ **PHỤ THÊM** TRÊN Ô TÍCH, KHÔNG PHẢI MỘT DANH SÁCH RIÊNG. `coso_ql` luôn là
	 *    tập con của những cơ sở đã tích. Nghĩa là mọi thứ cấp PHẠM VI (thẻ phiên,
	 *    `co_quyen_coso`, `co_quyen_ho_so`, `ds_coso_hs`) chạy y như cũ, không đổi một dòng —
	 *    chỉ vế CHẤM CÔNG trừ ra. Làm ngược lại (cột riêng ngoài ô tích) là phải sửa hết mọi
	 *    câu hỏi "người này ở đâu" trong cả plugin, và mỗi câu bỏ sót là một chỗ mất quyền câm.
	 *
	 * ⚠️ Tên nào không có trong ô tích thì BỎ. Cờ sót lại của một cơ sở đã bỏ tích mà vẫn tính
	 *    thì lượt lưu sau, người ta tích lại cơ sở ấy là nó lặng lẽ không chấm công được.
	 */
	public static function ds_coso_ql( $hs ) {
		$co = array();
		foreach ( self::ds_coso_hs( $hs ) as $x ) { $co[ self::chu_thuong( $x ) ] = $x; }
		$ra = array();
		$goc = isset( $hs['coso_ql'] ) ? (string) $hs['coso_ql'] : '';
		foreach ( explode( ',', $goc ) as $x ) {
			$x = self::chuan_coso( $x );
			if ( '' === $x ) { continue; }
			$k = self::chu_thuong( $x );
			if ( ! isset( $co[ $k ] ) || isset( $ra[ $k ] ) ) { continue; }
			$ra[ $k ] = $co[ $k ];
		}
		return array_values( $ra );
	}

	/**
	 * CƠ SỞ NGƯỜI NÀY QUẢN LÝ NGƯỜI KHÁC — cộng cả hai kiểu quản.
	 *
	 * =========================================================================================
	 * 🔴 QUẢN LÝ VÀ CHẤM CÔNG LÀ HAI CHUYỆN RỜI NHAU
	 * =========================================================================================
	 * Anh Thắng 18/09/2026: *"nếu chấm công thì xem quản thân chứ, còn quản lý mới xem được cả
	 * cửa hàng"*. Trước bản này `co_quyen_coso()` hỏi `ds_coso_cua()` — MỌI cơ sở đã tích — nên
	 * hễ ai chấm công ở đâu là xem được cả bảng công cửa hàng đó, duyệt được đơn của người ở đó,
	 * thêm được nhân sự vào đó. Một cửa hàng trưởng thỉnh thoảng sang cơ sở khác làm một ca là
	 * lập tức quản được cả cơ sở ấy.
	 *
	 * Một người ở một cơ sở nay có đúng bốn cảnh, và cột nào lo cảnh nào:
	 *   · chấm công, không quản   → tích, không cờ nào       (nhân viên; CHT đi làm nhờ)
	 *   · chấm công VÀ quản       → tích + `coso_quan`        (CHT ở chính cửa hàng mình)
	 *   · quản, không chấm công   → tích + `coso_ql`          (CHT trông coi cơ sở vệ tinh)
	 *   · không thuộc về          → không tích
	 *
	 * ⚠️ `coso_ql` ĐÃ HÀM Ý QUẢN LÝ nên gộp vào đây, không bắt khai hai lần. Bắt khai hai lần
	 *    là mọi hồ sơ đang chạy phải sửa tay, và sửa sót một dòng thì người ta lặng lẽ mất quyền.
	 */
	/**
	 * GIEO `coso_quan` MỘT LẦN cho hồ sơ đã có — chạy lúc nâng lược đồ.
	 *
	 * =========================================================================================
	 * 🔴 KHÔNG GIEO THÌ CÀI XONG LÀ CẢ CHUỖI MẤT QUYỀN CÙNG LÚC
	 * =========================================================================================
	 * Trước bản này không có cột nào nói "quản ở đâu" — `co_quyen_coso()` suy ra từ danh sách
	 * đã tích. Đổi cổng sang hỏi `coso_quan` mà cột ấy rỗng thì mọi cửa hàng trưởng mất quyền ở
	 * CHÍNH cửa hàng mình ngay lúc bấm Kích hoạt, và không ai đoán ra vì sao.
	 *
	 * Gieo bằng `cua_hang` — CƠ SỞ CHÍNH. Đó đúng là cửa hàng người ta phụ trách, và là cách
	 * duy nhất dựng lại được ý định cũ từ dữ liệu đang có.
	 *
	 * ⚠️ CHỈ GIEO CHO AI QUA BẬC `cong_coso`. Nhân viên thường không quản ai; gieo cho họ là
	 *    phát quyền quản lý cho cả chuỗi bằng một lượt nâng cấp im lặng.
	 * ⚠️ CHỈ GIEO KHI CỘT CÒN RỖNG. Chạy lại lượt nâng cấp không được đè lên thứ người ta đã
	 *    khai tay sau đó.
	 */
	public static function gieo_coso_quan() {
		global $wpdb;
		$t  = VHCC_DB::t( 'nhan_vien' );
		$ds = $wpdb->get_results(
			"SELECT ma_nv, cua_hang, vai_tro FROM $t"
			. " WHERE cua_hang <> '' AND (coso_quan IS NULL OR coso_quan = '')", ARRAY_A );
		$so = 0;
		foreach ( (array) $ds as $r ) {
			if ( ! VHCC_Vai::duoc( array( 'role' => (string) $r['vai_tro'] ), 'cong_coso' ) ) { continue; }
			$cs = self::chuan_coso( $r['cua_hang'] );
			if ( '' === $cs ) { continue; }
			$wpdb->update( $t, array( 'coso_quan' => $cs ), array( 'ma_nv' => (string) $r['ma_nv'] ) );
			$so++;
		}
		return $so;
	}

	/** CHỈ cột `coso_quan`, KHÔNG gộp `coso_ql` — dùng lúc LƯU, để hai cột không nuốt nhau. */
	public static function ds_coso_quan_tho( $hs ) {
		$co = array();
		foreach ( self::ds_coso_hs( $hs ) as $x ) { $co[ self::chu_thuong( $x ) ] = $x; }
		$ra = array();
		foreach ( explode( ',', isset( $hs['coso_quan'] ) ? (string) $hs['coso_quan'] : '' ) as $x ) {
			$x = self::chuan_coso( $x );
			if ( '' === $x ) { continue; }
			$k = self::chu_thuong( $x );
			if ( ! isset( $co[ $k ] ) || isset( $ra[ $k ] ) ) { continue; }
			$ra[ $k ] = $co[ $k ];
		}
		return array_values( $ra );
	}

	public static function ds_coso_quan( $hs ) {
		$co = array();
		foreach ( self::ds_coso_hs( $hs ) as $x ) { $co[ self::chu_thuong( $x ) ] = $x; }
		$ra = array();
		foreach ( self::ds_coso_ql( $hs ) as $x ) { $ra[ self::chu_thuong( $x ) ] = $x; }
		$goc = isset( $hs['coso_quan'] ) ? (string) $hs['coso_quan'] : '';
		foreach ( explode( ',', $goc ) as $x ) {
			$x = self::chuan_coso( $x );
			if ( '' === $x ) { continue; }
			$k = self::chu_thuong( $x );
			/* Lọc lại theo danh sách ĐÃ TÍCH: cờ sót của một cơ sở đã bỏ tích mà còn tính thì
			   người ta vẫn quản được một chỗ hồ sơ không còn nói họ thuộc về. */
			if ( ! isset( $co[ $k ] ) || isset( $ra[ $k ] ) ) { continue; }
			$ra[ $k ] = $co[ $k ];
		}
		return array_values( $ra );
	}

	/**
	 * CƠ SỞ NGƯỜI NÀY CHẤM CÔNG ĐƯỢC = đã tích, TRỪ mấy cơ sở đặt "chỉ quản lý".
	 *
	 * ⚠️ KHÔNG BAO GIỜ RỖNG khi hồ sơ có tích cơ sở: `dat_ds_coso()` và biểu mẫu hồ sơ chối
	 *    lượt lưu đặt cờ "chỉ quản lý" lên CƠ SỞ CHÍNH. Nhờ vậy `coSoMacDinh` của trạm (đọc
	 *    `cua_hang`) luôn là một cơ sở chấm được — nếu không, ô xổ trên trạm chọn sẵn một cơ sở
	 *    không có trong danh sách, và lượt chấm không chọn cơ sở ghi vào một nơi vừa bị loại.
	 */
	public static function ds_coso_cham( $hs ) {
		$bo = array();
		foreach ( self::ds_coso_ql( $hs ) as $x ) { $bo[ self::chu_thuong( $x ) ] = 1; }
		$ra = array();
		foreach ( self::ds_coso_hs( $hs ) as $x ) {
			if ( isset( $bo[ self::chu_thuong( $x ) ] ) ) { continue; }
			$ra[] = $x;
		}
		return $ra;
	}

	/** Cơ sở này của hồ sơ ấy đang là "chỉ quản lý — không chấm công" không. */
	public static function la_chi_quan_ly( $hs, $coso ) {
		$coso = self::chu_thuong( self::chuan_coso( $coso ) );
		if ( '' === $coso ) { return false; }
		foreach ( self::ds_coso_ql( $hs ) as $x ) {
			if ( self::chu_thuong( $x ) === $coso ) { return true; }
		}
		return false;
	}

	/** Hồ sơ này có CHẤM CÔNG ở cơ sở ấy không — tích rồi và không đặt "chỉ quản lý". */
	public static function hs_cham_coso( $hs, $coso ) {
		$coso = self::chu_thuong( self::chuan_coso( $coso ) );
		if ( '' === $coso ) { return false; }
		foreach ( self::ds_coso_cham( $hs ) as $x ) {
			if ( self::chu_thuong( $x ) === $coso ) { return true; }
		}
		return false;
	}

	/** Hồ sơ này có làm ở cơ sở ấy không — so KHÔNG phân biệt hoa thường. */
	public static function hs_thuoc_coso( $hs, $coso ) {
		$coso = self::chu_thuong( self::chuan_coso( $coso ) );
		if ( '' === $coso ) { return false; }
		foreach ( self::ds_coso_hs( $hs ) as $x ) {
			if ( self::chu_thuong( $x ) === $coso ) { return true; }
		}
		return false;
	}

	/**
	 * Người đang đăng nhập có được xem hồ sơ này không.
	 *
	 * 🔴 ĐỦ MỘT CƠ SỞ TRÙNG LÀ ĐƯỢC. Cửa hàng trưởng của B phải thấy người tích B, dù trong hồ
	 *    sơ họ B đứng thứ hai — đó chính là *"có mặt làm việc đầy đủ tại chi nhánh đó"*.
	 */
	public static function co_quyen_ho_so( $u, $hs ) {
		$ds = self::ds_coso_hs( $hs );
		if ( ! $ds ) { return self::co_quyen_coso( $u, '' ); }
		foreach ( $ds as $x ) {
			if ( self::co_quyen_coso( $u, $x ) ) { return true; }
		}
		return false;
	}

	/**
	 * Mệnh đề SQL "hồ sơ có làm ở cơ sở này" — NỚI RỘNG, lọc lại bằng PHP.
	 *
	 * ⚠️ `coso_phu` là một chuỗi nối bằng dấu phẩy, mà cách so chính xác trong SQL thì mỗi hệ
	 *    quản trị viết một kiểu (`CONCAT` của MySQL, `||` của SQLite). Nên ở đây chỉ NỚI bằng
	 *    `LIKE %X%` — có thể bắt thừa khi tên cơ sở này là một khúc của tên cơ sở khác — rồi
	 *    `hs_thuoc_coso()` lọc lại cho đúng. Nới rồi lọc thì sai một chiều duy nhất là đọc thừa
	 *    vài dòng; hẹp rồi thôi thì sai chiều kia, là MẤT người, và mất im lặng.
	 *
	 * @return array `sql` · `tv` (tham số cho $wpdb->prepare)
	 */
	public static function dk_sql_coso( $coso ) {
		$coso = self::chuan_coso( $coso );
		if ( '' === $coso ) { return array( 'sql' => '1=1', 'tv' => array() ); }
		/* 🔴 CỐ Ý KHÔNG `esc_like()`, VÀ ĐÂY LÀ MỘT CÁI BẪY THẬT ĐÃ SẬP.
		   Mã cơ sở của K&H đầy dấu gạch dưới (`POSH_HCM`, `FZ_SC_VIVO_T`). `esc_like()` biến
		   `_` thành `\_`, mà dấu `\` chỉ là ký tự thoát của LIKE trên MySQL — SQLite thì
		   KHÔNG, trừ khi khai `ESCAPE`. Nên cùng một câu cho hai kết quả khác nhau: trên
		   hosting thì khớp, trên máy chạy thử thì không. Loại lệch ấy tệ hơn cả một lỗi thường,
		   vì bộ thử và thật nói ngược nhau mà chẳng bên nào kêu.

		   Bỏ `esc_like()` thì `_` và `%` trong tên cơ sở thành ký tự đại diện, tức mệnh đề bắt
		   THỪA. Đúng ý: mệnh đề này vốn chỉ để NỚI, và `hs_thuoc_coso()` lọc lại cho đúng ngay
		   sau đó. Nới rồi lọc thì sai một chiều duy nhất là đọc thừa vài dòng.

		   ⚠️ NƠI GỌI PHẢI LỌC LẠI. Không lọc thì đây thành lỗ: lọc cơ sở "TA" kéo về cả người
		      của "BETA", tức lộ hồ sơ của chi nhánh khác. Phá thử canh đúng chỗ đó. */
		return array(
			'sql' => '(LOWER(cua_hang)=LOWER(%s) OR LOWER(coso_phu) LIKE LOWER(%s))',
			'tv'  => array( $coso, '%' . $coso . '%' ),
		);
	}

	/**
	 * Hồ sơ này đã nghỉ việc chưa — đọc từ ô "Trạng thái làm việc".
	 *
	 * 🔴 MỘT NƠI DUY NHẤT quyết định câu đó. Ô này người ta gõ tay, nên trong sổ có đủ kiểu:
	 *    "Đã nghỉ", "Nghỉ việc", "đã nghỉ 12/2025", "NGHỈ". Luật là *có chữ "nghỉ"*, và luật
	 *    ấy phải giống nhau ở mọi chỗ hỏi: cổng trạm chấm công, bảng đối chiếu máy, danh sách
	 *    lương. Hai nơi tự viết luật riêng thì có ngày một người nghỉ vẫn chấm công được ở cửa
	 *    này trong khi cửa kia đã chặn — và không ai biết bên nào đúng.
	 *
	 * ⚠️ Ô TRỐNG = ĐANG LÀM. Sổ cũ nhiều dòng bỏ trống ô này; coi trống là nghỉ thì khoá cửa
	 *    của phần lớn công ty ngay lượt cài đặt đầu tiên.
	 */
	public static function da_nghi( $trang_thai ) {
		$t = trim( (string) $trang_thai );
		if ( '' === $t ) { return false; }
		return false !== strpos( self::chu_thuong( $t ), 'nghỉ' );
	}

	/** Chữ thường có dấu — mb_strtolower khi có, strtolower khi không (host cũ thiếu mbstring). */
	public static function chu_thuong( $s ) {
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( (string) $s, 'UTF-8' ) : strtolower( (string) $s );
	}

	/**
	 * Đọc một ô TIỀN người ta gõ tay — bản dịch `_vpSoTien`.
	 *
	 * ⚠️ PHẢI phân biệt kiểu VIỆT và kiểu ANH, không được vét sạch dấu chấm rồi thôi:
	 *      13.000.000  (kiểu Việt: chấm là phân cách nghìn)  -> 13000000
	 *      13,000,000  (kiểu Anh:  phẩy là phân cách nghìn)  -> 13000000
	 *      13,5        (kiểu Việt: phẩy là dấu thập phân)    -> 13.5
	 *    Bản đầu của hàm này em viết `preg_replace('/[^0-9.]/','')` rồi `(float)` — nghĩa là
	 *    "13.000.000" thành **13 đồng**. Lương một người thành 13 đồng, mà ô vẫn có số nên bảng
	 *    lương trông vẫn bình thường. Đây đúng loại sai mà cả việc này phải tránh.
	 */
	public static function so_tien( $v ) {
		if ( is_int( $v ) || is_float( $v ) ) { return is_finite( (float) $v ) ? (float) $v : 0.0; }
		$s = trim( (string) $v );
		if ( '' === $s ) { return 0.0; }
		$s = preg_replace( '/[^\d.,-]/', '', $s );                       // bỏ 'đ', 'VND', khoảng trắng
		if ( preg_match( '/^-?\d{1,3}(\.\d{3})+$/', $s ) ) {
			$s = str_replace( '.', '', $s );                              // 13.000.000  (kiểu VN)
		} elseif ( preg_match( '/^-?\d{1,3}(,\d{3})+(\.\d+)?$/', $s ) ) {
			$s = str_replace( ',', '', $s );                              // 13,000,000.5 (kiểu Anh)
		} else {
			$s = str_replace( ',', '.', $s );                             // '13,5' -> 13.5
		}
		return is_numeric( $s ) ? (float) $s : 0.0;
	}

	// ======================================================================= đọc

	/** Danh sách hồ sơ. Ô lương bị BỎ HẲN khỏi kết quả khi không có quyền, không chỉ ẩn trên màn. */
	public static function ds_nhan_vien( $u, $coso = '', $tim = '' ) {
		global $wpdb;
		$dk = array( '1=1' );
		$tv = array();
		$coso = self::chuan_coso( $coso );
		/* Lọc theo cơ sở phải tính CẢ cơ sở người ta tích thêm — xem `dk_sql_coso()`. Hỏi mỗi
		   `cua_hang` là danh sách nhân sự của một chi nhánh thiếu đúng những người hay chạy
		   giữa hai chi nhánh, tức là những người cần theo dõi nhất. */
		if ( '' !== $coso ) {
			$dk_cs = self::dk_sql_coso( $coso );
			$dk[]  = $dk_cs['sql'];
			$tv    = array_merge( $tv, $dk_cs['tv'] );
		}
		if ( '' !== trim( (string) $tim ) ) {
			$like = '%' . $wpdb->esc_like( trim( $tim ) ) . '%';
			$dk[] = '(ma_nv LIKE %s OR ho_ten LIKE %s OR sdt LIKE %s OR cccd LIKE %s)';
			$tv = array_merge( $tv, array( $like, $like, $like, $like ) );
		}
		$sql = 'SELECT * FROM ' . VHCC_DB::t( 'nhan_vien' ) . ' WHERE ' . implode( ' AND ', $dk )
			. ' ORDER BY cua_hang, ho_ten';
		$rows = VHCC_DB::rows( $tv ? $wpdb->prepare( $sql, $tv ) : $sql );

		$xem_luong = self::co_xem_luong( $u );
		$out = array();
		foreach ( $rows as $r ) {
			/* Mệnh đề SQL ở trên NỚI (LIKE), nên lọc lại cho đúng ở đây. */
			if ( '' !== $coso && ! self::hs_thuoc_coso( $r, $coso ) ) { continue; }
			// Cửa hàng trưởng thấy người của MỌI cơ sở mình quản, kể cả người tích thêm.
			if ( ! self::co_quyen_ho_so( $u, $r ) ) { continue; }
			if ( ! $xem_luong ) {
				/* BỎ khỏi dữ liệu, không phải ẩn bằng CSS. Ẩn trên màn thì số vẫn đi xuống trình
				   duyệt và ai mở công cụ nhà phát triển là đọc được. */
				foreach ( self::O_LUONG as $o ) { unset( $r[ $o ] ); }
			}
			$out[] = $r;
		}
		return $out;
	}

	/**
	 * DÒ HỒ SƠ TRÙNG — trùng HỌ TÊN, hoặc trùng MÃ NV sau khi chuẩn hoá.
	 *
	 * =========================================================================================
	 * Anh Thắng 27/08/2026: *"Nhân viên nào trùng tên, trùng Mã NV thì đưa lên đầu nhé"*.
	 * =========================================================================================
	 * 🔴 VÌ SAO ĐÁNG DÒ. Hồ sơ nạp từ nhiều đợt .csv khác nhau, và đã từng có một đợt hiểu nhầm
	 * cột "ID" của Sheets (số thứ tự dòng) thành Mã NV — nên trong sổ còn lẫn mã `1`, `15`, `996`
	 * bên cạnh mã thật. Hậu quả không nằm ở chỗ xấu mắt: MÃ LÀ KHOÁ. Hai hồ sơ của cùng một
	 * người mang hai mã là công của họ bị chẻ đôi, mỗi nửa một bảng lương; hai người khác nhau
	 * lỡ mang cùng một mã là công của người này cộng vào người kia.
	 *
	 * Cả hai kiểu hỏng ấy đều IM LẶNG — không có lỗi nào phát ra, chỉ có con số cuối tháng sai.
	 * Nên trang phải tự chỉ ra, và chỉ lên đầu, chứ không để anh Thắng lật 5 trang đi tìm.
	 *
	 * ⚠️ SO SAU KHI CHUẨN HOÁ, KHÔNG SO THÔ. "Nguyễn Thị A" và "NGUYỄN THỊ  A" là một người mà
	 *    so thô ra hai. Mã "mnnv1" và "MNNV1 " cũng vậy — mà đúng cặp ấy mới nguy hiểm nhất:
	 *    CSDL coi là hai dòng khác nhau nên không hề chặn, còn người đọc thì thấy y hệt nhau.
	 *
	 * @param array $ds Danh sách hồ sơ (mỗi phần tử có `ma_nv`, `ho_ten`).
	 * @return array [ ma_nv => array( 'ten' => bool, 'ma' => bool ) ] — chỉ những hồ sơ CÓ trùng.
	 */
	public static function dau_hieu_trung( $ds ) {
		$dem_ten = array();
		$dem_ma  = array();
		$khoa    = array();

		foreach ( (array) $ds as $r ) {
			$ma  = isset( $r['ma_nv'] ) ? (string) $r['ma_nv'] : '';
			$ten = isset( $r['ho_ten'] ) ? (string) $r['ho_ten'] : '';
			$k_ten = self::khoa_so( $ten );
			/* Mã so theo chữ HOA + bỏ hết khoảng trắng — không bỏ dấu, vì mã không có dấu và
			   một mã lỡ có dấu thì đó là chuyện khác, phải thấy nó là khác. */
			$k_ma  = strtoupper( preg_replace( '/\s+/', '', trim( $ma ) ) );
			$khoa[] = array( 'ma' => $ma, 'k_ten' => $k_ten, 'k_ma' => $k_ma,
				'coso' => isset( $r['cua_hang'] ) ? (string) $r['cua_hang'] : '' );
			if ( '' !== $k_ten ) { $dem_ten[ $k_ten ] = ( isset( $dem_ten[ $k_ten ] ) ? $dem_ten[ $k_ten ] : 0 ) + 1; }
			if ( '' !== $k_ma )  { $dem_ma[ $k_ma ]   = ( isset( $dem_ma[ $k_ma ] ) ? $dem_ma[ $k_ma ] : 0 ) + 1; }
		}

		/* =====================================================================================
		 * 🔴 TRÙNG TÊN CÙNG MỘT CƠ SỞ LÀ CHUYỆN KHÁC HẲN TRÙNG TÊN KHÁC CƠ SỞ.
		 * =====================================================================================
		 * Anh Thắng 28/08/2026: *"1 nhân viên mà làm 2 cơ sở, nên hệ thống báo trùng. có ảnh
		 * hưởng gì không"*.
		 *
		 * Có, và nặng — nhưng chỉ ở MỘT trong hai kiểu, mà nhãn cũ gộp cả hai làm một:
		 *
		 *   • Khác cơ sở  -> rất có thể là hai người thật, tình cờ trùng tên. Bình thường.
		 *   • CÙNG cơ sở  -> gần như chắc là MỘT người bị tạo hai hồ sơ. Với cả hệ, hai mã NV
		 *     là hai người khác nhau: công chia đôi (không mã nào đủ ngày công chuẩn), lương
		 *     tính theo hai nửa, mỗi hồ sơ một PIN nên đăng nhập bằng PIN nào chỉ thấy nửa ấy.
		 *
		 * ⚠️ Gộp hai kiểu vào một nhãn là bắt người đọc tự phân loại 400 hồ sơ. Mà cái gì bắt
		 *    người ta tự phân loại thì họ phân loại một lần rồi thôi đọc.
		 *
		 * ⚠️ CƠ SỞ SO CÙNG THƯỚC VỚI CẢ HỆ: `strtoupper( chuan_coso() )`. Bỏ qua hoa/thường,
		 *    nhưng KHÔNG gộp "POSH_HCM" với "posh hcm" — và đúng ra là không được gộp: bảng
		 *    công, chùm cơ sở, quyền theo cơ sở đều coi hai chuỗi ấy là HAI cơ sở. Nới riêng ở
		 *    đây là màn này nói một đằng, bảng công tính một nẻo.
		 */
		$cs_theo_ten = array();
		/* Nhóm theo (tên, cơ sở) — thêm 29/08/2026 để biết CHÍNH XÁC mã nào đứng cùng nhóm với
		   mã nào, phục vụ nút "Ghép với hồ sơ kia" ngay tại dòng (xem viec_ghep_voi() ở
		   class-vhcc-trang-ns.php) — trước đây hàm chỉ ĐẾM số lượng trong nhóm, không giữ lại
		   DANH SÁCH mã trong nhóm nên không trỏ được sang "hồ sơ kia" là mã nào. */
		$ma_theo_nhom = array();
		/* Mọi mã theo TÊN, bất kể cơ sở — để mời ghép được cả cặp "trùng tên khác cơ sở". */
		$ma_theo_ten  = array();
		foreach ( (array) $ds as $r ) {
			$k_ten = self::khoa_so( isset( $r['ho_ten'] ) ? (string) $r['ho_ten'] : '' );
			if ( '' === $k_ten ) { continue; }
			$cs = strtoupper( self::chuan_coso( isset( $r['cua_hang'] ) ? $r['cua_hang'] : '' ) );
			if ( ! isset( $cs_theo_ten[ $k_ten ] ) ) { $cs_theo_ten[ $k_ten ] = array(); }
			$cs_theo_ten[ $k_ten ][ $cs ] = ( isset( $cs_theo_ten[ $k_ten ][ $cs ] )
				? $cs_theo_ten[ $k_ten ][ $cs ] : 0 ) + 1;
			$nhom_k = $k_ten . '·' . $cs;
			if ( ! isset( $ma_theo_nhom[ $nhom_k ] ) ) { $ma_theo_nhom[ $nhom_k ] = array(); }
			$ma_nv_r = isset( $r['ma_nv'] ) ? (string) $r['ma_nv'] : '';
			if ( '' !== $ma_nv_r ) {
				$ma_theo_nhom[ $nhom_k ][] = $ma_nv_r;
				if ( ! isset( $ma_theo_ten[ $k_ten ] ) ) { $ma_theo_ten[ $k_ten ] = array(); }
				$ma_theo_ten[ $k_ten ][] = $ma_nv_r;
			}
		}

		$ra = array();
		foreach ( $khoa as $x ) {
			$t = ( '' !== $x['k_ten'] && $dem_ten[ $x['k_ten'] ] > 1 );
			$m = ( '' !== $x['k_ma'] && $dem_ma[ $x['k_ma'] ] > 1 );
			if ( ! $t && ! $m ) { continue; }
			/* Trùng tên NGAY TRONG cơ sở của chính hồ sơ này — không phải "có ai đó cùng tên ở
			   đâu đó". Hai người cùng tên ở hai cơ sở khác nhau thì mỗi người vẫn đứng một
			   mình ở cơ sở của họ, và đó là chuyện bình thường. */
			$mot_nguoi = false;
			$doi = array();
			if ( $t ) {
				$cs_x = strtoupper( self::chuan_coso( isset( $x['coso'] ) ? $x['coso'] : '' ) );
				$mot_nguoi = ( isset( $cs_theo_ten[ $x['k_ten'] ][ $cs_x ] )
					&& $cs_theo_ten[ $x['k_ten'] ][ $cs_x ] > 1 );
				if ( $mot_nguoi ) {
					$nhom_k = $x['k_ten'] . '·' . $cs_x;
					foreach ( (array) ( isset( $ma_theo_nhom[ $nhom_k ] ) ? $ma_theo_nhom[ $nhom_k ] : array() ) as $ma_doi ) {
						if ( $ma_doi !== $x['ma'] ) { $doi[] = $ma_doi; }
					}
				}
			}
			/* 🔴 `doi` CHỈ ĐIỀN KHI CÙNG CƠ SỞ — và đó là lý do nút "Ghép với" không hiện cho
			   cặp trùng tên KHÁC cơ sở. Anh Thắng 13/09/2026: *"Không hiện chỗ sửa hồ sơ để
			   ghép"*, kèm ảnh hai hồ sơ "Nguyễn Thị Mai Anh" mang nhãn *trùng tên (khác cơ sở)*
			   mà không có nút nào.
			   Một người làm hai cơ sở là chuyện thường ở chuỗi này, nên "khác cơ sở" KHÔNG đủ để
			   kết luận hai người. Nay kê riêng `doiTen` — mọi mã cùng tên, bất kể cơ sở — để màn
			   hình mời ghép được, còn việc có thật sự là một người hay không thì màn XEM TRƯỚC
			   lo (nó bày CCCD, SĐT, ngày vào làm ra để soát). */
			$doi_ten = array();
			if ( $t ) {
				foreach ( (array) ( isset( $ma_theo_ten[ $x['k_ten'] ] ) ? $ma_theo_ten[ $x['k_ten'] ] : array() ) as $md ) {
					if ( $md !== $x['ma'] ) { $doi_ten[] = $md; }
				}
			}
			$ra[ $x['ma'] ] = array( 'ten' => $t, 'ma' => $m, 'motNguoi' => $mot_nguoi,
				'doi' => $doi, 'doiTen' => $doi_ten );
		}
		return $ra;
	}

	/**
	 * ĐẾM DỮ LIỆU CHẤM CÔNG CỦA MỘT LOẠT MÃ — MỘT LƯỢT GỌI, không hỏi từng mã.
	 *
	 * Anh Thắng 29/08/2026, đứng trước cặp "một người hai hồ sơ?" (MNNV2KVC0113/0177, cùng tên
	 * Trần Minh Chiến, cùng cơ sở): *"giờ anh muốn xóa, nhưng không biết ai là thật, có ô nào
	 * hiện ra người có dữ liệu và người không có dữ liệu không — dữ liệu chấm công... để biết
	 * người đó có hoạt động"*.
	 *
	 * Nhãn "một người hai hồ sơ?" chỉ NGHI — nó không nói mã nào là mã dùng thật, mã nào là mã
	 * tạo lỡ (bấm nhầm lúc nhập, test, hoặc cơ sở cũ không dùng nữa). Đếm số lượt CHẤM CÔNG THẬT
	 * của mỗi mã trong cặp trả lời đúng câu đó: mã có hàng trăm lượt là mã đang dùng, mã 0 lượt
	 * gần như chắc là hồ sơ rác — xoá mã đó không mất công của ai.
	 *
	 * ⚠️ CHỈ ĐẾM MÃ CẦN, KHÔNG ĐẾM CẢ SỔ. Trang Nhân sự có thể tới hàng trăm hồ sơ; đa số không
	 *    trùng gì cả. Gọi hàm này với đúng danh sách mã đang bị gắn cờ trùng (`array_keys($trung)`
	 *    ở nơi gọi) — một câu SQL `GROUP BY` cho đúng nhóm nhỏ đó, không quét toàn bảng chấm công
	 *    theo từng mã một (N+1) và không đếm luôn cả những mã chẳng ai nghi ngờ.
	 *
	 * @param array $ds_ma Danh sách Mã NV cần đếm.
	 * @return array [ ma_nv => [ 'luot'=>int, 'tu'=>'Y-m-d'|'', 'den'=>'Y-m-d'|'' ] ] — mã nào
	 *   không có dòng nào trong bảng `cham_cong` thì KHÔNG có khoá trong mảng trả về (0 lượt).
	 */
	public static function dem_cham_cong_theo_ma( $ds_ma ) {
		global $wpdb;
		$ds = array();
		foreach ( (array) $ds_ma as $m ) {
			$m = trim( (string) $m );
			if ( '' !== $m ) { $ds[ $m ] = true; }
		}
		$ds = array_keys( $ds );
		if ( ! $ds ) { return array(); }

		$t  = VHCC_DB::t( 'cham_cong' );
		$ph = implode( ',', array_fill( 0, count( $ds ), '%s' ) );
		$sql = $wpdb->prepare(
			"SELECT ma_nv, COUNT(*) AS luot, MIN(ngay) AS tu, MAX(ngay) AS den
			 FROM $t WHERE ma_nv IN ($ph) GROUP BY ma_nv", $ds );

		$ra = array();
		foreach ( VHCC_DB::rows( $sql ) as $r ) {
			$ra[ (string) $r['ma_nv'] ] = array( 'luot' => (int) $r['luot'],
				'tu' => (string) $r['tu'], 'den' => (string) $r['den'] );
		}
		return $ra;
	}

	/**
	 * Khoá so sánh của một họ tên: BỎ DẤU, hạ chữ, gộp khoảng trắng, bỏ ký tự lạ.
	 *
	 * 🔴 PHẢI BỎ DẤU TRƯỚC KHI LỌC KÝ TỰ. `chu_thuong()` chỉ hạ chữ, không bỏ dấu — nên
	 *    `preg_replace('/[^a-z0-9]+/')` chạy ngay sau nó sẽ XOÁ mọi chữ có dấu: "Nguyễn" thành
	 *    "nguy n". Khi ấy "Nguyễn Thị A" và "Nguyệt Thị A" cùng ra "nguy n thi a" — hai người
	 *    khác nhau bị báo là trùng tên, còn hai người trùng tên thật thì vẫn nhận ra được. Sai
	 *    kiểu ấy tệ hơn không dò: nó đẻ ra báo động giả, và báo động giả thì người ta tắt đi.
	 *    Đây đúng là lỗi em vừa mắc ở bản nháp đầu.
	 * ⚠️ Gác `method_exists` cùng hàm với lời gọi — luật `tools/test/kiem-goi-cheo.php`.
	 */
	public static function khoa_so( $s ) {
		$x = trim( (string) $s );
		if ( class_exists( 'VHCC_Vai' ) && method_exists( 'VHCC_Vai', 'bo_dau' ) ) {
			$x = VHCC_Vai::bo_dau( $x );          // đã hạ chữ thường luôn
		} else {
			$x = self::chu_thuong( $x );
		}
		$x = preg_replace( '/[^a-z0-9]+/', ' ', $x );
		return trim( preg_replace( '/\s+/', ' ', $x ) );
	}

	/**
	 * Xếp những hồ sơ ĐÁNG NGỜ lên đầu, giữ nguyên thứ tự cũ trong từng nhóm.
	 *
	 * ⚠️ SẮP XẾP TRƯỚC KHI CẮT TRANG. Cắt trang rồi mới xếp thì hồ sơ trùng nằm ở trang 4 vẫn
	 *    ở trang 4 — mà "đưa lên đầu" chính là để khỏi phải lật từng trang đi tìm.
	 *
	 * ⚠️ Giữ thứ tự cũ trong mỗi nhóm (`usort` của PHP 8 đã ổn định, PHP 7 thì không) — nên
	 *    kèm chỉ số làm khoá phụ, đừng phó mặc cho phiên bản PHP của hosting.
	 */
	public static function xep_trung_len_dau( $ds, $trung ) {
		$co = array();
		$khong = array();
		foreach ( (array) $ds as $r ) {
			$ma = isset( $r['ma_nv'] ) ? (string) $r['ma_nv'] : '';
			if ( isset( $trung[ $ma ] ) ) { $co[] = $r; } else { $khong[] = $r; }
		}
		return array_merge( $co, $khong );
	}

	public static function ho_so( $ma_nv ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . VHCC_DB::t( 'nhan_vien' ) . ' WHERE ma_nv=%s', trim( (string) $ma_nv ) ), ARRAY_A );
	}

	/**
	 * MÃ TRÊN MÁY -> MÃ NHÂN SỰ THẬT.
	 *
	 * =============================================================================================
	 * Anh Thắng 27/08/2026: *"bắt đầu kết nối máy chấm công để tránh mất dữ liệu"*.
	 * =============================================================================================
	 * 🔴 HAI BỘ MÃ KHÁC HẲN NHAU, VÀ ĐÓ LÀ CHỖ DỮ LIỆU MÁY SẼ RƠI HẾT.
	 *    Máy ZKTeco ở xưởng trả `employeeNo` dạng `20000601` — mã ấy do người dựng máy gõ vào
	 *    từng đầu đọc, không ai đối chiếu với sổ nhân sự. Hồ sơ ở đây dùng mã dạng
	 *    `MNNV1CTY0002`. Đẩy thẳng mã máy vào bảng chấm công thì cả tháng công của cả xưởng nằm
	 *    dưới một dãy số không có hồ sơ nào: bảng đầy số, mà không số nào ra lương của ai.
	 *    Ảnh phần mềm HR V5.2 anh gửi cho thấy đúng chuyện ấy — cột Họ tên trống trơn, mỗi dòng
	 *    ghi "Chưa phân phòng", và có hẳn một nút tên là *"Phân nhân viên vào phòng / ghép mã NV"*.
	 *
	 * 🔴 KHAI, KHÔNG ĐOÁN. Bảng `ma_song_song` sinh ra đúng cho việc này và câu chú thích của nó
	 *    vẫn đúng nguyên: *"Hai mã của cùng một người, PHẢI KHAI chứ không đoán: tên người Việt
	 *    trùng rất nhiều, đoán sai là gộp lương hai người khác nhau"*. Ghép theo tên là ghép
	 *    Nguyễn Văn A này sang Nguyễn Văn A kia, và tiền đi theo.
	 *
	 * ⚠️ KHÔNG CẦN QUY ƯỚC CHIỀU `ma_a` / `ma_b`. Bảng ấy không nói bên nào là mã máy, và bắt
	 *    người khai nhớ đúng chiều là sớm muộn có dòng khai ngược — im lặng. Luật ở đây tự suy
	 *    ra: mã đến mà ĐÃ CÓ hồ sơ thì giữ nguyên; không có hồ sơ thì tìm đầu kia của cặp, và
	 *    chỉ nhận nếu đầu kia CÓ hồ sơ. Khai ngược cũng chạy đúng.
	 *
	 * ⚠️ KHÔNG TÌM THẤY THÌ TRẢ LẠI CHÍNH NÓ, đừng trả rỗng. Lượt ấy phải đi tiếp đúng đường cũ
	 *    — vào bảng với mã máy và được kể ra ở khối "chưa có hồ sơ" — chứ không biến mất. Mất
	 *    một lượt bấm là mất công của người thật.
	 */
	public static function ma_that( $ma_nv ) {
		global $wpdb;
		$ma = trim( (string) $ma_nv );
		/* ⚠️ Chốt mã rỗng là PHÒNG XA, không phải chốt canh hành vi: tra với mã rỗng cũng chẳng
		   khớp dòng nào nên kết quả y hệt — chỉ tốn thêm hai lượt hỏi cơ sở dữ liệu. Đã phá thử
		   và ghi lại để người sau khỏi đi tìm phép thử canh nó: KHÔNG CÓ. */
		if ( '' === $ma ) { return ''; }
		if ( self::ho_so( $ma ) ) { return $ma; }

		$cap = VHCC_DB::rows( $wpdb->prepare(
			'SELECT ma_a, ma_b FROM ' . VHCC_DB::t( 'ma_song_song' )
			. ' WHERE LOWER(ma_a)=LOWER(%s) OR LOWER(ma_b)=LOWER(%s)', $ma, $ma ) );
		foreach ( (array) $cap as $c ) {
			$kia = ( 0 === strcasecmp( (string) $c['ma_a'], $ma ) ) ? (string) $c['ma_b'] : (string) $c['ma_a'];
			$kia = trim( $kia );
			if ( '' !== $kia && 0 !== strcasecmp( $kia, $ma ) && self::ho_so( $kia ) ) { return $kia; }
		}
		return $ma;
	}

	/** Cơ sở đã biết: gộp từ bảng máy, bảng chấm công và hồ sơ — không tự tạo cơ sở nào. */
	/**
	 * MỌI BẢNG ĐANG TRỎ TỚI MÃ NHÂN VIÊN — dò từ CHÍNH sơ đồ bảng, không gõ tay danh sách.
	 *
	 * 🔴 Gõ tay là sớm muộn thiếu. Thêm một bảng mới có cột `ma_nv` mà quên khai ở đây thì đổi
	 *    mã sẽ bỏ sót đúng bảng đó — dữ liệu của người ta rơi ra ngoài, không có gì báo, và chỉ
	 *    lộ ra ở bảng lương cuối tháng. Đọc sơ đồ thì bảng mới tự có mặt.
	 *
	 * `ma_song_song` khai riêng vì nó gọi hai cột là `ma_a`/`ma_b` chứ không phải `ma_nv`.
	 */
	public static function bang_theo_ma() {
		$ra = array();
		foreach ( VHCC_DB::bang() as $ten => $than ) {
			if ( 'nhan_vien' === $ten ) { continue; }          // chính nó, xử riêng
			foreach ( array( 'ma_nv', 'ma_a', 'ma_b' ) as $cot ) {
				if ( preg_match( '/^\s*' . $cot . '\s+VARCHAR/mi', $than ) ) { $ra[ $ten ][] = $cot; }
			}
		}
		return $ra;
	}

	/**
	 * ĐỔI MÃ NHÂN VIÊN — và KÉO THEO mọi hàng đang trỏ tới mã cũ.
	 *
	 * Anh Thắng: *"Admin có quyền sửa luôn mã nhân viên lại cho chuẩn nhé"*. Được, nhưng phải
	 * làm cho tới: mã nhân viên là thứ NỐI hồ sơ với chấm công, lương, lịch làm, yêu cầu, sổ
	 * mặt trong máy. Đổi mỗi ở bảng hồ sơ là toàn bộ lịch sử của người đó rơi ra ngoài — bảng
	 * công trống trơn, mà không có gì báo.
	 *
	 * 🔴 CHẶN GHI ĐÈ LÊN MÃ ĐANG CÓ NGƯỜI. Đổi A -> B khi B đã tồn tại là trộn công của hai
	 *    người vào một, và KHÔNG có đường lùi: sau đó không phân biệt được hàng nào vốn của ai.
	 *    Đây đúng là cảnh báo màn Nhân sự trong wp-admin vẫn in ra, giờ thành một cái chặn thật.
	 *
	 * @return array ['ok', 'bang' => [tên bảng => số hàng đã kéo theo]]
	 */
	public static function doi_ma( $cu, $moi ) {
		global $wpdb;
		$cu  = trim( (string) $cu );
		$moi = trim( (string) $moi );

		if ( '' === $cu || '' === $moi ) {
			return array( 'ok' => false, 'error' => 'Thiếu mã cũ hoặc mã mới.' );
		}
		if ( $cu === $moi ) { return array( 'ok' => true, 'bang' => array(), 'khong_doi' => true ); }
		/* Mã đi vào URL, tên file, và cột khoá của mọi bảng. Giữ khuôn hẹp còn hơn xử lý ký tự
		   lạ ở mười chỗ khác nhau. */
		if ( ! preg_match( '/^[A-Za-z0-9_.\-]{1,40}$/', $moi ) ) {
			return array( 'ok' => false, 'error' => 'Mã mới chỉ được gồm chữ, số, gạch dưới, gạch nối '
				. 'và dấu chấm, tối đa 40 ký tự. Đã nhập: "' . $moi . '".' );
		}
		$bang_nv = VHCC_DB::t( 'nhan_vien' );
		$co_cu   = $wpdb->get_var( $wpdb->prepare( "SELECT ma_nv FROM $bang_nv WHERE ma_nv=%s", $cu ) );
		if ( ! $co_cu ) {
			return array( 'ok' => false, 'error' => 'Không thấy hồ sơ mang mã ' . $cu . '.' );
		}
		$co_moi = $wpdb->get_var( $wpdb->prepare( "SELECT ho_ten FROM $bang_nv WHERE ma_nv=%s", $moi ) );
		if ( null !== $co_moi ) {
			return array( 'ok' => false, 'error' => 'Mã ' . $moi . ' đã là của ' . $co_moi
				. '. Đổi sang mã đang có người là TRỘN công của hai người vào một, và không có '
				. 'đường lùi — sau đó không phân biệt được hàng nào vốn của ai. Chọn mã khác.' );
		}

		/* Kéo các bảng phụ TRƯỚC, hồ sơ SAU. Nửa chừng hỏng thì mấy hàng đã kéo trỏ vào một mã
		   chưa có hồ sơ — vẫn tìm lại được bằng chính mã đó. Làm ngược lại thì hồ sơ mang mã mới
		   còn lịch sử nằm ở mã cũ, và không còn gì nối hai đầu. */
		$dem = array();
		foreach ( self::bang_theo_ma() as $ten => $cot_ds ) {
			$t = VHCC_DB::t( $ten );
			foreach ( $cot_ds as $cot ) {
				$n = $wpdb->query( $wpdb->prepare(
					"UPDATE $t SET $cot=%s WHERE $cot=%s", $moi, $cu ) );
				if ( $n > 0 ) { $dem[ $ten ] = ( isset( $dem[ $ten ] ) ? $dem[ $ten ] : 0 ) + (int) $n; }
			}
		}
		$wpdb->update( $bang_nv, array( 'ma_nv' => $moi, 'cap_nhat' => current_time( 'mysql' ) ),
			array( 'ma_nv' => $cu ) );

		return array( 'ok' => true, 'bang' => $dem, 'cu' => $cu, 'moi' => $moi );
	}

	/**
	 * ĐẶT VAI TRÒ CHO MỘT NGƯỜI.
	 *
	 * =========================================================================================
	 * 🔴 ĐỔI VAI LÀ ĐỔI QUYỀN — VÀ ĐÂY LÀ CHỖ MỘT NGƯỜI TỰ NÂNG MÌNH LÊN ADMIN
	 * =========================================================================================
	 * Cho Kế toán sửa ô vai trò mà không chốt gì thì việc đầu tiên làm được là mở ô của CHÍNH
	 * MÌNH, chọn Admin, bấm Lưu. Xong là có PIN xem được PIN của mọi người, máy chấm công, và
	 * toàn bộ cài đặt hệ thống. Không lỗi nào phát ra, không dòng nhật ký nào.
	 *
	 * Nên ba chốt, và ba chốt này KHÁC NHAU chứ không phải một chốt viết ba lần:
	 *   1. KHÔNG ĐẶT VAI CAO HƠN BẬC CỦA CHÍNH MÌNH — chặn đường nâng người khác lên trên đầu
	 *      mình rồi nhờ họ nâng lại.
	 *   2. KHÔNG ĐỤNG VÀO NGƯỜI ĐANG Ở BẬC CAO HƠN — chặn đường Kế toán hạ Admin xuống Nhân
	 *      viên. Thiếu chốt này thì chốt 1 vô dụng: không nâng được mình lên thì hạ hết người
	 *      trên xuống, kết quả y hệt.
	 *   3. KHÔNG TỰ ĐỔI VAI CỦA CHÍNH MÌNH — kể cả hạ. Admin duy nhất tự hạ xuống Nhân viên là
	 *      cả hệ thống không còn ai vào được màn cài đặt, và không có đường nào gỡ ra ngoài
	 *      việc sửa thẳng CSDL.
	 *
	 * ⚠️ LƯU NGUYÊN CHUỖI NGƯỜI TA CHỌN, KHÔNG QUY VỀ TÊN CHUNG. Sổ đang có cả "Kế toán cá nhân"
	 *    lẫn "Kế toán NCC" — hệ chấm công gộp cả hai vào một bậc, nhưng app Vận hành chi phí
	 *    phân biệt chúng. Ghi đè thành "Kế toán" là bên chi phí mất phân biệt, mà bên này không
	 *    thấy gì khác cả.
	 *
	 * @param array  $u      Người đang khai.
	 * @param string $ma_nv  Mã NV của người bị đổi vai.
	 * @param string $vai    Tên vai, phải nằm trong `VHCC_Vai::ds_ten()`.
	 */

	/* ══════════════════════════════════════════════════════════════════════════════════════════
	 * MẢNG KINH DOANH & BỘ PHẬN CỦA MỘT NGƯỜI
	 * ══════════════════════════════════════════════════════════════════════════════════════════
	 * Anh Thắng 13/09/2026: *"Cơ cấu lại hệ nhân sự để phân quyền theo mảng kinh doanh và bộ phận
	 * được phân"* — *"Sau này ai thuộc mảng nào và bộ phận nào sẽ phân quyền và điều động dễ hơn"*.
	 *
	 * Hai trục KHÁC HẲN NHAU, đừng gộp:
	 *   · MẢNG KINH DOANH — mảng việc mà tiền chạy qua: Máy tự động · Khu vui chơi · Văn phòng ·
	 *     Part time. Đây ĐÚNG là vốn từ đã có sẵn trong `bo_phan_coso` (`VHCC_Luong::BP_DS`) —
	 *     bảng ấy gọi là "bộ phận của CƠ SỞ" nhưng nội dung chính là mảng. Không dựng vốn từ thứ
	 *     hai cho cùng một thứ: hai danh sách của một khái niệm thì sớm muộn lệch nhau.
	 *   · BỘ PHẬN — ô trong sơ đồ tổ chức: Phòng Nhân sự, Phòng Kỹ Thuật, Khối Nhân Viên Cơ Sở…
	 *     Người văn phòng KHÔNG thuộc cơ sở nào, nên trục này không suy ra từ cơ sở được.
	 *
	 * =============================================================================================
	 * 🔴 SUY LÚC ĐỌC, KHÔNG GHI ĐÈ LÚC NÂNG CẤP
	 * =============================================================================================
	 * Anh Thắng chọn *"tự suy từ cơ sở, sửa tay chỗ nào sai"*. Có hai cách làm điều đó, và chỉ một
	 * cách đúng:
	 *
	 *   ✗ Chạy một lượt nâng cấp ghi mảng/bộ phận vào cả 225 hồ sơ. Nghe gọn, nhưng: (1) ngày mai
	 *     đổi mảng của một cơ sở thì 40 hồ sơ ghi cứng vẫn mang mảng cũ, không ai biết mà sửa;
	 *     (2) không phân biệt được "đã xếp đúng" với "máy đoán hộ", nên không bao giờ biết còn
	 *     bao nhiêu người chưa ai soát.
	 *
	 *   ✓ Để cột TRỐNG nghĩa là "theo cơ sở", và suy ra lúc đọc. Khai tay là ghi đè, và chỉ khi
	 *     ấy cột mới có chữ. Đổi mảng của cơ sở thì mọi người "theo cơ sở" tự đi theo; ai đã khai
	 *     tay thì đứng yên — đúng như người khai muốn. Và đếm được ngay ai còn đang trôi theo
	 *     cơ sở, ai đã được xếp thật.
	 *
	 * ⚠️ ĐỪNG ĐỔI Ý NỬA CHỪNG. Nếu sau này có ai thêm một lượt nâng cấp ghi đè, cột trống biến
	 *    mất và mọi tính chất trên mất theo, mà không có gì đỏ cả.
	 */

	/** Bộ phận mặc định của người CÓ cơ sở — họ đứng quầy, không thuộc phòng ban nào. */
	const BP_CO_SO = 'Khối Nhân Viên Cơ Sở';

	/** Khoá lưu danh sách bộ phận (sơ đồ tổ chức). Sửa được ở màn nhân sự. */
	const BP_DS_O = 'vhcc_ds_bo_phan';

	/**
	 * Danh sách bộ phận dựng sẵn — đúng sơ đồ anh Thắng đang dùng (ảnh 13/09/2026).
	 *
	 * ⚠️ CHỈ LÀ HẠT GIỐNG cho lần đầu. Sau đó nguồn sự thật là option `vhcc_ds_bo_phan`; sửa hằng
	 *    này KHÔNG đổi được danh sách của một site đã chạy — đó là cố ý, kẻo một bản cập nhật âm
	 *    thầm xoá mất phòng ban người ta tự thêm.
	 */
	const BP_HAT_GIONG = array(
		'Tổng Giám Đốc (CEO)', 'Phòng Nhân sự', 'Phòng Kế Toán - Tài Chính', 'Phòng Kinh doanh',
		'Phòng Marketing', 'Phòng Chăm sóc khách hàng', 'Phòng Hành Chính', 'Phòng Kỹ Thuật',
		'Phòng Kho Hàng', 'Phòng Kỹ Thuật / CNTT', 'Phòng Vận Hành', self::BP_CO_SO,
	);

	/* ══════════════════════════════════════════════════════════════════════════════════════════
	 * MẢNG KINH DOANH — TÊN HIỆN RA MÀN, VÀ BỘ PHẬN RIÊNG CỦA TỪNG MẢNG
	 * ══════════════════════════════════════════════════════════════════════════════════════════
	 * Anh Thắng 13/09/2026: *"Tạo mảng kinh doanh trước (Mảng Kinh Doanh Máy Tự Động) (Mảng Kinh
	 * Doanh Khu Vui Chơi). Mỗi mảng sẽ có một bộ phận riêng"*.
	 *
	 * =========================================================================================
	 * 🔴 ĐỔI TÊN HIỆN RA, KHÔNG ĐỔI GIÁ TRỊ LƯU. Và đây là chỗ suýt làm hỏng lương cả chuỗi.
	 * =========================================================================================
	 * Chuỗi `'Máy tự động'` không phải một cái nhãn — nó là KHOÁ khớp chính xác ở BỐN plugin:
	 *
	 *   · `VHCC_Luong::BP_DS` là danh sách trắng; `bo_phan_cua()` trả 'Chưa xếp' cho bất kỳ giá
	 *     trị nào ngoài nó, mà 'Chưa xếp' nghĩa là KHÔNG CÓ CÔNG THỨC LƯƠNG NÀO;
	 *   · `VHCC_Luong::vp_cfg_khoi()` khoá cấu hình công theo đúng cái tên ấy;
	 *   · `VHCP_Cfg` (chi phí) và `VHDA_Quyen` (dự án) bó quyền theo đúng cái tên ấy;
	 *   · `VCG_Nap` (cổng) chuẩn hoá chuỗi về đúng cái tên ấy.
	 *
	 * Đổi giá trị lưu thành "Mảng Kinh Doanh Máy Tự Động" là cả bốn chỗ trên đồng loạt tra không
	 * ra — lương của cả mảng rơi về "Chưa xếp", im lặng, và chỉ lộ ra ở kỳ lương sau.
	 *
	 * Nên: giá trị lưu GIỮ NGUYÊN, còn màn hình đọc tên dài qua `ten_mang()`. Muốn đổi hẳn giá
	 * trị lưu thì phải là một lượt riêng, đi qua cả bốn plugin.
	 * ══════════════════════════════════════════════════════════════════════════════════════════ */

	/** Khoá lưu TÊN HIỆN RA của mảng: [ giá trị lưu => tên dài ]. */
	const TEN_MANG_O = 'vhcc_ten_mang';

	/** Hạt giống: đúng hai cái tên anh Thắng gõ. */
	const TEN_MANG_HAT_GIONG = array(
		'Máy tự động'  => 'Mảng Kinh Doanh Máy Tự Động',
		'Khu vui chơi' => 'Mảng Kinh Doanh Khu Vui Chơi',
	);

	/** Bản đồ tên hiện ra. */
	public static function ten_mang_ban() {
		/* Đọc thì đừng ghi — cùng lý do với `ds_bo_phan()`. */
		$v = get_option( self::TEN_MANG_O, null );
		if ( ! is_array( $v ) ) { $v = self::TEN_MANG_HAT_GIONG; }
		$ra = array();
		foreach ( $v as $k => $t ) {
			$k = trim( (string) $k ); $t = trim( (string) $t );
			if ( '' !== $k && '' !== $t ) { $ra[ $k ] = $t; }
		}
		return $ra;
	}

	/**
	 * TÊN HIỆN RA của một mảng. Chưa đặt thì trả về chính giá trị lưu.
	 *
	 * ⚠️ Đường lui phải là chính giá trị lưu, KHÔNG phải chuỗi rỗng — mảng mới thêm mà chưa ai
	 *    đặt tên dài thì ô xổ trống trơn, và người ta tưởng dữ liệu hỏng.
	 */
	public static function ten_mang( $m ) {
		$m = trim( (string) $m );
		$b = self::ten_mang_ban();
		return isset( $b[ $m ] ) ? $b[ $m ] : $m;
	}

	/** Đặt tên hiện ra cho một mảng. Tên rỗng = bỏ đặt, quay về dùng giá trị lưu. */
	public static function dat_ten_mang( $u, $mang, $ten ) {
		if ( ! self::co_sua_ho_so( $u ) ) {
			return array( 'ok' => false, 'error' => 'Sửa sơ đồ tổ chức cần vai Kế toán trở lên.' );
		}
		$m = trim( (string) $mang );
		if ( '' === $m ) { return array( 'ok' => false, 'error' => 'Thiếu mảng.' ); }
		if ( ! in_array( $m, self::ds_mang_tat_ca(), true ) ) {
			return array( 'ok' => false, 'error' => 'Không có mảng "' . $m . '".' );
		}
		$t = trim( (string) $ten );
		$b = self::ten_mang_ban();
		$cu = isset( $b[ $m ] ) ? $b[ $m ] : '';
		if ( $cu === $t || ( '' === $t && '' === $cu ) ) {
			return array( 'ok' => false, 'error' => 'Chưa đổi gì.' );
		}
		if ( '' === $t || $t === $m ) { unset( $b[ $m ] ); } else { $b[ $m ] = $t; }
		update_option( self::TEN_MANG_O, $b );
		self::ghi_nhat_ky_bp( $u, 'ten_mang', $m . ' → ' . $cu, $t );
		return array( 'ok' => true, 'mang' => $m, 'ten' => $t );
	}

	/** Khoá lưu những mảng ĐÃ ẨN khỏi các ô chọn. */
	const MANG_AN_O = 'vhcc_mang_an';

	/**
	 * Hạt giống: ẩn sẵn "Part time".
	 *
	 * Anh Thắng 13/09/2026, nhìn ô "Thuộc mảng": *"bỏ 2 cái dưới cùng cho anh"*. "Part time" là
	 * KIỂU LÀM VIỆC, không phải một mảng kinh doanh — cùng loại nhầm với "Tổng Giám Đốc (CEO)"
	 * nằm trong danh sách phòng ban.
	 *
	 * 🔴 ẨN, KHÔNG XOÁ. Chuỗi ấy vẫn nằm trong `VHCC_Luong::BP_DS`, và cơ sở nào đang xếp vào đó
	 *    thì lương vẫn tra ra công thức như cũ. Bỏ hẳn khỏi danh sách trắng là lương của cơ sở ấy
	 *    rơi về "Chưa xếp" — im lặng, tới kỳ lương sau mới lộ.
	 */
	const MANG_AN_HAT_GIONG = array( 'Part time' );

	/** Những mảng đang ẩn khỏi ô chọn. */
	public static function mang_an() {
		/* Đọc thì đừng ghi — cùng lý do với `ds_bo_phan()`. */
		$v = get_option( self::MANG_AN_O, null );
		if ( ! is_array( $v ) ) { $v = array_values( (array) self::MANG_AN_HAT_GIONG ); }
		$ra = array();
		foreach ( $v as $x ) { $x = trim( (string) $x ); if ( '' !== $x ) { $ra[] = $x; } }
		return $ra;
	}

	/** Ẩn / hiện một mảng ở các ô chọn. */
	public static function dat_mang_an( $u, $mang, $an ) {
		if ( ! self::co_sua_ho_so( $u ) ) {
			return array( 'ok' => false, 'error' => 'Sửa sơ đồ tổ chức cần vai Kế toán trở lên.' );
		}
		$m = trim( (string) $mang );
		if ( '' === $m || ! in_array( $m, self::ds_mang_tat_ca(), true ) ) {
			return array( 'ok' => false, 'error' => 'Không có mảng "' . $m . '".' );
		}
		$ds = self::mang_an();
		$co = in_array( $m, $ds, true );
		if ( (bool) $an === $co ) { return array( 'ok' => false, 'error' => 'Chưa đổi gì.' ); }
		if ( $an ) {
			$ds[] = $m;
		} else {
			$ra = array();
			foreach ( $ds as $x ) { if ( $x !== $m ) { $ra[] = $x; } }
			$ds = $ra;
		}
		update_option( self::MANG_AN_O, array_values( $ds ) );
		self::ghi_nhat_ky_bp( $u, 'mang_an', $m, $an ? 'ẩn' : 'hiện' );
		return array( 'ok' => true, 'mang' => $m, 'an' => (bool) $an );
	}

	/**
	 * MỌI MẢNG hệ biết — KỂ CẢ mảng đang ẩn.
	 *
	 * 🔴 MỌI CHỐT DANH SÁCH TRẮNG PHẢI DÙNG HÀM NÀY, không dùng `ds_mang()`. Ẩn một mảng mà chốt
	 *    lưu cũng hẹp theo thì người đang khai tay mảng ấy bấm Lưu là nhận câu chối "mảng không
	 *    có trong hệ" — cho một giá trị chính họ đang mang, và không có cách nào sửa.
	 */
	public static function ds_mang_tat_ca() {
		$ra = array_values( (array) VHCC_Luong::BP_DS );
		/* Mảng lạ còn sót trong hồ sơ cũng phải hiện ra ô xổ — không thì mở hồ sơ ấy lên là ô tự
		   nhảy về dòng đầu, bấm Lưu một cái là đổi mảng của người ta mà không ai định làm vậy.
		   Đúng cái bẫy `dat_vai_tro()` đã dính với vai "Kế Toán MTD". */
		foreach ( self::mang_dang_khai() as $m ) {
			if ( '' !== $m && ! in_array( $m, $ra, true ) ) { $ra[] = $m; }
		}
		return $ra;
	}

	/** Mảng để BÀY RA Ô CHỌN — bỏ những mảng đã ẩn. */
	public static function ds_mang() {
		$an = self::mang_an();
		$ra = array();
		foreach ( self::ds_mang_tat_ca() as $m ) {
			if ( ! in_array( $m, $an, true ) ) { $ra[] = $m; }
		}
		return $ra;
	}

	/**
	 * Những MẢNG thật sự đang nằm trong sổ.
	 *
	 * =========================================================================================
	 * 🔴 PHẢI TÁCH DẤU PHẨY. Anh Thắng 13/09/2026 gửi ảnh ô "Thuộc mảng": dòng cuối là
	 *    *"Máy tự động, Khu vui chơi, Văn phòng, Part time"* — một dòng trông như một mảng, nhưng
	 *    nó là CẢ BỐN MẢNG của MỘT người làm nhiều mảng, dính liền thành một chuỗi.
	 * =========================================================================================
	 * Cột `mang` chở nhiều mảng ngăn bằng dấu phẩy (`dat_mang_bo_phan()` ghi đúng như vậy, và đó
	 * là cố ý — người làm hai mảng là chuyện thường). `SELECT DISTINCT mang` trả về nguyên chuỗi,
	 * nên mỗi TỔ HỢP mảng đẻ ra một "mảng" giả trong danh sách.
	 *
	 * Hỏng theo ba đường, đường nào cũng im lặng:
	 *   · ô chọn mọc thêm dòng rác, và tích vào nó là ghi một tổ hợp cứng cho người ta;
	 *   · dải đếm và ô lọc có một ô không bao giờ khớp ai ngoài đúng mấy người tổ hợp ấy;
	 *   · bảng LUẬT QUYỀN mọc một hàng nhóm giả — khai luật vào đó thì nó chỉ trúng nhúm người
	 *     có đúng tổ hợp ấy, còn người khai tưởng mình vừa khai cho cả bốn mảng.
	 *
	 * `tach_mang()` đã có sẵn cho đúng việc này; chỗ này chỉ quên gọi.
	 */
	public static function mang_dang_khai() {
		$t = VHCC_DB::t( 'nhan_vien' );
		if ( ! VHCC_DB::co_bang( $t ) ) { return array(); }
		global $wpdb;
		$ra = array();
		foreach ( (array) $wpdb->get_col( "SELECT DISTINCT mang FROM $t WHERE mang <> ''" ) as $chuoi ) {
			foreach ( self::tach_mang( $chuoi ) as $m ) { $ra[] = $m; }
		}
		return array_values( array_unique( $ra ) );
	}

	/** Sơ đồ tổ chức đang khai. Lần đầu thì gieo hạt giống rồi lưu lại. */
	public static function ds_bo_phan() {
		/* 🔴 ĐỌC THÌ ĐỪNG GHI. Bản trước gieo hạt giống ngay trong hàm đọc — tiện, nhưng nó biến
		   một câu hỏi thành một lượt ghi: `wp eval-file` soát trên hosting, một lượt tải trang
		   bất kỳ, hay một phép thử chỉ muốn đếm — đều để lại dấu trong CSDL. Hạt giống vẫn trả
		   ra bình thường; nó chỉ được GHI xuống khi có người thật sự sửa sơ đồ. */
		$v = get_option( self::BP_DS_O, null );
		if ( ! is_array( $v ) ) { $v = array_values( (array) self::BP_HAT_GIONG ); }
		$ra = array();
		foreach ( $v as $x ) { $x = trim( (string) $x ); if ( '' !== $x && ! in_array( $x, $ra, true ) ) { $ra[] = $x; } }
		/* Bộ phận lạ còn sót trong hồ sơ — cùng lý do với ds_mang(). */
		$t = VHCC_DB::t( 'nhan_vien' );
		if ( VHCC_DB::co_bang( $t ) ) {
			global $wpdb;
			foreach ( (array) $wpdb->get_col( "SELECT DISTINCT bo_phan FROM $t WHERE bo_phan <> ''" ) as $b ) {
				$b = trim( (string) $b );
				if ( '' !== $b && ! in_array( $b, $ra, true ) ) { $ra[] = $b; }
			}
		}
		return $ra;
	}


	/* ══════════════════════════════════════════════════════════════════════════════════════════
	 * SỬA SƠ ĐỒ TỔ CHỨC — thêm · đổi tên · gộp · xoá phòng ban
	 * ══════════════════════════════════════════════════════════════════════════════════════════
	 * Anh Thắng 13/09/2026: *"cơ cấu vai trò phòng ban nó đang sai"*.
	 *
	 * Và đó là lỗi của chính chỗ này: danh sách phòng ban là một HẠT GIỐNG gieo một lần rồi nằm
	 * trong option — không có một màn hình nào sửa được. Thấy sai thì phải nhắn cho người viết mã
	 * và chờ một bản cập nhật, cho một việc lẽ ra là gõ lại một cái tên.
	 *
	 * 🔴 TÊN BỘ PHẬN LÀ KHOÁ CỦA BA SỔ KHÁC NHAU — đổi tên mà không mang cả ba theo thì mọi thứ
	 *    gắn vào nó rụng ra, IM LẶNG:
	 *      1. `nhan_vien.bo_phan`      — người thuộc phòng ấy;
	 *      2. `vhcc_vai_bo_phan`       — vai bày lên đầu ô xổ của phòng ấy;
	 *      3. `vhcc_quyen_nhom['bp']`  — luật quyền vào trang của phòng ấy.
	 *    Rụng (3) là cả phòng lặng lẽ rơi xuống thang vai — không ai thấy gì cho tới lúc có người
	 *    kêu "sao tôi không vào được nữa". Nên mọi đường ở đây đều đi qua `doi_ten_bo_phan()`.
	 * ══════════════════════════════════════════════════════════════════════════════════════════ */

	/** Ghi danh sách bộ phận (đã rửa trùng & rỗng). */
	private static function ghi_ds_bo_phan( $ds ) {
		$ra = array();
		foreach ( (array) $ds as $x ) {
			$x = trim( (string) $x );
			if ( '' !== $x && ! in_array( $x, $ra, true ) ) { $ra[] = $x; }
		}
		update_option( self::BP_DS_O, $ra );
		return $ra;
	}

	/** Số người ĐANG KHAI TAY từng bộ phận. Người trôi theo cơ sở không tính — họ không bám tên. */
	public static function dem_khai_bo_phan() {
		$t = VHCC_DB::t( 'nhan_vien' );
		if ( ! VHCC_DB::co_bang( $t ) ) { return array(); }
		global $wpdb;
		$ra = array();
		foreach ( (array) $wpdb->get_results(
			"SELECT bo_phan, COUNT(*) so FROM $t WHERE bo_phan <> '' GROUP BY bo_phan", ARRAY_A ) as $r ) {
			$ra[ trim( (string) $r['bo_phan'] ) ] = (int) $r['so'];
		}
		return $ra;
	}

	/** THÊM một phòng ban. */
	public static function them_bo_phan( $u, $ten ) {
		if ( ! self::co_sua_ho_so( $u ) ) {
			return array( 'ok' => false, 'error' => 'Sửa sơ đồ tổ chức cần vai Kế toán trở lên.' );
		}
		$t = trim( (string) $ten );
		if ( '' === $t ) { return array( 'ok' => false, 'error' => 'Thiếu tên phòng ban.' ); }
		if ( in_array( $t, self::ds_bo_phan(), true ) ) {
			return array( 'ok' => false, 'error' => 'Đã có phòng ban "' . $t . '".' );
		}
		$ds   = get_option( self::BP_DS_O, null );
		$ds   = is_array( $ds ) ? $ds : array_values( (array) self::BP_HAT_GIONG );
		$ds[] = $t;
		self::ghi_ds_bo_phan( $ds );
		self::ghi_nhat_ky_bp( $u, 'them_bo_phan', '', $t );
		return array( 'ok' => true, 'ten' => $t );
	}

	/**
	 * ĐỔI TÊN một phòng ban — mang theo CẢ BA sổ bám vào cái tên ấy.
	 *
	 * @param bool $gop Cho phép tên mới TRÙNG một phòng đang có (tức là GỘP hai phòng làm một).
	 *
	 * ⚠️ GỘP LÀ MỘT VIỆC KHÁC HẲN ĐỔI TÊN, nên phải nói ra ý định bằng `$gop` chứ không để nó
	 *    xảy ra như tác dụng phụ của một lượt gõ nhầm. Gõ "Phòng Kỹ Thuật" vào ô đổi tên của
	 *    "Phòng Kỹ Thuật / CNTT" mà hệ im lặng nhập hai phòng làm một thì người gõ không hề biết
	 *    mình vừa xoá một phòng.
	 */
	public static function doi_ten_bo_phan( $u, $cu, $moi, $gop = false ) {
		/* Đổi tên: Kế toán trở lên, y như mọi việc sửa hồ sơ. GỘP thì cần Admin — nó XOÁ HẲN một
		   phòng, và kéo cả người lẫn luật quyền của phòng ấy đi theo. */
		if ( ! self::co_sua_ho_so( $u ) ) {
			return array( 'ok' => false, 'error' => 'Sửa sơ đồ tổ chức cần vai Kế toán trở lên.' );
		}
		if ( $gop && ! VHCC_Vai::duoc( $u, 'he_thong' ) ) {
			return array( 'ok' => false, 'error' => 'Gộp hai phòng ban cần vai Admin — nó xoá hẳn một phòng.' );
		}
		$a = trim( (string) $cu );
		$b = trim( (string) $moi );
		if ( '' === $a || '' === $b ) { return array( 'ok' => false, 'error' => 'Thiếu tên phòng ban.' ); }
		if ( $a === $b ) { return array( 'ok' => false, 'error' => 'Tên mới trùng tên cũ — chưa đổi gì.' ); }
		$ds = self::ds_bo_phan();
		if ( ! in_array( $a, $ds, true ) ) {
			return array( 'ok' => false, 'error' => 'Không có phòng ban "' . $a . '".' );
		}
		$trung = in_array( $b, $ds, true );
		if ( $trung && ! $gop ) {
			return array( 'ok' => false,
				'error' => 'Đã có phòng ban "' . $b . '". Muốn nhập hai phòng làm một thì bấm Gộp.' );
		}

		/* 1. Sổ người — CHỈ dòng khai tay đúng tên cũ. */
		global $wpdb;
		$t     = VHCC_DB::t( 'nhan_vien' );
		$nguoi = 0;
		if ( VHCC_DB::co_bang( $t ) ) {
			$nguoi = (int) $wpdb->query( $wpdb->prepare(
				"UPDATE $t SET bo_phan=%s WHERE bo_phan=%s", $b, $a ) );
		}

		/* 2. Vai bày lên đầu. Gộp thì HỢP hai danh sách, không đè — mất vai của phòng đích là
		      người phòng ấy mở ô xổ ra thấy gợi ý lạ hẳn, mà chẳng ai đụng vào nó. */
		$ban = self::vai_theo_bo_phan();
		if ( isset( $ban[ $a ] ) ) {
			$hop = isset( $ban[ $b ] ) ? $ban[ $b ] : array();
			foreach ( $ban[ $a ] as $v ) { if ( ! in_array( $v, $hop, true ) ) { $hop[] = $v; } }
			unset( $ban[ $a ] );
			if ( $hop ) { $ban[ $b ] = $hop; }
			update_option( self::VAI_BP_O, $ban );
		}

		/* 3. Luật quyền theo bộ phận.
		   🔴 GỘP MÀ HAI BÊN KHAI NGƯỢC NHAU THÌ GIỮ CỦA PHÒNG ĐÍCH, VÀ NÓI RA. Tự chọn hộ một
		      bên rồi im lặng là đúng kiểu hỏng mà không ai thấy: cả một phòng đổi quyền vì một
		      lượt gộp tên. */
		$lech = array();
		if ( class_exists( 'VHCC_Cong' ) && method_exists( 'VHCC_Cong', 'doi_ten_nhom' ) ) {
			$lech = VHCC_Cong::doi_ten_nhom( 'bp', $a, $b );
		}

		/* 4. Danh sách phòng ban. */
		$ds_o = get_option( self::BP_DS_O, null );
		$ds_o = is_array( $ds_o ) ? $ds_o : array_values( (array) self::BP_HAT_GIONG );
		$ra   = array();
		foreach ( $ds_o as $x ) {
			$x = trim( (string) $x );
			if ( $x === $a ) { $x = $b; }
			if ( '' !== $x && ! in_array( $x, $ra, true ) ) { $ra[] = $x; }
		}
		self::ghi_ds_bo_phan( $ra );
		/* Bộ nhớ trong-lượt của `VHCC_Cong` còn giữ bộ phận CŨ của từng người — không quên thì
		   bảng vẽ lại ngay sau đây tra luật bằng tên cũ, và cả phòng trông như vừa mất quyền. */
		if ( class_exists( 'VHCC_Cong' ) && method_exists( 'VHCC_Cong', 'quen_nhom' ) ) { VHCC_Cong::quen_nhom(); }
		self::ghi_nhat_ky_bp( $u, $trung ? 'gop_bo_phan' : 'doi_ten_bo_phan', $a, $b );

		return array( 'ok' => true, 'cu' => $a, 'moi' => $b, 'gop' => (bool) $trung,
			'nguoi' => $nguoi, 'lech' => $lech );
	}

	/**
	 * XOÁ một phòng ban.
	 *
	 * 🔴 CHỈ XOÁ ĐƯỢC PHÒNG KHÔNG CÒN AI KHAI TAY. Xoá phòng đang có người thì `bo_phan` của họ
	 *    trỏ vào một cái tên không còn trong sơ đồ: bảng vẫn hiện tên ấy (vì `ds_bo_phan()` gom
	 *    cả giá trị lạ còn sót), nhưng khai vai hay khai quyền cho nó thì không được nữa. Muốn bỏ
	 *    một phòng đang có người thì GỘP nó vào phòng khác — người đi theo.
	 */
	public static function xoa_bo_phan( $u, $ten ) {
		if ( ! VHCC_Vai::duoc( $u, 'he_thong' ) ) {
			return array( 'ok' => false, 'error' => 'Xoá phòng ban cần vai Admin.' );
		}
		$t = trim( (string) $ten );
		if ( '' === $t ) { return array( 'ok' => false, 'error' => 'Thiếu tên phòng ban.' ); }
		if ( self::BP_CO_SO === $t ) {
			return array( 'ok' => false, 'error' => 'Không xoá được "' . self::BP_CO_SO
				. '" — mọi người có cơ sở đều tự rơi vào đây khi chưa khai tay.' );
		}
		$dem = self::dem_khai_bo_phan();
		$so  = isset( $dem[ $t ] ) ? (int) $dem[ $t ] : 0;
		if ( $so ) {
			return array( 'ok' => false, 'error' => 'Còn ' . $so . ' người đang khai bộ phận "'
				. $t . '". Chuyển họ đi, hoặc GỘP phòng này vào phòng khác — gộp thì người đi theo.' );
		}
		$ds_o = get_option( self::BP_DS_O, null );
		$ds_o = is_array( $ds_o ) ? $ds_o : array_values( (array) self::BP_HAT_GIONG );
		if ( ! in_array( $t, $ds_o, true ) ) {
			return array( 'ok' => false, 'error' => 'Không có phòng ban "' . $t . '" trong sơ đồ.' );
		}
		$ra = array();
		foreach ( $ds_o as $x ) { if ( trim( (string) $x ) !== $t ) { $ra[] = $x; } }
		self::ghi_ds_bo_phan( $ra );

		/* Vai và luật quyền của phòng vừa xoá cũng phải đi theo — để lại là rác vô hình, và nó
		   sống dậy đúng ngày có người khai lại một phòng trùng tên. */
		$ban = self::vai_theo_bo_phan();
		$co_vai = isset( $ban[ $t ] );
		if ( $co_vai ) { unset( $ban[ $t ] ); update_option( self::VAI_BP_O, $ban ); }
		$co_luat = 0;
		if ( class_exists( 'VHCC_Cong' ) && method_exists( 'VHCC_Cong', 'xoa_nhom' ) ) {
			$co_luat = VHCC_Cong::xoa_nhom( 'bp', $t );
		}
		if ( class_exists( 'VHCC_Cong' ) && method_exists( 'VHCC_Cong', 'quen_nhom' ) ) { VHCC_Cong::quen_nhom(); }
		self::ghi_nhat_ky_bp( $u, 'xoa_bo_phan', $t, '' );
		return array( 'ok' => true, 'ten' => $t, 'vai' => $co_vai, 'luat' => (int) $co_luat );
	}

	/** Một dòng nhật ký cho mọi lượt sửa sơ đồ — sơ đồ đổi là quyền của cả phòng đổi theo. */
	private static function ghi_nhat_ky_bp( $u, $viec, $cu, $moi ) {
		$t = VHCC_DB::t( 'nhat_ky_ho_so' );
		if ( ! VHCC_DB::co_bang( $t ) ) { return; }
		global $wpdb;
		$wpdb->insert( $t, array(
			'luc'     => current_time( 'mysql' ),
			'ma_nv'   => '',
			'ai'      => isset( $u['name'] ) ? (string) $u['name'] : '',
			'tu_coso' => isset( $u['coso'] ) ? (string) $u['coso'] : '',
			'o'       => $viec,
			'cu'      => (string) $cu,
			'moi'     => (string) $moi,
		) );
	}

	/** MẢNG của MỘT cơ sở. '' = cơ sở ấy chưa khai mảng. */
	public static function mang_theo_coso( $coso ) {
		$cs = self::chuan_coso( $coso );
		if ( '' === $cs ) { return ''; }
		$bp = VHCC_Luong::bo_phan_cua( $cs );
		/* 'Chưa xếp' là câu TRẢ LỜI CỦA `bo_phan_cua()` khi không tra ra, không phải một mảng
		   thật. Trả nó ra đây là bịa cho người ta một mảng tên "Chưa xếp". */
		return ( VHCC_Luong::BP_CHUA_XEP === $bp ) ? '' : $bp;
	}

	/**
	 * SUY MẢNG CHO MỘT HỒ SƠ — và NÓI RA CĂN CỨ.
	 *
	 * =============================================================================================
	 * 🔴 ANH THẮNG 13/09/2026: *"nếu đổi mà tự suy, giờ làm sao biết nhân viên đó làm cơ sở đó
	 *    mà suy"*. Câu hỏi ấy trúng ba lỗ hổng của bản 3.67.0 đầu tiên, cả ba đều câm:
	 * =============================================================================================
	 *
	 *  1. CHỈ NHÌN CƠ SỞ ĐẦU TIÊN. Bản ấy suy từ `cua_hang`, mà `chuan_coso()` CẮT Ở DẤU PHẨY
	 *     ĐẦU. Người làm hai nơi — VIVO (Khu vui chơi) và POSH_Q1 (Máy tự động) — chỉ được xét
	 *     theo VIVO. Màn hình ghi "Khu vui chơi" gọn gàng, không có gì cho biết nó vừa bỏ qua
	 *     một nửa.
	 *
	 *  2. CƠ SỞ CHÍNH TRỐNG THÌ COI NHƯ KHÔNG CÓ CƠ SỞ. Ai chỉ có `coso_phu` (chuyện thật: người
	 *     được điều đi hỗ trợ, hồ sơ chưa đặt cơ sở chính) bị xếp vào "chưa xếp", trong khi họ
	 *     CÓ nơi làm hẳn hoi.
	 *
	 *  3. KHÔNG NÓI SUY TỪ ĐÂU. Ô xổ chỉ ghi «theo cơ sở (Khu vui chơi)». Muốn soát thì phải tự
	 *     đi tra cơ sở nào thuộc mảng nào — tức là không ai soát, và một phép suy không soát
	 *     được thì chẳng khác gì một phép đoán.
	 *
	 * =============================================================================================
	 * LUẬT MỚI: MỌI CƠ SỞ NGƯỜI TA LÀM, VÀ LỆCH THÌ KHÔNG ĐOÁN
	 * =============================================================================================
	 * Xét trên `ds_coso_cham()` — mọi cơ sở người ta LÀM, đã bỏ cơ sở "chỉ quản lý". Người quản
	 * một cơ sở mảng khác mà không làm ở đó thì không vì thế mà đổi mảng; ai chỉ đi quản (không
	 * chấm ở đâu cả) thì mới lấy cả cơ sở quản làm căn cứ.
	 *
	 * =============================================================================================
	 * 🔴 MỘT NGƯỜI THUỘC NHIỀU MẢNG LÀ CHUYỆN THƯỜNG, KHÔNG PHẢI LỖI
	 * =============================================================================================
	 * Anh Thắng 13/09/2026: *"Đối với nhân viên là người làm thì họ có thể làm ở 2 mảng nhiều cơ
	 * sở, nhưng đối với quản lý 1 mảng thì mình không lo"*.
	 *
	 * Bản 3.68.0 coi "cơ sở thuộc nhiều mảng" là chỗ hệ chịu thua: trả rỗng, gắn nhãn đỏ «lệch
	 * mảng», và đẩy người ấy vào danh sách việc. SAI, và sai theo kiểu tệ nhất:
	 *
	 *   · Nhân viên quầy chạy giữa Khu vui chơi và Máy tự động là chuyện HÀNG NGÀY. Gắn cờ đỏ cho
	 *     họ nghĩa là gắn cờ cho phần lớn sổ — một danh sách việc dài bằng cả công ty thì không
	 *     phải danh sách việc, nó chỉ là nhiễu.
	 *   · Và nhiễu thì dạy người ta thôi đọc cờ. Đúng bài học của `dat_vai_tro()`: dòng đỏ kêu
	 *     oan làm hỏng luôn dòng đỏ thật.
	 *
	 * Nay: thuộc bao nhiêu mảng thì GHI NHẬN bấy nhiêu, y như một người có nhiều cơ sở. Không cờ,
	 * không bắt chọn tay. Chỉ còn ĐÚNG hai cảnh là thật sự chưa biết — chưa gắn cơ sở nào, và cơ
	 * sở có mà chưa ai khai mảng cho nó.
	 *
	 * Quản lý thì anh Thắng chốt là mỗi người một mảng nên *"không lo"* — hệ không cần luật riêng
	 * cho họ: một mảng thì phép suy này trả đúng một mảng.
	 *
	 * @return array array(
	 *     'dsMang' => CÁC mảng suy ra (rỗng nếu không suy được),
	 *     'coSo'   => các cơ sở đã dùng làm căn cứ,
	 *     'vi'     => câu giải thích ngắn để in thẳng lên màn,
	 * )
	 */
	public static function suy_mang( $hs ) {
		$hs = (array) $hs;
		$ds = self::ds_coso_cham( $hs );
		/* Chỉ đi quản, không chấm ở đâu: vẫn phải có căn cứ, nên lấy cơ sở quản. */
		if ( ! $ds ) { $ds = self::ds_coso_hs( $hs ); }
		if ( ! $ds ) {
			return array( 'dsMang' => array(), 'coSo' => array(),
				'vi' => 'chưa gắn cơ sở nào — phải chọn tay' );
		}
		$thay = array(); $chua = array();
		foreach ( $ds as $cs ) {
			$m = self::mang_theo_coso( $cs );
			if ( '' === $m ) { $chua[] = $cs; continue; }
			if ( ! isset( $thay[ $m ] ) ) { $thay[ $m ] = array(); }
			$thay[ $m ][] = $cs;
		}
		if ( ! $thay ) {
			return array( 'dsMang' => array(), 'coSo' => $ds,
				'vi' => 'cơ sở ' . implode( ', ', $chua ) . ' chưa khai mảng — khai ở màn Cấu hình, '
					. 'hoặc chọn tay' );
		}
		/* Kể ra TỪNG MẢNG kèm cơ sở làm căn cứ: "Khu vui chơi (VIVO) · Máy tự động (POSH_Q1)".
		   Đọc một dòng là soát được, không phải đi tra bảng cơ sở. */
		$ke = array();
		foreach ( $thay as $m => $cs_ds ) { $ke[] = $m . ' (' . implode( ', ', $cs_ds ) . ')'; }
		$vi = 'theo cơ sở: ' . implode( ' · ', $ke );
		if ( $chua ) { $vi .= ' (chưa tính ' . implode( ', ', $chua ) . ': cơ sở ấy chưa khai mảng)'; }
		return array( 'dsMang' => array_keys( $thay ), 'coSo' => $ds, 'vi' => $vi );
	}

	/** BỘ PHẬN suy ra từ cơ sở: có cơ sở thì là khối cơ sở; không có thì chịu, phải khai tay. */
	public static function bo_phan_theo_coso( $coso ) {
		return ( '' !== self::chuan_coso( $coso ) ) ? self::BP_CO_SO : '';
	}

	/**
	 * BỘ PHẬN suy ra cho cả HỒ SƠ — xét MỌI cơ sở, không chỉ cơ sở chính.
	 *
	 * ⚠️ `chuan_coso()` cắt ở dấu phẩy đầu, nên hỏi thẳng `cua_hang` là bỏ sót người chỉ có
	 *    `coso_phu`: họ CÓ nơi làm mà bị xếp vào "chưa xếp".
	 */
	public static function suy_bo_phan( $hs ) {
		$ds = self::ds_coso_hs( (array) $hs );
		return $ds ? self::BP_CO_SO : '';
	}

	/**
	 * MẢNG / BỘ PHẬN THẬT SỰ CỦA MỘT HỒ SƠ — khai tay thắng, không có thì suy từ cơ sở.
	 *
	 * @param array $hs hàng hồ sơ (cần `mang`/`bo_phan`/`cua_hang`).
	 * @return array array( 'mang','boPhan','mangKhai','boPhanKhai','theoCoSo' )
	 *               `theoCoSo` = true khi CẢ HAI đều đang trôi theo cơ sở (chưa ai soát).
	 */
	public static function mang_bo_phan_cua( $hs ) {
		$hs   = (array) $hs;
		$cs   = isset( $hs['cua_hang'] ) ? (string) $hs['cua_hang'] : '';
		$mk   = isset( $hs['mang'] ) ? trim( (string) $hs['mang'] ) : '';
		$bk   = isset( $hs['bo_phan'] ) ? trim( (string) $hs['bo_phan'] ) : '';
		$suy   = self::suy_mang( $hs );
		$ds_mk = self::tach_mang( $mk );
		$ds_hl = $ds_mk ? $ds_mk : $suy['dsMang'];
		return array(
			/* `mang` là chuỗi ĐỂ ĐỌC ("Khu vui chơi + Máy tự động"); `dsMang` là danh sách ĐỂ SO.
			   Lọc và đếm phải dùng `dsMang` — so bằng chuỗi ghép thì người làm hai mảng không
			   khớp với bất kỳ ô lọc nào, và họ biến mất khỏi mọi bộ lọc mà chẳng ai để ý. */
			'mang'       => implode( ' + ', $ds_hl ),
			'dsMang'     => $ds_hl,
			'boPhan'     => ( '' !== $bk ) ? $bk : self::suy_bo_phan( $hs ),
			'mangKhai'   => $mk,
			'dsMangKhai' => $ds_mk,
			'boPhanKhai' => $bk,
			'theoCoSo'   => ( '' === $mk && '' === $bk ),
			/* Chở theo CĂN CỨ để màn hình in thẳng ra. Không có nó thì người đọc phải tự đi tra
			   cơ sở nào thuộc mảng nào — tức là không ai soát, và phép suy không soát được thì
			   chẳng khác gì phép đoán (anh Thắng 13/09/2026). */
			'vi'         => $suy['vi'],
			'canCu'      => $suy['coSo'],
			/* 🔴 DANH SÁCH VIỆC CHỈ CÒN ĐÚNG MỘT CẢNH: không khai tay mà cũng không suy ra nổi
			   mảng nào. Thuộc NHIỀU mảng KHÔNG nằm ở đây — đó là trạng thái hợp lệ của nhân viên
			   chạy giữa hai mảng, gắn cờ cho họ là gắn cờ cho phần lớn sổ. */
			'canChonTay' => ! $ds_hl,
		);
	}

	/** Tách chuỗi mảng đã khai ("A, B") thành danh sách. Lưu giống `coso_phu` — cùng một lối. */
	public static function tach_mang( $chuoi ) {
		$ra = array();
		foreach ( explode( ',', (string) $chuoi ) as $x ) {
			$x = trim( $x );
			if ( '' !== $x && ! in_array( $x, $ra, true ) ) { $ra[] = $x; }
		}
		return $ra;
	}

	/**
	 * ĐẶT MẢNG & BỘ PHẬN cho một người. Chuỗi rỗng = "theo cơ sở" (xoá phần khai tay).
	 *
	 * ⚠️ CÙNG BẬC QUYỀN VỚI ĐỔI VAI TRÒ (`co_sua_ho_so`, Kế toán trở lên). Mảng và bộ phận là
	 *    thứ mà bản sau sẽ BÓ QUYỀN theo; ai sửa được nó thì sau này sửa được phạm vi nhìn thấy
	 *    của người khác. Đặt thấp hơn bây giờ thì bản sau muốn nâng lên đã có người quen tay.
	 *
	 * @return array array( 'ok', 'doi' ) hoặc array( 'ok' => false, 'error' )
	 */
	public static function dat_mang_bo_phan( $u, $ma_nv, $mang, $bo_phan ) {
		global $wpdb;
		if ( ! self::co_sua_ho_so( $u ) ) {
			return array( 'ok' => false, 'error' => 'Đổi mảng / bộ phận cần vai Kế toán trở lên.' );
		}
		$ma = trim( (string) $ma_nv );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu Mã NV.' ); }
		$cu = self::ho_so( $ma );
		if ( ! $cu ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ ' . $ma . '.' ); }

		$m = trim( (string) $mang );
		$b = trim( (string) $bo_phan );
		$m_cu = trim( (string) ( isset( $cu['mang'] ) ? $cu['mang'] : '' ) );
		$b_cu = trim( (string) ( isset( $cu['bo_phan'] ) ? $cu['bo_phan'] : '' ) );
		/* "Không đổi gì" xét TRƯỚC danh sách trắng — cùng bài học với `dat_vai_tro()`: hồ sơ đang
		   mang một giá trị sót từ sổ cũ thì mỗi lần bấm Lưu bảng lại đẻ một dòng đỏ cho một việc
		   không xảy ra, và dòng đỏ kêu oan dạy người ta thôi đọc dòng đỏ. */
		if ( $m === $m_cu && $b === $b_cu ) { return array( 'ok' => true, 'doi' => false ); }

		/* Nhận NHIỀU mảng, ngăn bằng dấu phẩy — một người làm hai mảng là chuyện thường. Chuẩn
		   hoá lại lúc ghi để chuỗi trong sổ luôn cùng một dạng, khỏi sinh hai biến thể của cùng
		   một tổ hợp ("A, B" và "A,B") rồi lọc trượt. */
		$ds_m = self::tach_mang( $m );
		foreach ( $ds_m as $x_m ) {
			/* ⚠️ Chốt bằng danh sách ĐẦY ĐỦ. Dùng `ds_mang()` (đã bỏ mảng ẩn) thì người đang
			   khai tay một mảng vừa bị ẩn bấm Lưu là nhận câu chối cho chính giá trị họ mang. */
			if ( ! in_array( $x_m, self::ds_mang_tat_ca(), true ) ) {
				return array( 'ok' => false, 'error' => $ma . ': mảng "' . $x_m . '" không có trong hệ.' );
			}
		}
		$m = implode( ', ', $ds_m );
		if ( $m === $m_cu && $b === $b_cu ) { return array( 'ok' => true, 'doi' => false ); }
		if ( '' !== $b && ! in_array( $b, self::ds_bo_phan(), true ) ) {
			return array( 'ok' => false, 'error' => $ma . ': bộ phận "' . $b . '" không có trong hệ.' );
		}
		$wpdb->update( VHCC_DB::t( 'nhan_vien' ),
			array( 'mang' => mb_substr( $m, 0, 120 ), 'bo_phan' => mb_substr( $b, 0, 120 ) ),
			array( 'ma_nv' => $ma ) );
		return array( 'ok' => true, 'doi' => true );
	}

	/**
	 * ĐẾM NGƯỜI THEO MẢNG và THEO BỘ PHẬN — dải số của màn nhân sự.
	 *
	 * ⚠️ ĐẾM TRÊN DANH SÁCH ĐÃ LỌC QUYỀN (`$ds`), không tự truy vấn cả sổ. Cửa hàng trưởng thấy
	 *    con số của cả chuỗi là một chỗ rò: nó nói cho biết chuỗi có bao nhiêu người, ở những
	 *    mảng nào — thứ mà chính bảng bên dưới đang giấu đi.
	 */
	public static function dem_mang_bo_phan( $ds ) {
		$mang = array(); $bp = array(); $chua = 0; $tay = 0; $nhieu = 0;
		foreach ( (array) $ds as $r ) {
			$x = self::mang_bo_phan_cua( $r );
			/* 🔴 ĐẾM VÀO TỪNG MẢNG, không đếm vào chuỗi ghép. Người làm hai mảng phải có mặt ở
			   CẢ HAI ô — đó đúng là câu hỏi người ta hỏi dải này ("mảng Khu vui chơi có bao nhiêu
			   người"). Đếm theo chuỗi ghép thì đẻ ra một ô thứ ba tên "A + B" mà bấm vào không
			   lọc được gì, còn hai ô thật thì thiếu người.
			   ⚠️ Hệ quả: tổng của dải có thể LỚN HƠN số người. Đó là đúng, và màn hình nói rõ. */
			$co = ! empty( $x['dsMang'] ) ? $x['dsMang'] : array( '— chưa xếp —' );
			foreach ( $co as $km ) { $mang[ $km ] = ( isset( $mang[ $km ] ) ? $mang[ $km ] : 0 ) + 1; }
			$kb = ( '' !== $x['boPhan'] ) ? $x['boPhan'] : '— chưa xếp —';
			$bp[ $kb ]   = ( isset( $bp[ $kb ] ) ? $bp[ $kb ] : 0 ) + 1;
			if ( count( $co ) > 1 ) { $nhieu++; }
			/* 🔴 HAI CON SỐ PHẢI RỜI NHAU. "Trôi theo cơ sở" chỉ đếm người trôi mà SUY RA ĐƯỢC —
			   ai trôi mà suy không ra thì thuộc con số kia. Để chồng lấn thì câu "đó là trạng
			   thái ĐÚNG cho nhân viên quầy" nói trùm cả mấy người chưa gắn cơ sở, tức là màn
			   hình đang trấn an về đúng mấy trường hợp cần đụng tay. */
			if ( $x['theoCoSo'] && empty( $x['canChonTay'] ) ) { $chua++; }
			/* 🔴 HAI CON SỐ KHÁC NHAU, ĐỪNG GỘP.
			   `theoCoSo` = đang trôi theo cơ sở — phần lớn là ĐÚNG, không phải việc phải làm.
			   `canChonTay` = suy không ra, hệ đang bỏ trống — ĐÂY mới là danh sách việc.
			   Gộp hai cái là con số lúc nào cũng to (199 người trôi), nên không ai nhìn nữa, và
			   mấy người thật sự cần xếp tay chìm nghỉm trong đó. */
			if ( ! empty( $x['canChonTay'] ) ) { $tay++; }
		}
		arsort( $mang ); arsort( $bp );
		return array( 'mang' => $mang, 'boPhan' => $bp, 'theoCoSo' => $chua,
			'canChonTay' => $tay, 'nhieuMang' => $nhieu );
	}


	/**
	 * ĐẾM NGƯỜI THEO VAI TRÒ — và chỉ ra vai nào ĐANG BỊ CHỐI Ở CỬA.
	 *
	 * =============================================================================================
	 * 🔴 VÌ SAO CẦN, VÀ VÌ SAO LÀ BÂY GIỜ.
	 * =============================================================================================
	 * Anh Thắng 13/09/2026 đã chuyển nguồn người dùng sang `ho_so` — cổng PIN nay đọc THẲNG hồ sơ
	 * nhân sự. Chuyện đó đổi hẳn tính chất của cột Vai trò: trước nó chỉ là một ô xổ trên bảng,
	 * nay nó là **thứ quyết định ai vào được cổng**, vì `login()` so vai trong hồ sơ với
	 * `VHCC_Auth::vai_tro_vao()`.
	 *
	 * Hệ quả: một hồ sơ mang chuỗi vai KHÔNG có trong danh sách ấy (vai sót từ sổ cũ, vai gõ sai
	 * chính tả, vai của app khác) là người đó **đăng nhập không được** — mà màn hình chỉ nói
	 * "PIN không đúng hoặc chưa được cấp". Họ đi đổ cho cái PIN, gõ lại mấy lượt rồi thôi. Không
	 * ai lần ra là vì cái tên vai.
	 *
	 * ⚠️ ĐẾM THEO CHUỖI THẬT TRONG SỔ, KHÔNG QUY VỀ MÃ. Quy về mã thì "Kế Toán MTD" và "Kế toán
	 *    cá nhân" gộp hết vào một ô "Kế toán" — đúng về quyền, nhưng che mất đúng thứ đang cần
	 *    nhìn: có bao nhiêu chuỗi vai khác nhau đang nằm trong sổ, và chuỗi nào không vào được.
	 *
	 * @param array $ds danh sách hồ sơ ĐÃ LỌC QUYỀN (cùng lý do với `dem_mang_bo_phan`).
	 * @return array array( 'vai' => [ tên => ['so'=>N,'vao'=>bool] ], 'chan' => số người bị chối )
	 */
	public static function dem_vai( $ds ) {
		$ra = array(); $chan = 0;
		foreach ( (array) $ds as $r ) {
			$t = trim( (string) ( isset( $r['vai_tro'] ) ? $r['vai_tro'] : '' ) );
			$k = ( '' !== $t ) ? $t : '— chưa khai vai —';
			if ( ! isset( $ra[ $k ] ) ) {
				$ra[ $k ] = array( 'so' => 0, 'vao' => self::vai_vao_duoc( $t ) );
			}
			$ra[ $k ]['so']++;
			if ( ! $ra[ $k ]['vao'] ) { $chan++; }
		}
		uasort( $ra, function ( $a, $b ) { return $b['so'] - $a['so']; } );
		return array( 'vai' => $ra, 'chan' => $chan );
	}

	/**
	 * CHUỖI VAI NÀY CÓ QUA ĐƯỢC CỬA KHÔNG — đi ĐÚNG ĐƯỜNG CỔNG ĐI, không tự viết luật.
	 *
	 * 🔴 BÀI HỌC 13/09/2026, MẤT MỘT LƯỢT. Bản đầu của `dem_vai()` tự so chuỗi vai với
	 *    `vai_tro_vao()` bằng `khoa_ten()`. Kết quả: dải đếm tô đỏ vai **"Kế toán"** — một trong
	 *    năm vai DỰNG SẴN của hệ — và báo "3 người không vào được cổng".
	 *
	 *    Thử qua cửa thật thì họ VÀO ĐƯỢC. Vì nguồn `ho_so` chạy mỗi chuỗi vai qua
	 *    `VHCC_NguoiDung::vai_tro_biet()` TRƯỚC đã — hàm ấy quy "Kế toán" → "Kế toán cá nhân",
	 *    "ql" → "Quản lý", "cht" → "Cửa hàng trưởng"… Bỏ qua bước quy đổi là báo oan hàng loạt.
	 *
	 * ⚠️ MÀ BÁO OAN Ở ĐÂY LÀ LOẠI TỆ NHẤT: nó bảo người ta đi sửa vai của mấy chục hồ sơ đang
	 *    chạy tốt. Sửa xong mới là lúc hỏng thật. Dòng đỏ kêu oan không chỉ vô dụng — nó sai
	 *    khiến người ta.
	 *
	 * Nên: quy đổi bằng đúng hàm cổng dùng, rồi mới so với đúng danh sách cổng so.
	 */
	public static function vai_vao_duoc( $tho ) {
		$t = trim( (string) $tho );
		/* Vai TRỐNG không phải bị chối: `users_cua()` hạ nó về 'Nhân viên', bậc thấp nhất. */
		if ( '' === $t ) { return true; }
		if ( ! class_exists( 'VHCC_Auth' ) || ! method_exists( 'VHCC_Auth', 'vai_tro_vao' ) ) { return true; }
		$cho = VHCC_Auth::vai_tro_vao();
		/* Khớp thẳng — vai tự tạo ("Kế Toán MTD") nằm ở đây, `vai_tro_biet()` không biết chúng. */
		if ( in_array( $t, $cho, true ) ) { return true; }
		if ( class_exists( 'VHCC_NguoiDung' ) && method_exists( 'VHCC_NguoiDung', 'vai_tro_biet' ) ) {
			$quy = VHCC_NguoiDung::vai_tro_biet( $t );
			if ( '' !== $quy && in_array( $quy, $cho, true ) ) { return true; }
		}
		return false;
	}


	/* ══════════════════════════════════════════════════════════════════════════════════════════
	 * VAI TRÒ THEO BỘ PHẬN — GỢI Ý, KHÔNG PHẢI BÓ
	 * ══════════════════════════════════════════════════════════════════════════════════════════
	 * Anh Thắng 13/09/2026: *"Chỗ Vai Trò nó sẽ sinh ra khi chọn bộ phận phải không. VD nếu Khối
	 * cơ sở nó sinh ra là nhân viên, cửa hàng trưởng, cửa hàng phó"*.
	 *
	 * =============================================================================================
	 * 🔴 SẮP XẾP LẠI Ô XỔ, TUYỆT ĐỐI KHÔNG XOÁ LỰA CHỌN NÀO
	 * =============================================================================================
	 * Cách làm hiển nhiên — lọc ô xổ chỉ còn vai của bộ phận — là một cái bẫy đã cắn kho này một
	 * lần. Người đang mang một vai KHÔNG thuộc bộ phận vừa chọn thì lựa chọn ấy biến mất, ô xổ
	 * NHẢY VỀ DÒNG ĐẦU, và chỉ cần bấm Lưu một cái là đổi vai của họ — mà không ai định đổi ai.
	 * Đúng chuyện `o_vai()` đã phải chống với vai "Kế Toán MTD", và `dat_vai_tro()` phải chống
	 * lần nữa ở phía lưu.
	 *
	 * Nên luật ở đây là: **đưa vai của bộ phận LÊN ĐẦU** (nhóm riêng), phần còn lại vẫn nằm
	 * nguyên bên dưới. Gợi ý cho nhanh tay, không cắt đường của ai.
	 *
	 * ⚠️ DANH MỤC KHAI ĐƯỢC, KHÔNG GÕ CỨNG. Bên chi phí đã vấp đúng chỗ này — *"Danh sách trước
	 *    đây gõ cứng ở HAI nơi… mà hai nơi gõ cứng là hai nơi có thể lệch nhau"*. Công ty thêm
	 *    một phòng hay một vai thì anh Thắng tự khai, không phải chờ sửa mã.
	 */

	/** Khoá lưu bản đồ bộ phận -> vai. */
	const VAI_BP_O = 'vhcc_vai_bo_phan';

	/**
	 * Hạt giống: đúng MỘT dòng anh Thắng đã nói, không đoán thêm phòng nào.
	 *
	 * 🔴 CÁC PHÒNG KHÁC CỐ Ý ĐỂ TRỐNG. Trống = không gợi ý gì, ô xổ y như cũ — đó là trạng thái
	 *    an toàn. Đoán hộ mười một phòng ban rồi bày lên đầu ô xổ là dạy người khai chọn sai một
	 *    cách tự tin, và sai vai trò thì ra quyền.
	 */
	const VAI_BP_HAT_GIONG = array(
		self::BP_CO_SO => array( 'Nhân viên', 'Cửa hàng trưởng', 'Cửa hàng phó' ),
	);

	/**
	 * GỢI Ý VAI CHO MỘT PHÒNG CHƯA KHAI — và nói rõ đây là GỢI Ý.
	 *
	 * Anh Thắng 13/09/2026 gửi ảnh khối "Vai trò theo bộ phận": 10 trên 12 phòng trống trơn, nên
	 * ô Vai trò của người ở mấy phòng ấy chẳng bày gì lên đầu — khối ấy gần như vô dụng.
	 *
	 * 🔴 VẪN KHÔNG TỰ ĐIỀN. Hàm này chỉ TRẢ VỀ một đề nghị; điền hay không là một lượt bấm của
	 *    người khai, và chỉ điền vào phòng ĐANG TRỐNG — đè lên phòng đã khai là sửa việc người ta
	 *    đã cố ý làm. Đoán hộ rồi bày lên đầu ô xổ là dạy người khai chọn sai một cách tự tin.
	 *
	 * ⚠️ Chỉ trả vai CÓ THẬT trong hệ (`VHCC_Vai::ds_ten()`) — gợi ý một vai không tồn tại thì
	 *    người mang nó gõ đúng PIN vẫn bị chối ở cổng.
	 */
	public static function vai_goi_y_bp( $bo_phan ) {
		$bp = trim( (string) $bo_phan );
		$co = class_exists( 'VHCC_Vai' ) ? (array) VHCC_Vai::ds_ten() : array();
		if ( '' === $bp || ! $co ) { return array(); }
		$de = array( 'Nhân viên', 'Quản lý' );          // mặc định của một phòng văn phòng
		/* Dùng chính khoá so sánh của bảng vai — bỏ dấu, hạ chữ. Tự viết một cái thứ hai ở đây
		   là hai chỗ hiểu "Phòng Kế Toán" khác nhau. */
		$k  = VHCC_Vai::khoa_ten( $bp );
		if ( self::BP_CO_SO === $bp ) {
			$de = array( 'Nhân viên', 'Cửa hàng trưởng', 'Cửa hàng phó' );
		} elseif ( false !== strpos( $k, 'giam doc' ) || false !== strpos( $k, 'ceo' )
			|| false !== strpos( $k, 'ban giam' ) ) {
			$de = array( 'Admin' );
		} elseif ( false !== strpos( $k, 'ke toan' ) || false !== strpos( $k, 'tai chinh' ) ) {
			$de = array( 'Kế toán cá nhân', 'Kế toán NCC', 'Nhân viên' );
		} elseif ( false !== strpos( $k, 'nhan su' ) ) {
			$de = array( 'Kế toán cá nhân', 'Nhân viên', 'Quản lý' );
		}
		$ra = array();
		foreach ( $de as $v ) { if ( in_array( $v, $co, true ) ) { $ra[] = $v; } }
		return $ra;
	}

	/**
	 * ĐIỀN GỢI Ý CHO MỌI PHÒNG ĐANG TRỐNG. Không đụng phòng đã khai.
	 *
	 * @return array array( 'ok', 'so' => số phòng vừa điền, 'ten' => [tên phòng…] )
	 */
	public static function dien_vai_goi_y( $u ) {
		if ( ! self::co_sua_ho_so( $u ) ) {
			return array( 'ok' => false, 'error' => 'Khai vai cho bộ phận cần vai Kế toán trở lên.' );
		}
		$ban = self::vai_theo_bo_phan();
		$ten = array();
		foreach ( self::ds_bo_phan() as $bp ) {
			if ( ! empty( $ban[ $bp ] ) ) { continue; }      // 🔴 đã khai thì KHÔNG đụng
			$de = self::vai_goi_y_bp( $bp );
			if ( ! $de ) { continue; }
			$ban[ $bp ] = $de;
			$ten[]      = $bp;
		}
		if ( $ten ) { update_option( self::VAI_BP_O, $ban ); }
		return array( 'ok' => true, 'so' => count( $ten ), 'ten' => $ten );
	}

	/** Bản đồ đang khai: [ bộ phận => [tên vai, …] ]. */
	public static function vai_theo_bo_phan() {
		/* Đọc thì đừng ghi — cùng lý do với `ds_bo_phan()`. */
		$v = get_option( self::VAI_BP_O, null );
		if ( ! is_array( $v ) ) { $v = self::VAI_BP_HAT_GIONG; }
		$ra = array();
		foreach ( $v as $bp => $ds ) {
			$bp = trim( (string) $bp );
			if ( '' === $bp ) { continue; }
			$sach = array();
			foreach ( (array) $ds as $t ) {
				$t = trim( (string) $t );
				if ( '' !== $t && ! in_array( $t, $sach, true ) ) { $sach[] = $t; }
			}
			if ( $sach ) { $ra[ $bp ] = $sach; }
		}
		return $ra;
	}

	/**
	 * Khai vai cho một bộ phận. Danh sách rỗng = xoá khai, bộ phận ấy thôi gợi ý.
	 *
	 * ⚠️ KHÔNG chối vai chưa có trong hệ. Khai trước rồi tạo vai sau là thứ tự tự nhiên khi dựng
	 *    sơ đồ tổ chức ("Cửa hàng phó" chưa tồn tại lúc anh Thắng nói ra nó). Chối ở đây thì
	 *    người khai phải nhớ làm đúng thứ tự — mà không ai nhớ. Thay vào đó `vai_goi_y()` kê ra
	 *    vai nào khai rồi mà hệ chưa có, ngay trên màn hình.
	 */
	public static function dat_vai_bo_phan( $u, $bo_phan, $ds_vai ) {
		if ( ! self::co_sua_ho_so( $u ) ) {
			return array( 'ok' => false, 'error' => 'Khai vai cho bộ phận cần vai Kế toán trở lên.' );
		}
		$bp = trim( (string) $bo_phan );
		if ( '' === $bp ) { return array( 'ok' => false, 'error' => 'Thiếu tên bộ phận.' ); }
		if ( ! in_array( $bp, self::ds_bo_phan(), true ) ) {
			return array( 'ok' => false, 'error' => 'Bộ phận "' . $bp . '" không có trong hệ.' );
		}
		$sach = array();
		foreach ( (array) $ds_vai as $t ) {
			$t = trim( (string) $t );
			if ( '' !== $t && ! in_array( $t, $sach, true ) ) { $sach[] = $t; }
		}
		$ban = self::vai_theo_bo_phan();
		if ( $sach ) { $ban[ $bp ] = $sach; } else { unset( $ban[ $bp ] ); }
		update_option( self::VAI_BP_O, $ban );
		return array( 'ok' => true, 'so' => count( $sach ) );
	}

	/**
	 * GỢI Ý VAI cho một hồ sơ, theo bộ phận của họ.
	 *
	 * @return array array(
	 *     'boPhan' => bộ phận đang xét ('' nếu chưa xếp),
	 *     'trong'  => vai của bộ phận VÀ hệ đang có — bày lên đầu ô xổ,
	 *     'thieu'  => vai đã khai cho bộ phận mà hệ CHƯA có (kê ra để đi khai, đừng im lặng bỏ),
	 * )
	 */
	public static function vai_goi_y( $hs ) {
		$x  = self::mang_bo_phan_cua( $hs );
		$bp = (string) $x['boPhan'];
		$ra = array( 'boPhan' => $bp, 'trong' => array(), 'thieu' => array() );
		if ( '' === $bp ) { return $ra; }
		$ban = self::vai_theo_bo_phan();
		if ( empty( $ban[ $bp ] ) ) { return $ra; }
		$co = VHCC_Vai::ds_ten();
		foreach ( $ban[ $bp ] as $t ) {
			if ( in_array( $t, $co, true ) ) { $ra['trong'][] = $t; } else { $ra['thieu'][] = $t; }
		}
		return $ra;
	}


	/* ══════════════════════════════════════════════════════════════════════════════════════════
	 * GỘP HAI HỒ SƠ CỦA CÙNG MỘT NGƯỜI
	 * ══════════════════════════════════════════════════════════════════════════════════════════
	 * Anh Thắng 13/09/2026: *"Ghép 2 nhân viên gộp dữ liệu lại, mã nhân viên sẽ chọn 1 mã làm mã
	 * nv, mã kia sẽ bỏ, lấy 1 mã pin, mã khác cũng bỏ nếu khác"*.
	 *
	 * Nút "Ghép với" vốn có CHỈ khai một cặp vào sổ `ma_song_song` — ghi nhận "hai mã là một
	 * người" để các màn cộng gộp lúc hiển thị. Nó KHÔNG dời dữ liệu và KHÔNG xoá hồ sơ nào. Việc
	 * này thì gộp thật.
	 *
	 * =============================================================================================
	 * 🔴 KHÔNG CÓ ĐƯỜNG LÙI — nên XEM TRƯỚC là bắt buộc, không phải tuỳ chọn
	 * =============================================================================================
	 * Gộp là dời `ma_nv` ở HAI MƯƠI bảng rồi xoá một hồ sơ. Sai một bảng là lịch sử của người đó
	 * rơi ra ngoài, mà bảng công vẫn hiện bình thường — chỉ thiếu. Nên hàm này chạy được ở hai
	 * chế độ, và chế độ mặc định là CHỈ ĐẾM.
	 *
	 * =============================================================================================
	 * 🔴 BẢY BẢNG CÓ KHOÁ UNIQUE CHỨA `ma_nv` — ĐÂY LÀ CHỖ MẤT DỮ LIỆU ÂM THẦM
	 * =============================================================================================
	 * `UPDATE … SET ma_nv=<giữ> WHERE ma_nv=<bỏ>` mà đụng khoá unique thì MySQL chối CẢ CÂU (hoặc
	 * chối từng hàng tuỳ chế độ), `$wpdb->query` trả false, và mấy hàng ấy Ở LẠI mã vừa bị xoá —
	 * mồ côi, không màn nào hiện, không dòng nào báo.
	 *
	 * Hai hồ sơ trùng người gần như LUÔN chồng ngày nhau (ảnh anh Thắng gửi: 0024 chấm 01/07→19/07,
	 * 0036 chấm 01/07→13/09 — chồng trọn nửa tháng). Nên đây là ca THẬT, không phải phòng xa.
	 *
	 * Cách xử, khác nhau theo từng bảng và có chủ ý:
	 *   · `cham_cong` — ĐỔI HẬU TỐ, không bỏ hàng nào. Đây là TIỀN CÔNG; bỏ một lượt chấm là bớt
	 *     tiền của người ta. Khoá là (coso,ngay,ma_nv,hau_to) nên đổi `hau_to` là lách được, và
	 *     bảng công sẽ hiện hai lượt trong ngày — anh Thắng nhìn thấy mà tự xử.
	 *     ⚠️ KHÔNG tự trộn giờ (lấy vào sớm nhất / ra muộn nhất). Nghe hợp lý, nhưng đó là một
	 *        QUYẾT ĐỊNH NGHIỆP VỤ, và quyết định ấy làm âm thầm thì không ai soát lại được.
	 *   · Các bảng còn lại — giữ hàng của mã GIỮ, bỏ hàng của mã BỎ, và ĐẾM RA. Mẫu khuôn mặt,
	 *     lịch làm, xin đi trễ trùng ngày: giữ một cái là đủ, nhưng phải nói ra đã bỏ mấy cái.
	 *
	 * @param string $ma_giu mã ở lại.
	 * @param string $ma_bo  mã bị xoá.
	 * @param bool   $lam    false = chỉ đếm và kê (mặc định); true = làm thật.
	 */
	public static function gop_ho_so( $u, $ma_giu, $ma_bo, $lam = false ) {
		global $wpdb;
		/* 🔴 BẬC ADMIN. Gộp XOÁ một hồ sơ và dời lịch sử chấm công — cùng mức nguy hiểm với xoá
		   sạch sổ hồ sơ, nên cùng bậc. Kế toán sửa được hồ sơ, nhưng không xoá được người. */
		if ( ! VHCC_Vai::duoc( $u, 'he_thong' ) ) {
			return array( 'ok' => false, 'error' => 'Gộp hồ sơ xoá một mã và dời cả lịch sử chấm công — chỉ Admin.' );
		}
		$giu = trim( (string) $ma_giu );
		$bo  = trim( (string) $ma_bo );
		if ( '' === $giu || '' === $bo ) { return array( 'ok' => false, 'error' => 'Thiếu một trong hai mã.' ); }
		if ( self::khoa_so( $giu ) === self::khoa_so( $bo ) ) {
			return array( 'ok' => false, 'error' => 'Hai mã giống nhau — không có gì để gộp.' );
		}
		$hs_giu = self::ho_so( $giu );
		$hs_bo  = self::ho_so( $bo );
		if ( ! $hs_giu ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ ' . $giu . '.' ); }
		if ( ! $hs_bo )  { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ ' . $bo . '.' ); }

		$tcc  = VHCC_DB::t( 'cham_cong' );
		$dem  = array();   // tên bảng => ['doi'=>N, 'dung'=>M]
		$dung_cc = array();

		/* ---- 1. CHẤM CÔNG: dời, hàng nào đụng thì đổi hậu tố ---- */
		$trung = VHCC_DB::rows( $wpdb->prepare(
			"SELECT b.id, b.ngay, b.coso, b.hau_to FROM $tcc b"
			. " INNER JOIN $tcc a ON a.coso=b.coso AND a.ngay=b.ngay AND a.hau_to=b.hau_to AND a.ma_nv=%s"
			. " WHERE b.ma_nv=%s", $giu, $bo ) );
		$tong_cc = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $tcc WHERE ma_nv=%s", $bo ) );
		foreach ( (array) $trung as $r ) {
			$dung_cc[] = self::ymd_vn( (string) $r['ngay'] ) . ' · ' . (string) $r['coso'];
		}
		$dem['cham_cong'] = array( 'doi' => $tong_cc, 'dung' => count( $trung ) );

		if ( $lam ) {
			/* Đổi hậu tố TRƯỚC khi dời mã — làm ngược lại là câu UPDATE dời mã đụng khoá ngay. */
			foreach ( (array) $trung as $r ) {
				$ht = (string) $r['hau_to'];
				for ( $i = 2; $i <= 9; $i++ ) {
					$moi_ht = substr( $ht, 0, 2 ) . 'g' . $i;
					$co = $wpdb->get_var( $wpdb->prepare(
						"SELECT 1 FROM $tcc WHERE coso=%s AND ngay=%s AND ma_nv=%s AND hau_to=%s",
						$r['coso'], $r['ngay'], $giu, $moi_ht ) );
					if ( ! $co ) {
						$wpdb->update( $tcc, array( 'hau_to' => $moi_ht ), array( 'id' => (int) $r['id'] ) );
						break;
					}
				}
			}
			/* 🔴 RỒI MỚI DỜI MÃ. Bước đổi hậu tố ở trên chỉ DỌN ĐƯỜNG; quên câu này thì mọi lượt
			   chấm của mã bỏ Ở LẠI một hồ sơ sắp bị xoá — mồ côi, không bảng công nào hiện, mà
			   tổng số hàng vẫn đủ nên phép đếm thô cũng không thấy. Đúng lỗi bản nháp đã dính. */
			$wpdb->query( $wpdb->prepare( "UPDATE $tcc SET ma_nv=%s WHERE ma_nv=%s", $giu, $bo ) );
		}

		/* ---- 2. Mọi bảng khác mang mã: đếm hàng đụng khoá unique ---- */
		foreach ( self::bang_theo_ma() as $ten => $cot_ds ) {
			if ( 'cham_cong' === $ten ) { continue; }
			$t = VHCC_DB::t( $ten );
			if ( ! VHCC_DB::co_bang( $t ) ) { continue; }
			foreach ( $cot_ds as $cot ) {
				$so = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE $cot=%s", $bo ) );
				if ( ! $so ) { continue; }
				if ( ! isset( $dem[ $ten ] ) ) { $dem[ $ten ] = array( 'doi' => 0, 'dung' => 0 ); }
				$dem[ $ten ]['doi'] += $so;
				if ( $lam ) {
					/* Dời từng hàng: đụng khoá thì `update` trả false — bỏ hàng ấy đi và ĐẾM,
					   chứ không để nó ở lại một mã sắp bị xoá. Dời cả cụm bằng một câu UPDATE
					   thì một hàng đụng là CẢ CÂU hỏng, và 36 hàng kia cũng không đi. */
					foreach ( (array) VHCC_DB::rows( $wpdb->prepare( "SELECT id FROM $t WHERE $cot=%s", $bo ) ) as $h ) {
						$ok = $wpdb->update( $t, array( $cot => $giu ), array( 'id' => (int) $h['id'] ) );
						if ( false === $ok ) {
							$wpdb->delete( $t, array( 'id' => (int) $h['id'] ) );
							$dem[ $ten ]['dung']++;
							$dem[ $ten ]['doi']--;
						}
					}
				}
			}
		}

		/* ---- 3. Hai hồ sơ khác nhau ở ô nào ---- */
		$khac = array();
		foreach ( array( 'ho_ten' => 'Họ tên', 'cua_hang' => 'Cơ sở chính', 'sdt' => 'SĐT',
			'cccd' => 'CCCD', 'vai_tro' => 'Vai trò', 'ngay_vao_lam' => 'Ngày vào làm',
			'trang_thai_lam_viec' => 'Trạng thái', 'mang' => 'Mảng', 'bo_phan' => 'Bộ phận' ) as $o => $nhan ) {
			$a = trim( (string) ( isset( $hs_giu[ $o ] ) ? $hs_giu[ $o ] : '' ) );
			$b = trim( (string) ( isset( $hs_bo[ $o ] ) ? $hs_bo[ $o ] : '' ) );
			if ( $a !== $b ) { $khac[] = array( 'o' => $nhan, 'giu' => $a, 'bo' => $b ); }
		}
		/* ⚠️ KHÔNG BAO GIỜ IN PIN RA MÀN. Chỉ nói CÓ khác hay không — ảnh màn hình đi khắp nơi,
		   và kho này đã mất một khoá cầu nối vì đúng một tấm ảnh. */
		$pin_giu = trim( (string) $hs_giu['pin_dang_nhap'] );
		$pin_bo  = trim( (string) $hs_bo['pin_dang_nhap'] );
		$pin = array(
			'giuCo'  => '' !== $pin_giu,
			'boCo'   => '' !== $pin_bo,
			'khac'   => ( $pin_giu !== $pin_bo ),
			/* Mã giữ CHƯA có PIN mà mã bỏ CÓ -> chuyển sang, kẻo gộp xong người ta mất đường vào. */
			'chuyen' => ( '' === $pin_giu && '' !== $pin_bo ),
		);

		if ( ! $lam ) {
			return array( 'ok' => true, 'xemTruoc' => true, 'giu' => $giu, 'bo' => $bo,
				'bang' => $dem, 'dungCC' => $dung_cc, 'khac' => $khac, 'pin' => $pin,
				'tenGiu' => (string) $hs_giu['ho_ten'], 'tenBo' => (string) $hs_bo['ho_ten'] );
		}

		/* ---- 4. PIN rồi mới xoá hồ sơ ---- */
		if ( $pin['chuyen'] ) {
			$wpdb->update( VHCC_DB::t( 'nhan_vien' ), array( 'pin_dang_nhap' => $pin_bo ),
				array( 'ma_nv' => $giu ) );
		}
		$wpdb->delete( VHCC_DB::t( 'nhan_vien' ), array( 'ma_nv' => $bo ) );

		/* Nhật ký: gộp không lùi được, nên ít nhất phải còn dấu vết ai làm, lúc nào, gộp cái gì. */
		$t_nk = VHCC_DB::t( 'nhat_ky_ho_so' );
		if ( VHCC_DB::co_bang( $t_nk ) ) {
			$wpdb->insert( $t_nk, array(
				'luc'     => current_time( 'mysql' ),
				'ma_nv'   => $giu,
				'ai'      => isset( $u['name'] ) ? (string) $u['name'] : '',
				'tu_coso' => self::chuan_coso( (string) $hs_bo['cua_hang'] ),
				'o'       => 'gop_ho_so',
				'cu'      => mb_substr( $bo . ' · ' . (string) $hs_bo['ho_ten'], 0, 255 ),
				'moi'     => mb_substr( $giu . ' · dời ' . (int) $dem['cham_cong']['doi'] . ' lượt chấm'
					. ( $dung_cc ? ', ' . count( $dung_cc ) . ' lượt trùng ngày đổi hậu tố' : '' ), 0, 255 ),
			) );
		}
		return array( 'ok' => true, 'giu' => $giu, 'bo' => $bo, 'bang' => $dem,
			'dungCC' => $dung_cc, 'pinChuyen' => ! empty( $pin['chuyen'] ) );
	}

	/** 'YYYY-MM-DD' -> 'dd/mm/YYYY' để in ra màn. */
	private static function ymd_vn( $s ) {
		return preg_match( '/^(\d{4})-(\d{2})-(\d{2})/', (string) $s, $m ) ? $m[3] . '/' . $m[2] . '/' . $m[1] : (string) $s;
	}

	public static function dat_vai_tro( $u, $ma_nv, $vai ) {
		global $wpdb;
		if ( ! self::co_sua_ho_so( $u ) ) {
			return array( 'ok' => false, 'error' => 'Đổi vai trò cần vai Kế toán trở lên.' );
		}
		$ma  = trim( (string) $ma_nv );
		$vai = trim( (string) $vai );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu Mã NV.' ); }
		$cu = self::ho_so( $ma );
		if ( ! $cu ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ ' . $ma . '.' ); }

		/* =====================================================================================
		 * 🔴 "KHÔNG ĐỔI GÌ" PHẢI XÉT TRƯỚC MỌI CHỐT KHÁC, KỂ CẢ DANH SÁCH TRẮNG.
		 * =====================================================================================
		 * Anh Thắng 28/08/2026, ảnh màn nhân sự sau một lần bấm Lưu bảng:
		 *     Đã lưu 2 ô quyền vào trang.
		 *     MNKT4CTY0001: Vai trò "Kế Toán MTD" không có trong hệ.
		 *     Hệ ghế: đã đẩy/gỡ 1 người.
		 * Anh không hề định đổi vai ai. Hồ sơ ấy ĐANG mang chuỗi "Kế Toán MTD" — một vai còn
		 * sót từ dữ liệu cũ, chưa khai vào hệ. Ô xổ cố ý giữ nguyên chuỗi ấy làm lựa chọn đang
		 * chọn (xem `VHCC_TrangNS::o_vai()`), vì thả nó ra là ô tự nhảy về dòng đầu và một cú
		 * bấm Lưu đổi vai cả trang. Nhưng lúc lưu, chuỗi ấy gửi lên và chốt danh sách trắng
		 * chối nó — nên MỖI LẦN bấm Lưu bảng lại đẻ ra một dòng đỏ cho một việc không xảy ra.
		 *
		 * ⚠️ DÒNG ĐỎ KÊU OAN LÀ THỨ DẠY NGƯỜI TA THÔI ĐỌC DÒNG ĐỎ. Trong 400 nhân sự còn nhiều
		 *    vai sót như vậy; để nguyên thì mỗi lần lưu là mấy chục dòng đỏ vô nghĩa, và ngày
		 *    có một dòng đỏ THẬT thì nó nằm lẫn trong đám ấy.
		 *
		 * Danh sách trắng vẫn giữ nguyên hiệu lực cho mọi lần ĐỔI THẬT: gửi lên một chuỗi lạ
		 * KHÁC vai đang có thì vẫn bị chối ở ngay dưới đây.
		 */
		if ( trim( (string) $cu['vai_tro'] ) === $vai ) { return array( 'ok' => true, 'doi' => false ); }

		/* 🔴 DANH SÁCH TRẮNG PHẢI LÀ `VHCC_Vai::ds_ten()`, KHÔNG PHẢI `VHCC_Auth::VAI_TRO_TAT_CA`.
		   Hằng số kia CỐ ĐỊNH, không bao giờ biết tới vai tự tạo — nghĩa là khai một vai mới ở
		   "Bảng vai trò" ("Kế Toán MTD"…) xong thì KHÔNG BAO GIỜ gán được cho ai, vì đúng chỗ
		   gán lại chối nó là "lạ". Anh Thắng 28/08/2026 tạo vai "Kế Toán MTD" xong bấm Lưu bảng
		   vẫn ăn đúng câu "không có trong hệ" — `ds_ten()` gộp cả `VAI_TRO_TAT_CA` lẫn vai tự
		   tạo nên vẫn chối được chuỗi thật sự lạ, chỉ khác là không còn chối nhầm vai vừa khai. */
		if ( ! in_array( $vai, VHCC_Vai::ds_ten(), true ) ) {
			return array( 'ok' => false, 'error' => 'Vai trò "' . $vai . '" không có trong hệ.' );
		}
		if ( ! self::co_quyen_coso( $u, $cu['cua_hang'] ) ) {
			return array( 'ok' => false, 'error' => 'Hồ sơ này không thuộc cơ sở bạn phụ trách.' );
		}

		$bac_toi = VHCC_Vai::bac( $u );
		/* Chốt 3 trước hai chốt kia: câu chối của nó nói đúng chuyện đang xảy ra, còn hai chốt
		   kia sẽ nói nhầm thành "vai cao hơn bậc của bạn" khi người ta tự sửa chính mình. */
		$ma_toi = trim( (string) ( isset( $u['ma_nv'] ) ? $u['ma_nv'] : '' ) );
		if ( '' !== $ma_toi && $ma_toi === $ma ) {
			return array( 'ok' => false, 'error' => 'Không tự đổi vai trò của chính mình được — '
				. 'nhờ một Admin khác đổi giúp.' );
		}
		if ( VHCC_Vai::bac( array( 'role' => $vai ) ) > $bac_toi ) {
			return array( 'ok' => false, 'error' => 'Không đặt được vai cao hơn vai của chính mình ('
				. VHCC_Vai::ten( $u ) . ').' );
		}
		if ( VHCC_Vai::bac( array( 'role' => (string) $cu['vai_tro'] ) ) > $bac_toi ) {
			return array( 'ok' => false, 'error' => trim( (string) $cu['ho_ten'] ) . ' đang mang vai '
				. VHCC_Vai::ten( array( 'role' => (string) $cu['vai_tro'] ) )
				. ' — cao hơn vai của bạn, nên không đổi được.' );
		}

		/* ⛔ Chốt "không đổi thì thôi" từng nằm ở ĐÂY. Nay nó đứng trên đầu hàm, trước danh sách
		   trắng — để lại một bản thứ hai ở đây là mã chết: mọi lối tới dòng này đều đã qua bản
		   kia rồi. */
		$ok = $wpdb->update( VHCC_DB::t( 'nhan_vien' ),
			array( 'vai_tro' => $vai, 'cap_nhat' => current_time( 'mysql' ) ),
			array( 'ma_nv' => $ma ) );
		return ( false === $ok )
			? array( 'ok' => false, 'error' => 'MySQL: ' . $wpdb->last_error )
			: array( 'ok' => true, 'doi' => true );
	}

	/**
	 * CHUYỂN MỘT NGƯỜI SANG CƠ SỞ KHÁC — và RESET quyền riêng của họ về mặc định.
	 *
	 * Anh Thắng 27/08/2026: *"Điều chỉnh bạn thuộc cơ sở nào nên bạn chuyển, khi chuyển quyền
	 * hạn sẽ reset lại mặc định"*.
	 *
	 * 🔴 CHUYỂN CƠ SỞ LÀ VIỆC NẶNG, KHÔNG PHẢI SỬA MỘT Ô. Cửa hàng nào trong hồ sơ quyết định
	 * công và lương của người ấy tính về đâu — nên chốt đúng bằng chốt của `luu_ho_so()`:
	 * Quản lý trở lên, và phải phụ trách CẢ HAI cơ sở. Chỉ phụ trách cơ sở đích thôi là đủ để
	 * "hút" người của cơ sở khác về mình.
	 *
	 * ⚠️ RESET NGOẠI LỆ QUYỀN, KHÔNG RESET VAI. Vai là thứ khai có chủ ý và không dính cơ sở;
	 *    ngoại lệ mở/khoá từng trang thì khai theo hoàn cảnh ở cơ sở cũ — xem `VHCC_Cong::xoa_nguoi()`.
	 * ⚠️ Gác `method_exists` cùng hàm với lời gọi (luật `tools/test/kiem-goi-cheo.php`).
	 */
	public static function dat_co_so( $u, $ma_nv, $coso ) {
		global $wpdb;
		/* 🔴 MỘT CHỐT, KHÔNG HAI. Bản đầu gác cả `co_sua_ho_so` (quyền `ho_so`, bậc 4) LẪN
		   `co_quan_tri_nv` (quyền `ngoai_coso`, bậc 3) — trông như phòng thủ hai tầng, nhưng
		   bậc 4 đã CAO HƠN bậc 3, nên không tồn tại vai nào qua được chốt trên mà trượt chốt
		   dưới. Chốt thứ hai là MÃ CHẾT: không bao giờ chạy, và câu lỗi "cần Quản lý" của nó
		   không bao giờ hiện ra cho ai. Phá thử phát hiện đúng chỗ này — bỏ nó đi mà bộ thử
		   vẫn xanh, vì nó vốn chưa từng chặn ai.
		   Giữ đúng chốt CHẶT HƠN (`ho_so`), và có phép thử canh khoảng cách hai bậc ấy: hạ
		   `ho_so` xuống ngang hay thấp hơn `ngoai_coso` là câu chuyện khác, phải biết ngay. */
		if ( ! self::co_sua_ho_so( $u ) ) {
			return array( 'ok' => false, 'error' => 'Chuyển cơ sở là chuyển cả công và lương giữa hai '
				. 'cửa hàng — cần vai Kế toán trở lên.' );
		}
		$ma  = trim( (string) $ma_nv );
		$moi = self::chuan_coso( $coso );
		if ( '' === $ma )  { return array( 'ok' => false, 'error' => 'Thiếu Mã NV.' ); }
		if ( '' === $moi ) { return array( 'ok' => false, 'error' => 'Chưa chọn cơ sở đích.' ); }
		$cu_hs = self::ho_so( $ma );
		if ( ! $cu_hs ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ ' . $ma . '.' ); }

		$cu = self::chuan_coso( $cu_hs['cua_hang'] );
		if ( strtolower( $cu ) === strtolower( $moi ) ) {
			return array( 'ok' => true, 'doi' => false, 'go' => 0 );
		}
		/* Phải phụ trách CẢ HAI. Thiếu vế "cơ sở cũ" là mở đường hút người của cơ sở khác về
		   mình mà cơ sở kia không hay biết. */
		if ( '' !== $cu && ! self::co_quyen_coso( $u, $cu ) ) {
			return array( 'ok' => false, 'error' => 'Người này đang thuộc ' . $cu
				. ' — cơ sở bạn không phụ trách.' );
		}
		if ( ! self::co_quyen_coso( $u, $moi ) ) {
			return array( 'ok' => false, 'error' => 'Bạn không phụ trách cơ sở "' . $moi . '".' );
		}

		$ok = $wpdb->update( VHCC_DB::t( 'nhan_vien' ),
			array( 'cua_hang' => $moi, 'cap_nhat' => current_time( 'mysql' ) ),
			array( 'ma_nv' => $ma ) );
		if ( false === $ok ) {
			return array( 'ok' => false, 'error' => 'MySQL: ' . $wpdb->last_error );
		}

		/* 🔴 RESET QUYỀN RIÊNG. Ngoại lệ khai theo hoàn cảnh ở cơ sở CŨ; sang cơ sở mới thì hoàn
		   cảnh ấy hết, nhưng cái ngoại lệ thì ở lại — âm thầm, và không ai ở cơ sở mới biết. */
		$go = 0;
		if ( class_exists( 'VHCC_Cong' ) && method_exists( 'VHCC_Cong', 'xoa_nguoi' ) ) {
			$go = (int) VHCC_Cong::xoa_nguoi( $ma );
		}
		return array( 'ok' => true, 'doi' => true, 'tu' => $cu, 'den' => $moi, 'go' => $go );
	}

	/**
	 * ĐẶT DANH SÁCH CƠ SỞ CHO MỘT NGƯỜI — tích cơ sở nào là làm việc VÀ quản ở đó.
	 *
	 * Anh Thắng 31/08/2026: *"thay vì cửa hàng trưởng làm ở 1 cơ sở đó, tích chọn quản lý các cơ
	 * sở khác, thì có thể quản lý các nhân viên ở các cơ sở khác"*, và chốt: **một ô chung**.
	 *
	 * 🔴 MỘT Ô, HAI NGHĨA, VÀ ĐÓ LÀ Ý ĐỊNH. Cơ sở tích ở đây vừa là nơi người ta LÀM (công của
	 *    họ nằm ở bảng cơ sở ấy) vừa là phạm vi họ QUẢN (nếu vai đủ bậc). Nhân viên tích 2 cơ sở
	 *    thì chỉ là làm ở 2 nơi — họ không có `cong_coso` nên chẳng quản được gì. Cửa hàng
	 *    trưởng tích 3 cơ sở thì quản người ở cả 3. Quyền đi theo VAI, phạm vi đi theo ô này.
	 *
	 * 🔴 PHẢI PHỤ TRÁCH CẢ CƠ SỞ CŨ LẪN CƠ SỞ MỚI. Thiếu vế "cũ" là mở đường hút người của cơ sở
	 *    khác về mình mà bên kia không hay biết; thiếu vế "mới" là đẩy người sang một cơ sở mình
	 *    không có trách nhiệm gì. Kiểm TỪNG cơ sở bị thêm và TỪNG cơ sở bị bỏ, không kiểm cả
	 *    danh sách một lượt — người ta thường chỉ sửa một ô trong năm.
	 *
	 * ⚠️ RESET QUYỀN RIÊNG khi cơ sở đổi, y như `dat_co_so()` cũ: ngoại lệ khai theo hoàn cảnh ở
	 *    cơ sở cũ mà theo người sang cơ sở mới thì không ai ở đó biết nó tồn tại.
	 *
	 * 🔴 CƠ SỞ CHÍNH ĐỔI ĐƯỢC — `$chinh`. Anh Thắng 09/09/2026: *"làm sao để chuyển đổi cơ sở
	 *    chính và cơ sở phụ"*. Trước bản này KHÔNG có đường nào: lưới ô tích gửi tên cơ sở lên
	 *    theo THỨ TỰ VẼ (đã `sort()` theo bảng chữ cái), nên `cua_hang` luôn là cơ sở đứng đầu
	 *    bảng chữ cái, và khối "không đổi gì thì thôi" bên dưới so theo TẬP HỢP nên kéo lại thứ
	 *    tự cũng không ghi. Người tích `JP_HCM` + `VP_KH-HCM` mãi mãi có `JP_HCM` là cơ sở chính.
	 *
	 * ⚠️ ĐỔI CƠ SỞ CHÍNH **KHÔNG** RESET QUYỀN RIÊNG và không phải "chuyển cơ sở". Người ấy vẫn
	 *    làm ở đủ những cơ sở cũ — chỉ đổi cơ sở nào được CHỌN SẴN lúc chấm công (và cơ sở nào
	 *    đứng ở cột `cua_hang` cho mấy phép gom theo một tên). Xoá ngoại lệ quyền của họ vì một
	 *    lượt đổi mặc định là phạt người ta cho một việc không ai coi là chuyển cửa hàng.
	 *
	 * @param array  $ds    Danh sách cơ sở (đã tích). Rỗng = thôi làm ở đâu cả.
	 * @param string $chinh Cơ sở muốn đặt làm CHÍNH (`cua_hang`). Rỗng, hoặc tên không nằm trong
	 *                      `$ds`, thì giữ nguyên luật cũ: cơ sở đầu danh sách.
	 * @param array|null $ds_ql Cơ sở đặt "CHỈ QUẢN LÝ — không chấm công" (xem `ds_coso_ql()`).
	 *                      `null` = lượt gửi không nói gì về cờ này, giữ nguyên cờ đang có.
	 * @return array `ok` · `doi`(bool) · `doiChinh`(bool) · `doiQL`(bool) · `tu` · `den` · `go`,
	 *               hoặc `error`.
	 */
	public static function dat_ds_coso( $u, $ma_nv, $ds, $chinh = '', $ds_ql = null, $ds_quan = null ) {
		/* 🔴 XOÁ BỘ NHỚ ĐỆM CẢ TRƯỚC LẪN SAU.
		   Trước: hàm này tự hỏi quyền mấy lần, và mỗi lượt hỏi lại nạp bản CŨ vào bộ nhớ.
		   Sau (`shutdown` của chính hàm, xem `$xoa_sau`): nạp trước rồi ghi sau thì bản vừa nạp
		   là bản cũ — màn vẽ ngay sau lượt Lưu sẽ nói ngược lại với thứ vừa lưu. */
		self::quen_coso_quan();
		$xoa_sau = new class {
			public function __destruct() { VHCC_NhanSu::quen_coso_quan(); }
		};
		unset( $xoa_sau );   // ⚠️ chỉ để soát mã thấy nó có dùng; bản thân đối tượng sống tới cuối hàm
		global $wpdb;
		if ( ! self::co_sua_ho_so( $u ) ) {
			return array( 'ok' => false, 'error' => 'Đổi cơ sở là chuyển cả công và lương giữa các '
				. 'cửa hàng — cần vai Kế toán trở lên.' );
		}
		$ma = trim( (string) $ma_nv );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu Mã NV.' ); }
		$cu_hs = self::ho_so( $ma );
		if ( ! $cu_hs ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ ' . $ma . '.' ); }

		$moi = array();
		$da  = array();
		foreach ( (array) $ds as $x ) {
			foreach ( explode( ',', (string) $x ) as $m ) {
				$m = self::chuan_coso( $m );
				if ( '' === $m ) { continue; }
				$k = self::chu_thuong( $m );
				if ( isset( $da[ $k ] ) ) { continue; }
				$da[ $k ] = 1;
				$moi[]    = $m;
			}
		}
		$cu = self::ds_coso_hs( $cu_hs );

		/* CƠ SỞ CHÍNH ĐƯỢC CHỈ ĐỊNH thì đưa nó lên ĐẦU `$moi` — cột `cua_hang` bên dưới lấy phần
		   tử đầu. Tên không có trong danh sách vừa tích thì BỎ QUA, không báo lỗi: bỏ tích một cơ
		   sở mà quên di cái nút tròn là chuyện thường, và chối cả lượt lưu vì thế là chối oan. */
		$chinh   = self::chuan_coso( $chinh );
		$chi_dinh = false;
		if ( '' !== $chinh ) {
			$k_ch = self::chu_thuong( $chinh );
			foreach ( $moi as $i_ch => $x_ch ) {
				if ( self::chu_thuong( $x_ch ) !== $k_ch ) { continue; }
				unset( $moi[ $i_ch ] );
				$moi      = array_merge( array( $x_ch ), array_values( $moi ) );
				$chi_dinh = true;
				break;
			}
		}

		/* ---- CỜ "CHỈ QUẢN LÝ — KHÔNG CHẤM CÔNG" (xem `ds_coso_ql()`) ----
		   `null` = lượt gửi không nói gì (đường nạp .csv, bản kéo sheet, lời gọi cũ) -> giữ
		   nguyên cờ đang có. Cả hai đường đều LỌC LẠI theo danh sách vừa tích: cờ sót lại của
		   một cơ sở đã bỏ tích mà còn tính thì lượt sau tích lại cơ sở ấy là nó lặng lẽ không
		   chấm công được. */
		$co_moi = array();
		foreach ( $moi as $x_c ) { $co_moi[ self::chu_thuong( $x_c ) ] = $x_c; }
		$ql_nguon = ( null === $ds_ql ) ? self::ds_coso_ql( $cu_hs ) : (array) $ds_ql;
		$ql_moi   = array();
		foreach ( $ql_nguon as $x_q ) {
			foreach ( explode( ',', (string) $x_q ) as $m_q ) {
				$m_q = self::chuan_coso( $m_q );
				if ( '' === $m_q ) { continue; }
				$k_q = self::chu_thuong( $m_q );
				if ( ! isset( $co_moi[ $k_q ] ) || isset( $ql_moi[ $k_q ] ) ) { continue; }
				$ql_moi[ $k_q ] = $co_moi[ $k_q ];
			}
		}
		/* 🔴 CƠ SỞ CHÍNH KHÔNG ĐƯỢC ĐẶT "CHỈ QUẢN LÝ". Cơ sở chính là cơ sở TRẠM CHỌN SẴN (nó đi
		   vào thẻ phiên rồi thành `coSoMacDinh`), và lượt chấm không kèm ô chọn ghi thẳng vào
		   đó. Cho phép thì ô xổ chọn sẵn một cơ sở không có trong danh sách, còn lượt chấm im
		   lặng ghi vào đúng cơ sở vừa bị loại — hỏng cả hai đầu. Chối thẳng, và chỉ ra cách
		   làm: bấm nút tròn "chính" cho một cơ sở có chấm công. */
		if ( isset( $moi[0] ) && isset( $ql_moi[ self::chu_thuong( $moi[0] ) ] ) ) {
			return array( 'ok' => false,
				'error' => 'Không đặt được "chỉ quản lý" cho ' . $moi[0] . ' vì đó đang là CƠ SỞ '
					. 'CHÍNH — cơ sở trạm chọn sẵn lúc chấm công. Bấm nút tròn "chính" cho một cơ '
					. 'sở người này CÓ chấm công, rồi lưu lại.' );
		}
		$ql_moi = array_values( $ql_moi );

		/* ---- CƠ SỞ QUẢN LÝ (xem `ds_coso_quan()`) ----
		   `null` = lượt gửi không nói gì -> giữ nguyên. Lọc lại theo danh sách vừa tích, cùng
		   một luật với cờ trên. KHÔNG chối khi trùng với `coso_ql`: trùng là thừa, không phải
		   sai, và `ds_coso_quan()` gộp hai danh sách nên kết quả vẫn đúng. */
		$qn_nguon = ( null === $ds_quan ) ? self::ds_coso_quan_tho( $cu_hs ) : (array) $ds_quan;
		$qn_moi   = array();
		foreach ( $qn_nguon as $x_n ) {
			foreach ( explode( ',', (string) $x_n ) as $m_n ) {
				$m_n = self::chuan_coso( $m_n );
				if ( '' === $m_n ) { continue; }
				$k_n = self::chu_thuong( $m_n );
				if ( ! isset( $co_moi[ $k_n ] ) || isset( $qn_moi[ $k_n ] ) ) { continue; }
				$qn_moi[ $k_n ] = $co_moi[ $k_n ];
			}
		}
		$qn_moi = array_values( $qn_moi );
		$sx_ql_cu  = array_map( array( __CLASS__, 'chu_thuong' ), self::ds_coso_ql( $cu_hs ) );
		$sx_ql_moi = array_map( array( __CLASS__, 'chu_thuong' ), $ql_moi );
		sort( $sx_ql_cu );
		sort( $sx_ql_moi );
		$doi_ql = ( $sx_ql_cu !== $sx_ql_moi );

		/* Không đổi gì thì thôi — so theo TẬP HỢP, không theo thứ tự: kéo lại thứ tự tích không
		   phải là chuyển cơ sở của ai. */
		$sx_cu = array_map( array( __CLASS__, 'chu_thuong' ), $cu );
		$sx_moi = array_map( array( __CLASS__, 'chu_thuong' ), $moi );
		sort( $sx_cu );
		sort( $sx_moi );
		if ( $sx_cu === $sx_moi ) {
			/* 🔴 TẬP HỢP Y NGUYÊN NHƯNG CƠ SỞ CHÍNH KHÁC = VẪN PHẢI GHI. Đây chính là đường
			   "chuyển đổi cơ sở chính ↔ cơ sở phụ": không ai bị thêm hay bớt cơ sở nào, chỉ đổi
			   cái đứng đầu. Trả về sớm ở đây (như trước bản 3.62.0) là nút tròn bấm xong không
			   ăn, và màn hình báo "Không có ô nào đổi". */
			/* ⚠️ CHỈ KHI CƠ SỞ CHÍNH ĐƯỢC **CHỈ ĐỊNH** (`$chi_dinh`). Không có `$chinh` thì luật
			   cũ còn nguyên: *"kéo lại thứ tự tích không phải là chuyển cơ sở của ai"*. Bỏ vế
			   này là mọi đường ghi không truyền `$chinh` (lượt nạp, đường gọi mới về sau) âm
			   thầm đẩy cơ sở chính về phần tử đầu của danh sách nó tình cờ gửi lên. */
			$ch_cu = isset( $cu[0] ) ? self::chu_thuong( $cu[0] ) : '';
			$ch_moi = isset( $moi[0] ) ? self::chu_thuong( $moi[0] ) : '';
			$doi_chinh = ( $chi_dinh && $ch_cu !== $ch_moi );
			/* 🔴 CỜ "CHỈ QUẢN LÝ" ĐỔI CŨNG PHẢI GHI, dù tập hợp cơ sở y nguyên — đây là đường
			   chính của việc này: không thêm không bớt cơ sở nào, chỉ nói cơ sở nào thôi chấm
			   công. Thiếu vế `$doi_ql` là tích ô xong bấm Lưu thấy "Không có ô nào đổi". */
			/* 🔴 CỜ "QUẢN LÝ" ĐỔI CŨNG PHẢI GHI — cùng lý do với `$doi_ql` ngay trên, và đây
			   là đường CHÍNH của cột `coso_quan`: không thêm không bớt cơ sở nào, chỉ nói cơ
			   sở nào người này quản. Thiếu vế này thì tích/bỏ tích ô "quản lý" bấm Lưu xong
			   thấy "Không có ô nào đổi" — và quyền không đổi thật. */
			$sx_qn_cu  = array_map( array( __CLASS__, 'chu_thuong' ), self::ds_coso_quan_tho( $cu_hs ) );
			$sx_qn_moi = array_map( array( __CLASS__, 'chu_thuong' ), $qn_moi );
			sort( $sx_qn_cu );
			sort( $sx_qn_moi );
			$doi_qn = ( $sx_qn_cu !== $sx_qn_moi );

			if ( ! $doi_chinh && ! $doi_ql && ! $doi_qn ) {
				return array( 'ok' => true, 'doi' => false, 'go' => 0 );
			}
			/* Phụ trách CẢ hai đầu — cùng luật với thêm/bỏ cơ sở: cơ sở chính là cơ sở mặc định
			   của người ta lúc chấm, đổi hộ ở một nơi mình không phụ trách là đổi sau lưng. */
			$soat_q = $doi_chinh ? array( $cu[0], $moi[0] ) : array();
			/* Cờ "chỉ quản lý" cũng là đụng vào vế chấm công của MỘT cơ sở cụ thể — phải phụ
			   trách đúng cơ sở bị đụng. Soát cả cơ sở vừa được đặt cờ lẫn cơ sở vừa được bỏ cờ. */
			foreach ( array_merge( array_diff( $sx_ql_moi, $sx_ql_cu ),
				array_diff( $sx_ql_cu, $sx_ql_moi ) ) as $x_ql ) {
				$soat_q[] = $x_ql;
			}
			/* Cờ "quản lý" cũng vậy: phát hay thu quyền quản một cơ sở thì phải đang phụ trách
			   đúng cơ sở ấy — không thì đây là đường tự phát quyền cho mình ở chỗ người khác. */
			foreach ( array_merge( array_diff( $sx_qn_moi, $sx_qn_cu ),
				array_diff( $sx_qn_cu, $sx_qn_moi ) ) as $x_qn ) {
				$soat_q[] = $x_qn;
			}
			foreach ( $soat_q as $x_q ) {
				if ( self::co_quyen_coso( $u, $x_q ) ) { continue; }
				return array( 'ok' => false,
					'error' => 'Cơ sở "' . $x_q . '" — bạn không phụ trách nên không đổi được.' );
			}
			$dat_c = $moi;
			$ok_c  = $wpdb->update( VHCC_DB::t( 'nhan_vien' ), array(
				'cua_hang' => array_shift( $dat_c ),
				'coso_phu' => implode( ', ', $dat_c ),
				'coso_ql'  => implode( ', ', $ql_moi ),
				'coso_quan' => implode( ', ', $qn_moi ),
				'cap_nhat' => current_time( 'mysql' ),
			), array( 'ma_nv' => $ma ) );
		self::quen_coso_quan();   // bản vừa nhớ là bản TRƯỚC lượt ghi này
			if ( false === $ok_c ) {
				return array( 'ok' => false, 'error' => 'MySQL: ' . $wpdb->last_error );
			}
			return array( 'ok' => true, 'doi' => false, 'doiChinh' => $doi_chinh,
				'doiQL' => $doi_ql, 'go' => 0,
				'tu' => $cu[0], 'den' => $moi[0], 'ql' => $ql_moi );
		}

		foreach ( array_diff( $sx_moi, $sx_cu ) as $them ) {
			if ( ! self::co_quyen_coso( $u, $them ) ) {
				return array( 'ok' => false,
					'error' => 'Bạn không phụ trách cơ sở "' . $them . '" nên không thêm vào được.' );
			}
		}
		foreach ( array_diff( $sx_cu, $sx_moi ) as $bo ) {
			if ( ! self::co_quyen_coso( $u, $bo ) ) {
				return array( 'ok' => false,
					'error' => 'Người này đang thuộc ' . $bo . ' — cơ sở bạn không phụ trách.' );
			}
		}

		/* Rải vào hai cột y như `VHCC_Web::luu_ho_so()`: cơ sở đầu vào `cua_hang`, còn lại vào
		   `coso_phu`. Một hình dạng lưu duy nhất cho cả hệ. */
		$dat = $moi;
		$ok  = $wpdb->update( VHCC_DB::t( 'nhan_vien' ), array(
			'cua_hang' => $dat ? array_shift( $dat ) : '',
			'coso_phu' => implode( ', ', $dat ),
			'coso_ql'  => implode( ', ', $ql_moi ),
			'coso_quan' => implode( ', ', $qn_moi ),
			'cap_nhat' => current_time( 'mysql' ),
		), array( 'ma_nv' => $ma ) );
		self::quen_coso_quan();   // bản vừa nhớ là bản TRƯỚC lượt ghi này
		if ( false === $ok ) {
			return array( 'ok' => false, 'error' => 'MySQL: ' . $wpdb->last_error );
		}

		$go = 0;
		if ( class_exists( 'VHCC_Cong' ) && method_exists( 'VHCC_Cong', 'xoa_nguoi' ) ) {
			$go = (int) VHCC_Cong::xoa_nguoi( $ma );
		}
		return array( 'ok' => true, 'doi' => true, 'doiQL' => $doi_ql, 'tu' => implode( ', ', $cu ),
			'den' => implode( ', ', $moi ), 'ql' => $ql_moi, 'go' => $go );
	}

	/**
	 * DANH MỤC CƠ SỞ — những cơ sở ĐÃ ĐƯỢC KHAI, không phải những tên từng xuất hiện đâu đó.
	 *
	 * Anh Thắng 02/09/2026, ảnh hồ sơ Phạm Tường Vi và lưới bảng công có hàng
	 * `(PART TIME )_POSH+JP` cạnh hàng `PART_TIME (POSHJP)`: *"bị sinh cơ sở ảo"*.
	 *
	 * 🔴 TRƯỚC BẢN NÀY DANH SÁCH CƠ SỞ ĐƯỢC SUY RA TỪ DỮ LIỆU CHẢY VÀO — `SELECT DISTINCT` trên
	 *    `cham_cong.coso` và `nhan_vien.cua_hang`. Nghĩa là BẤT KỲ tên nào từng lọt vào một lượt
	 *    chấm công hay một ô gõ tay đều nghiễm nhiên thành một cơ sở của cả hệ, vĩnh viễn, và
	 *    KHÔNG AI PHẢI QUYẾT ĐỊNH GÌ. Nạp .csv thì cơ sở suy ra từ TÊN TỆP
	 *    (`VHCC_NapCong::coso_tu_ten_tep`), nên hai lần nạp hai tên tệp khác nhau của cùng một
	 *    chỗ đẻ ra hai cơ sở; ô "Cơ sở phụ" trong hồ sơ là ô gõ tay, gõ lệch một dấu cách cũng
	 *    đẻ thêm một cơ sở nữa.
	 *
	 *    Hậu quả không dừng ở ô chọn dài thêm mấy dòng: công thật của một người bị XÉ ra nằm rải
	 *    trên hai ba hàng mang ba cái tên, mỗi hàng thiếu giờ, và bảng lương cộng theo hàng.
	 *
	 * 🔴 NAY CƠ SỞ CHỈ CÓ THẬT KHI ĐƯỢC KHAI CÓ Ý — đúng một trong hai:
	 *      · đã khai bộ phận ở màn Cấu hình (`bo_phan_coso`), hoặc
	 *      · đã có máy chấm công gán vào (`may.cua_hang`).
	 *    Cả hai đều là việc một người phải chủ động làm, không phải hệ quả của một lần gõ.
	 *
	 * ⚠️ SIẾT DANH MỤC KHÔNG ĐƯỢC LÀM MẤT CÔNG. Tên nằm ngoài danh mục mà vẫn đang mang lượt
	 *    chấm công thì KHÔNG biến mất im lặng — `ds_coso_la()` gom chúng lại và màn Cấu hình
	 *    hiện thành khối đỏ mở sẵn, kèm số lượt, để người ta gộp về tên đúng hoặc nhận vào danh
	 *    mục. Bỏ khối ấy đi là đổi một lỗi ồn ào (ô chọn thừa dòng) lấy một lỗi câm (công biến
	 *    mất khỏi mọi màn), tức là làm cho tệ hơn.
	 */
	public static function ds_coso() {
		global $wpdb;
		$ds = array();
		foreach ( array( 'bo_phan_coso' => 'coso', 'may' => 'cua_hang' ) as $bang => $cot ) {
			foreach ( (array) $wpdb->get_col( "SELECT DISTINCT $cot FROM " . VHCC_DB::t( $bang ) ) as $x ) {
				$x = self::chuan_coso( $x );
				if ( '' !== $x && ! in_array( $x, $ds, true ) ) { $ds[] = $x; }
			}
		}
		sort( $ds );
		return $ds;
	}

	/**
	 * CƠ SỞ LẠ — tên đang MANG DỮ LIỆU THẬT mà chưa có trong danh mục.
	 *
	 * Đây là mặt kia của `ds_coso()`: siết danh mục thì phải có chỗ nhìn thấy thứ vừa bị siết
	 * ra ngoài, kèm đủ số liệu để quyết — nó là một cơ sở thật chưa kịp khai, hay chỉ là một
	 * tên gõ lệch của cơ sở đã có?
	 *
	 * ⚠️ TÊN TRẢ VỀ LÀ TÊN THÔ, y như trong kho. Chính mấy cái tên gõ lệch nhau mới là thứ cần
	 *    gộp; chuẩn hoá ở đây thì hai kiểu gõ nhập làm một trên màn hình và người ta không chọn
	 *    tách ra được nữa. (Cùng lý do với `VHCC_Nhan::ds_coso_tho()`.)
	 *
	 * @return array array( array( 'coso' => tên thô, 'luot' => số lượt chấm công, 'nguoi' => số hồ sơ ) )
	 *               — nhiều lượt nhất trước.
	 */
	public static function ds_coso_la() {
		global $wpdb;
		$biet = array();
		foreach ( self::ds_coso() as $x ) { $biet[ self::chu_thuong( $x ) ] = 1; }

		$gom = array();
		$them = function ( $ten, $o_dau, $so ) use ( &$gom, $biet ) {
			$ten = trim( (string) $ten );
			if ( '' === $ten ) { return; }
			$chuan = VHCC_NhanSu::chuan_coso( $ten );
			if ( '' === $chuan ) { return; }
			/* So bằng dạng CHUẨN: `CS_POSH_HCM` và `POSH_HCM` là một chỗ, đừng kể thành lạ. */
			if ( isset( $biet[ VHCC_NhanSu::chu_thuong( $chuan ) ] ) ) { return; }
			$k = VHCC_NhanSu::chu_thuong( $ten );
			if ( ! isset( $gom[ $k ] ) ) { $gom[ $k ] = array( 'coso' => $ten, 'luot' => 0, 'nguoi' => 0 ); }
			$gom[ $k ][ $o_dau ] += (int) $so;
		};

		foreach ( (array) $wpdb->get_results(
			'SELECT coso, COUNT(*) so FROM ' . VHCC_DB::t( 'cham_cong' )
			. " WHERE coso<>'' GROUP BY coso", ARRAY_A ) as $r ) {
			$them( $r['coso'], 'luot', $r['so'] );
		}

		/* Hồ sơ: đi qua `ds_coso_hs()` để `coso_phu` (chuỗi nối bằng dấu phẩy) được tách đúng
		   như mọi nơi khác trong hệ — tự `explode` ở đây là nơi thứ hai tách một thứ. */
		foreach ( (array) $wpdb->get_results(
			'SELECT cua_hang, coso_phu FROM ' . VHCC_DB::t( 'nhan_vien' ), ARRAY_A ) as $r ) {
			foreach ( self::ds_coso_hs( $r ) as $x ) { $them( $x, 'nguoi', 1 ); }
		}

		$ra = array_values( $gom );
		usort( $ra, function ( $a, $b ) {
			if ( $a['luot'] !== $b['luot'] ) { return $b['luot'] - $a['luot']; }
			return strcmp( $a['coso'], $b['coso'] );
		} );
		return $ra;
	}

	/* ====================================================================== tên cơ sở */

	/**
	 * TÊN ĐẦY ĐỦ CỦA MỘT MÃ CƠ SỞ.
	 *
	 * =============================================================================================
	 * Mã cơ sở trong sổ là thứ máy đọc: `FARM_PT`, `FF_SC`, `PINPALL_HCM`, `VP_KH-HCM`. Chúng ngắn
	 * vì phải nằm vừa một cột và phải gõ được vào máy chấm công — nhưng người đọc bảng thì phải tự
	 * dịch trong đầu, và người mới thì không dịch nổi. Trên một ô chọn 21 dòng, đoán sai một dòng
	 * là xếp lịch cho cửa hàng khác.
	 *
	 * 🔴 KHÔNG ĐỔI MÃ ĐỂ CHO DỄ ĐỌC. Mã cơ sở là KHOÁ: bảng chấm công, bảng lịch, bảng máy, bảng
	 *    lương đều trỏ vào nó, và máy chấm công ngoài cửa hàng cũng khai bằng chính mã ấy. Đổi mã
	 *    là cắt đứt mọi dòng cũ. Nên bảng này chỉ thêm một lớp TÊN để HIỆN RA, mã giữ nguyên.
	 *
	 * ⚠️ Chưa khai thì trả lại chính MÃ, không trả rỗng. Trả rỗng là ô chọn có mấy dòng trắng
	 *    trơn — người ta không chọn được mà cũng không biết vì sao.
	 */
	const TEN_CS_O = 'COSO_TEN';

	private static $nho_ten_cs = null;

	/** Bảng [ MÃ => tên đầy đủ ], đã lọc sạch. */
	public static function ten_coso_bang() {
		if ( null === self::$nho_ten_cs ) {
			$ra = array();
			foreach ( (array) VHCC_Luong::cai_dat( self::TEN_CS_O, array() ) as $ma => $ten ) {
				$ma  = self::chuan_coso( $ma );
				$ten = trim( (string) ( is_array( $ten ) ? '' : $ten ) );
				if ( '' === $ma || '' === $ten ) { continue; }
				$ra[ $ma ] = $ten;
			}
			self::$nho_ten_cs = $ra;
		}
		return self::$nho_ten_cs;
	}

	public static function quen_ten_coso() { self::$nho_ten_cs = null; }

	/**
	 * Nhãn hiện ra màn hình: `Mã — Tên` nếu có khai, còn không thì chỉ `Mã`.
	 *
	 * 🔴 GIỮ CẢ MÃ, đừng chỉ hiện tên. Người đối chiếu với tệp .csv của máy, với bảng lương cũ,
	 *    với cái nhãn dán trên máy chấm công — họ tra bằng MÃ. Thay hẳn bằng tên là bắt họ dịch
	 *    ngược, và bảng nào cũng phải mở thêm một bảng nữa mới đọc được.
	 */
	public static function ten_coso( $ma ) {
		$m = self::chuan_coso( $ma );
		if ( '' === $m ) { return ''; }
		$b = self::ten_coso_bang();
		return isset( $b[ $m ] ) ? $m . ' — ' . $b[ $m ] : $m;
	}

	/**
	 * Khai / gỡ tên. `$ds` = [ MÃ => tên ]; tên rỗng thì gỡ dòng ấy.
	 *
	 * ⚠️ Bậc Quản lý (`ngoai_coso`): tên cơ sở hiện trên bảng của MỌI cửa hàng, không phải việc
	 *    riêng của một cửa hàng nào.
	 */
	public static function dat_ten_coso( $u, $ds ) {
		if ( ! VHCC_Vai::duoc( $u, 'ngoai_coso' ) ) {
			return array( 'ok' => false,
				'error' => VHCC_Vai::loi( $u, 'ngoai_coso', 'Đặt tên cơ sở' ) );
		}
		$cu   = self::ten_coso_bang();
		$sach = array();
		$doi  = 0;
		foreach ( (array) $ds as $ma => $ten ) {
			$ma  = self::chuan_coso( $ma );
			$ten = trim( (string) ( is_array( $ten ) ? '' : $ten ) );
			if ( '' === $ma ) { continue; }
			if ( mb_strlen( $ten, 'UTF-8' ) > 60 ) { $ten = mb_substr( $ten, 0, 60, 'UTF-8' ); }
			if ( '' !== $ten ) { $sach[ $ma ] = $ten; }
			$truoc = isset( $cu[ $ma ] ) ? $cu[ $ma ] : '';
			if ( $truoc !== $ten ) { $doi++; }
		}
		global $wpdb;
		$bang = VHCC_DB::t( 'cai_dat' );
		$ghi  = array( 'khoa' => self::TEN_CS_O, 'gia_tri' => wp_json_encode( $sach ),
			'cap_nhat' => current_time( 'mysql' ),
			'nguoi_sua' => isset( $u['name'] ) ? (string) $u['name'] : '' );
		$id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $bang WHERE khoa=%s", self::TEN_CS_O ) );
		if ( $id ) { $wpdb->update( $bang, $ghi, array( 'id' => (int) $id ) ); }
		else       { $wpdb->insert( $bang, $ghi ); }
		self::quen_ten_coso();
		return array( 'ok' => true, 'so' => count( $sach ), 'doi' => $doi );
	}

	/* ================================================================= quản lý cơ sở */

	/**
	 * BẢNG THỐNG KÊ TỪNG CƠ SỞ TRONG DANH MỤC — mã, tên, bộ phận, và NÓ ĐANG GIỮ GÌ.
	 *
	 * Anh Thắng 02/09/2026: *"thiếu tab quản lý cơ sở (thêm, xoá, sửa cơ sở)"*.
	 *
	 * 🔴 CỘT "ĐANG GIỮ GÌ" LÀ PHẦN QUAN TRỌNG NHẤT, không phải phần trang trí. Xoá một cơ sở
	 *    còn 400 lượt chấm công là xoá công thật của người ta — mà nhìn một dòng chỉ có mã và
	 *    tên thì không cách nào biết. Bày sẵn số máy · số hồ sơ · số lượt ngay cạnh nút Xoá thì
	 *    người bấm biết mình đang bấm cái gì.
	 *
	 * @return array array( array( 'ma','ten','bo_phan','cach_tinh','so_may','so_hs','so_luot' ) )
	 */
	public static function thong_ke_coso() {
		global $wpdb;
		$ds = self::ds_coso();
		if ( ! $ds ) { return array(); }
		$ten = self::ten_coso_bang();

		/* Đếm gộp MỘT LẦN cho cả ba bảng rồi tra bằng khoá chữ thường — hỏi từng cơ sở là 21 cơ
		   sở × 3 truy vấn cho một màn chỉ để đọc. */
		$dem_luot = array();
		foreach ( (array) $wpdb->get_results(
			'SELECT coso, COUNT(*) so FROM ' . VHCC_DB::t( 'cham_cong' ) . " WHERE coso<>'' GROUP BY coso",
			ARRAY_A ) as $r ) {
			$k = self::chu_thuong( self::chuan_coso( $r['coso'] ) );
			if ( '' === $k ) { continue; }
			$dem_luot[ $k ] = ( isset( $dem_luot[ $k ] ) ? $dem_luot[ $k ] : 0 ) + (int) $r['so'];
		}
		$dem_may = array();
		foreach ( (array) $wpdb->get_results(
			'SELECT cua_hang, COUNT(*) so FROM ' . VHCC_DB::t( 'may' ) . " WHERE cua_hang<>'' GROUP BY cua_hang",
			ARRAY_A ) as $r ) {
			$k = self::chu_thuong( self::chuan_coso( $r['cua_hang'] ) );
			if ( '' === $k ) { continue; }
			$dem_may[ $k ] = ( isset( $dem_may[ $k ] ) ? $dem_may[ $k ] : 0 ) + (int) $r['so'];
		}
		/* Hồ sơ: đếm qua `ds_coso_hs()` vì một người có thể thuộc NHIỀU cơ sở (cột `coso_phu` là
		   chuỗi nối bằng dấu phẩy). Đếm mỗi `cua_hang` là bỏ sót đúng những người chạy nhiều nơi. */
		$dem_hs = array();
		foreach ( (array) $wpdb->get_results(
			'SELECT cua_hang, coso_phu FROM ' . VHCC_DB::t( 'nhan_vien' ), ARRAY_A ) as $r ) {
			foreach ( self::ds_coso_hs( $r ) as $x ) {
				$k = self::chu_thuong( $x );
				$dem_hs[ $k ] = ( isset( $dem_hs[ $k ] ) ? $dem_hs[ $k ] : 0 ) + 1;
			}
		}

		$ra = array();
		foreach ( $ds as $ma ) {
			$k = self::chu_thuong( $ma );
			$ra[] = array(
				'ma'        => $ma,
				'ten'       => isset( $ten[ $ma ] ) ? $ten[ $ma ] : '',
				'bo_phan'   => VHCC_Luong::bo_phan_cua( $ma ),
				'cach_tinh' => VHCC_Luong::cach_tinh( $ma ),
				'so_may'    => isset( $dem_may[ $k ] ) ? $dem_may[ $k ] : 0,
				'so_hs'     => isset( $dem_hs[ $k ] ) ? $dem_hs[ $k ] : 0,
				'so_luot'   => isset( $dem_luot[ $k ] ) ? $dem_luot[ $k ] : 0,
			);
		}
		return $ra;
	}

	/**
	 * THÊM MỘT CƠ SỞ VÀO DANH MỤC.
	 *
	 * ⚠️ Đây là ĐƯỜNG DUY NHẤT sinh ra cơ sở mới bằng tay, và nó cố ý bắt người ta gõ mã rồi
	 *    bấm nút — chứ không phải hệ quả của một lần nạp tệp hay một ô gõ nhầm (xem khối 🔴 ở
	 *    `ds_coso()`).
	 */
	public static function them_coso( $u, $ma, $ten = '', $bo_phan = '' ) {
		if ( ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false, 'error' => 'Thêm cơ sở — ' . self::LOI_QT );
		}
		$ma = self::chuan_coso( $ma );
		$loi = VHCC_NapCong::ma_coso_hop_le( $ma );
		if ( '' !== $loi ) { return array( 'ok' => false, 'error' => $loi ); }
		foreach ( self::ds_coso() as $x ) {
			if ( 0 === strcasecmp( (string) $x, $ma ) ) {
				return array( 'ok' => false, 'error' => 'Cơ sở "' . $x . '" đã có trong danh mục rồi.' );
			}
		}
		$r = self::xep_bo_phan( $u, $ma, $bo_phan );
		if ( empty( $r['ok'] ) ) { return $r; }
		$ten = trim( (string) $ten );
		if ( '' !== $ten ) {
			$bang = self::ten_coso_bang();
			$bang[ $ma ] = $ten;
			self::dat_ten_coso( $u, $bang );
		}
		return array( 'ok' => true, 'ma' => $ma );
	}

	/**
	 * GỠ MỘT TÊN CƠ SỞ KHỎI MỌI HỒ SƠ. Trả về số hồ sơ đã sửa.
	 *
	 * ⚠️ Đi qua `ds_coso_hs()` rồi rải lại vào hai cột `cua_hang`/`coso_phu` — y hệt cách
	 *    `VHCC_Web::luu_ho_so()` và `doi_coso()` ghi. Cắt chuỗi bằng tay ở đây là nơi thứ ba
	 *    hiểu một hình dạng dữ liệu, và nơi thứ ba luôn là nơi hiểu sai.
	 */
	public static function go_coso_ho_so( $ten ) {
		global $wpdb;
		$bo = self::chu_thuong( self::chuan_coso( $ten ) );
		if ( '' === $bo ) { return 0; }
		$so = 0;
		foreach ( (array) $wpdb->get_results(
			'SELECT ma_nv, cua_hang, coso_phu FROM ' . VHCC_DB::t( 'nhan_vien' ), ARRAY_A ) as $r ) {
			$cu  = self::ds_coso_hs( $r );
			$giu = array();
			foreach ( $cu as $x ) {
				if ( self::chu_thuong( $x ) !== $bo ) { $giu[] = $x; }
			}
			if ( count( $giu ) === count( $cu ) ) { continue; }
			$dat = $giu;
			$wpdb->update( VHCC_DB::t( 'nhan_vien' ), array(
				'cua_hang' => $dat ? array_shift( $dat ) : '',
				'coso_phu' => implode( ', ', $dat ),
				'cap_nhat' => current_time( 'mysql' ),
			), array( 'ma_nv' => $r['ma_nv'] ) );
			$so++;
		}
		return $so;
	}

	/**
	 * XOÁ MỘT CƠ SỞ — khỏi danh mục, khỏi tên hiện ra, khỏi mọi hồ sơ.
	 *
	 * 🔴 CÔNG ĐÃ CHẤM KHÔNG BAO GIỜ BỊ XOÁ THEO MỘT CÁCH ÂM THẦM. Cơ sở còn lượt chấm công thì
	 *    hàm này CHỐI, và nói ra con số — muốn dọn thì gộp về cơ sở đúng (giữ nguyên công) hoặc
	 *    bấm lại với `$ca_luot` kèm ĐÚNG số lượt đang thấy trên màn.
	 *
	 * ⚠️ `$mong_luot` là chốt "đúng con số anh vừa nhìn". Người mở màn lúc 9h, đi họp, 11h quay
	 *    lại bấm Xoá — trong khoảng ấy máy chấm công có thể đã đẩy thêm cả trăm lượt. Không so
	 *    lại là xoá mất phần vừa vào mà không ai biết.
	 *
	 * ⚠️ CÒN MÁY GÁN VÀO THÌ CHỐI HẲN, không có đường vòng: máy vẫn cắm ngoài cửa hàng và vẫn
	 *    đẩy công về, nên xoá cơ sở chỉ làm công mới rơi thành "cơ sở lạ" ngay hôm sau. Gỡ gán
	 *    máy ở màn Máy & Firmware trước.
	 */
	public static function xoa_coso( $u, $ma, $ca_luot = false, $mong_luot = null ) {
		global $wpdb;
		if ( ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false, 'error' => 'Xoá cơ sở — ' . self::LOI_QT );
		}
		$ma = self::chuan_coso( $ma );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu mã cơ sở.' ); }

		$so_may = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHCC_DB::t( 'may' ) . ' WHERE LOWER(cua_hang)=LOWER(%s)', $ma ) );
		if ( $so_may > 0 ) {
			return array( 'ok' => false, 'error' => 'Cơ sở "' . $ma . '" còn ' . $so_may
				. ' máy chấm công đang gán vào. Gỡ gán máy ở màn Máy & Firmware trước — máy còn cắm '
				. 'ngoài cửa hàng thì công mới lại chảy về đây ngay hôm sau.' );
		}

		$so_luot = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHCC_DB::t( 'cham_cong' ) . ' WHERE LOWER(coso)=LOWER(%s)', $ma ) );
		if ( $so_luot > 0 && ! $ca_luot ) {
			return array( 'ok' => false, 'error' => 'Cơ sở "' . $ma . '" còn ' . $so_luot
				. ' lượt chấm công. Gộp nó về cơ sở đúng để giữ nguyên công, hoặc chọn "xoá cả '
				. $so_luot . ' lượt" nếu chắc chắn phần công này là rác.' );
		}
		if ( $so_luot > 0 && null !== $mong_luot && (int) $mong_luot !== $so_luot ) {
			return array( 'ok' => false, 'error' => 'Số lượt vừa đổi (' . $so_luot . ' chứ không phải '
				. (int) $mong_luot . ') — có ai đó vừa chấm công vào cơ sở này. Xem lại rồi bấm lại.' );
		}

		$xoa_luot = 0;
		if ( $so_luot > 0 ) {
			$xoa_luot = (int) $wpdb->query( $wpdb->prepare(
				'DELETE FROM ' . VHCC_DB::t( 'cham_cong' ) . ' WHERE LOWER(coso)=LOWER(%s)', $ma ) );
		}
		$so_hs = self::go_coso_ho_so( $ma );
		$wpdb->query( $wpdb->prepare(
			'DELETE FROM ' . VHCC_DB::t( 'bo_phan_coso' ) . ' WHERE LOWER(coso)=LOWER(%s)', $ma ) );
		$bang = self::ten_coso_bang();
		if ( isset( $bang[ $ma ] ) ) { unset( $bang[ $ma ] ); self::dat_ten_coso( $u, $bang ); }

		return array( 'ok' => true, 'ma' => $ma, 'luot' => $xoa_luot, 'ho_so' => $so_hs );
	}

	/**
	 * GỘP TRỌN VẸN MỘT CƠ SỞ VÀO CƠ SỞ KHÁC — công, hồ sơ, MÁY, và cả chỗ đứng trong danh mục.
	 *
	 * Anh Thắng 02/09/2026, sau khi thử dọn `(PART TIME )_POSH+JP` và `PART_TIME (POSHJP)`:
	 * *"Có gì đó xung đột không xoá hay gộp được"*.
	 *
	 * 🔴 GỐC: `VHCC_Nhan::gop_coso()` dời LƯỢT và dọn HỒ SƠ — nhưng KHÔNG chạm ba thứ còn lại:
	 *    dòng trong `bo_phan_coso`, máy đang gán, và tên đầy đủ. Mà từ 3.31.0 chính `bo_phan_coso`
	 *    là thứ quyết định một cơ sở CÓ THẬT hay không. Nên gộp xong:
	 *      · tên cũ VẪN nằm trong danh mục -> vẫn hiện ở mọi ô chọn, lưới cả tháng vẫn vẽ một
	 *        hàng 0h cho nó (cơ sở đã khai thì luôn hiện dù rỗng);
	 *      · vì còn trong danh mục nên nó KHÔNG rơi vào khối "Cơ sở lạ" -> không còn chỗ nào gộp
	 *        hay xoá được nữa. Đúng cảm giác "xung đột": làm gì cũng không mất đi.
	 *      · máy vẫn gán vào tên cũ -> hôm sau công lại chảy về đấy, vòng lặp khép kín.
	 *
	 * ⚠️ MÁY THÌ DỜI, KHÔNG CHỐI. `xoa_coso()` chối khi còn máy, và đúng — xoá là bỏ hẳn một chỗ.
	 *    Nhưng GỘP nghĩa là "hai cái tên này là MỘT chỗ", nên cái máy ấy vẫn đang ở đúng chỗ đó,
	 *    chỉ là khai dưới tên khác. Chối ở đây là bắt người ta đi vòng qua màn Máy rồi quay lại,
	 *    trong khi câu trả lời đã rõ. Dời, và KỂ RA số máy đã dời.
	 *
	 * ⚠️ CÒN LƯỢT KHÔNG DỜI ĐƯỢC THÌ GIỮ TÊN CŨ LẠI TRONG DANH MỤC. `gop_coso()` cố ý không đụng
	 *    hàng đích đã chỉnh tay (nguồn `sua`/`bu`, có thể đã chốt lương). Xoá tên cũ khỏi danh mục
	 *    lúc ấy là đẩy mấy lượt còn lại thành "cơ sở lạ" — nghĩa là vừa dọn xong đã đẻ ra rác mới.
	 */
	public static function gop_coso_day_du( $u, $tu, $den ) {
		global $wpdb;
		if ( ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false, 'error' => 'Gộp cơ sở — ' . self::LOI_QT );
		}
		$tu  = trim( (string) $tu );
		$den = trim( (string) $den );
		$r   = VHCC_Nhan::gop_coso( $tu, $den, true );
		if ( isset( $r['loi'] ) ) { return array( 'ok' => false, 'error' => $r['loi'] ); }

		/* Dời máy sang tên đích — dùng đúng kiểu gõ mà `gop_coso()` đã chốt (`$r['den']`), không
		   dùng chuỗi người ta gõ vào: hai thứ ấy có thể khác hoa thường. */
		$may = (int) $wpdb->query( $wpdb->prepare(
			'UPDATE ' . VHCC_DB::t( 'may' ) . ' SET cua_hang=%s WHERE LOWER(cua_hang)=LOWER(%s)',
			$r['den'], $tu ) );

		/* Còn lượt nào mang tên cũ (hàng đã chỉnh tay) thì GIỮ tên cũ trong danh mục. */
		$con = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHCC_DB::t( 'cham_cong' ) . ' WHERE LOWER(coso)=LOWER(%s)', $tu ) );
		$go_danh_muc = false;
		if ( 0 === $con ) {
			$wpdb->query( $wpdb->prepare(
				'DELETE FROM ' . VHCC_DB::t( 'bo_phan_coso' ) . ' WHERE LOWER(coso)=LOWER(%s)', $tu ) );
			$bang = self::ten_coso_bang();
			$k_tu = self::chuan_coso( $tu );
			if ( isset( $bang[ $k_tu ] ) ) { unset( $bang[ $k_tu ] ); self::dat_ten_coso( $u, $bang ); }
			self::quen_ten_coso();
			$go_danh_muc = true;
		}

		return array( 'ok' => true, 'tu' => $tu, 'den' => $r['den'],
			'luot' => (int) $r['doi_ten'] + (int) $r['gop'], 'ho_so' => (int) $r['ho_so'],
			'may' => $may, 'con_lai' => $con, 'go_danh_muc' => $go_danh_muc,
			'de_lai' => (array) $r['de_lai'] );
	}

	/**
	 * TRA MỘT TÊN CƠ SỞ — NÓ ĐANG NẰM Ở ĐÂU, VÀ CÓ MẤY BIẾN THỂ.
	 *
	 * Anh Thắng 02/09/2026, sau hai lượt dọn mà hàng vẫn còn: *"vẫn cứ hiện cơ sở giữa lỗi, cần
	 * xoá luôn"*.
	 *
	 * 🔴 MỘT CÁI TÊN NẰM Ở NĂM CHỖ, VÀ DỌN BỐN CHỖ THÌ NÓ VẪN HIỆN. Cơ sở không phải một bản ghi
	 *    — nó chỉ là chữ, rải ở: `cham_cong.coso` · `nhan_vien.cua_hang` · `nhan_vien.coso_phu` ·
	 *    `may.cua_hang` · `bo_phan_coso.coso` (+ bảng tên đầy đủ). Mỗi chỗ có một lối dọn riêng,
	 *    nên "đã bấm gộp rồi mà vẫn thấy" là chuyện bình thường — và không màn nào nói cho biết
	 *    còn sót ở đâu. Hàm này trả lời đúng câu ấy.
	 *
	 * ⚠️ TRẢ CẢ DANH SÁCH BIẾN THỂ. Hai tên chỉ khác một dấu cách (`(PART TIME )_POSH+JP` và
	 *    `(PART TIME)_POSH+JP`) là HAI hàng khác nhau trong kho, mà nhìn trên màn thì gần như
	 *    không phân biệt được. Gộp một cái rồi tưởng xong, cái kia vẫn nguyên.
	 */
	public static function tra_coso( $ten ) {
		global $wpdb;
		$ten = trim( (string) $ten );
		if ( '' === $ten ) { return array(); }
		$chuan = self::chuan_coso( $ten );
		$goc   = self::rut_gon_ten( $ten );

		/* Biến thể: mọi tên trong bảng chấm công mà bỏ dấu cách + gạch + chữ thường thì giống
		   nhau. Đây là phép so LỎNG có chủ ý — chỗ này để TÌM, không phải để xoá. */
		$bien = array();
		foreach ( (array) $wpdb->get_results(
			'SELECT coso, COUNT(*) so FROM ' . VHCC_DB::t( 'cham_cong' ) . " WHERE coso<>'' GROUP BY coso",
			ARRAY_A ) as $r ) {
			if ( self::rut_gon_ten( $r['coso'] ) !== $goc ) { continue; }
			$bien[] = array( 'ten' => (string) $r['coso'], 'luot' => (int) $r['so'] );
		}
		/* Tên có trong hồ sơ mà không có lượt nào cũng là một biến thể — nó vẫn đẻ ra hàng trên
		   lưới, và đó chính là cái hàng anh Thắng thấy. */
		$ho_so = array();
		foreach ( (array) $wpdb->get_results(
			'SELECT ma_nv, ho_ten, cua_hang, coso_phu FROM ' . VHCC_DB::t( 'nhan_vien' ), ARRAY_A ) as $r ) {
			foreach ( self::ds_coso_hs( $r ) as $x ) {
				if ( self::rut_gon_ten( $x ) !== $goc ) { continue; }
				$ho_so[] = array( 'ma_nv' => (string) $r['ma_nv'], 'ho_ten' => (string) $r['ho_ten'],
					'ten' => $x );
				$co = false;
				foreach ( $bien as $b ) { if ( $b['ten'] === $x ) { $co = true; break; } }
				if ( ! $co ) { $bien[] = array( 'ten' => $x, 'luot' => 0 ); }
			}
		}
		$may = array();
		foreach ( (array) $wpdb->get_results(
			'SELECT serial, mac, cua_hang FROM ' . VHCC_DB::t( 'may' ) . " WHERE cua_hang<>''", ARRAY_A ) as $r ) {
			if ( self::rut_gon_ten( $r['cua_hang'] ) !== $goc ) { continue; }
			$may[] = array( 'serial' => (string) $r['serial'], 'mac' => (string) $r['mac'],
				'ten' => (string) $r['cua_hang'] );
		}
		$bp = array();
		foreach ( (array) $wpdb->get_col( 'SELECT coso FROM ' . VHCC_DB::t( 'bo_phan_coso' ) ) as $x ) {
			if ( self::rut_gon_ten( $x ) === $goc ) { $bp[] = (string) $x; }
		}
		$ten_bang = array();
		foreach ( self::ten_coso_bang() as $ma => $t ) {
			if ( self::rut_gon_ten( $ma ) === $goc ) { $ten_bang[] = $ma; }
		}
		usort( $bien, function ( $a, $b ) { return $b['luot'] - $a['luot']; } );

		return array( 'ten' => $ten, 'chuan' => $chuan, 'bien_the' => $bien,
			'ho_so' => $ho_so, 'may' => $may, 'bo_phan' => $bp, 'ten_day_du' => $ten_bang,
			'trong_danh_muc' => in_array( $chuan, self::ds_coso(), true ) );
	}

	/**
	 * Rút một tên cơ sở về dạng "gần nhau thì bằng nhau": bỏ tiền tố `CS_`, bỏ mọi thứ không
	 * phải chữ/số, hạ chữ thường. `(PART TIME )_POSH+JP` và `PART_TIME (POSHJP)` ra cùng một
	 * chuỗi `parttimeposhjp`.
	 *
	 * ⚠️ CHỈ DÙNG ĐỂ TÌM, KHÔNG BAO GIỜ ĐỂ XOÁ hay để so "cơ sở này là cơ sở kia". Nó cố ý bắt
	 *    LỎNG, nên hai cửa hàng khác nhau mà tên gần giống sẽ rơi vào cùng một rổ — người nhìn
	 *    mới là người quyết, máy chỉ bày ra.
	 */
	public static function rut_gon_ten( $s ) {
		$s = self::chuan_coso( $s );
		$s = preg_replace( '/[^\p{L}\p{N}]+/u', '', (string) $s );
		return self::chu_thuong( (string) $s );
	}

	/**
	 * XOÁ SẠCH MỌI DẤU VẾT CỦA MỘT TÊN CƠ SỞ — cả năm chỗ, trong một lượt.
	 *
	 * Anh Thắng 02/09/2026: *"vẫn cứ hiện cơ sở giữa lỗi, cần xoá luôn"*.
	 *
	 * 🔴 KHÁC `xoa_coso()` VÀ `xoa_coso_la()` Ở CHỖ NÓ KHÔNG CHỪA GÌ: gỡ luôn cả máy đang gán
	 *    (đặt về "chưa gán", KHÔNG xoá máy) và dòng bộ phận, kể cả khi tên ấy đang nằm trong
	 *    danh mục. Đây là cái nút cuối cùng cho tên đã bị dọn nửa vời mấy lượt mà vẫn hiện.
	 *
	 * ⚠️ KHỚP THEO TÊN THÔ, CHÍNH XÁC TỪNG KÝ TỰ. `rut_gon_ten()` chỉ dùng để TÌM và bày ra;
	 *    xoá thì phải đúng cái tên người ta nhìn thấy, không thì một dấu cách lệch là xoá nhầm
	 *    cửa hàng bên cạnh.
	 *
	 * ⚠️ `$mong_luot` phải khớp đúng số lượt đang có. Mất công thì mất thật, không lấy lại được.
	 */
	public static function xoa_sach_coso( $u, $ten, $mong_luot ) {
		global $wpdb;
		if ( ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false, 'error' => 'Xoá sạch cơ sở — ' . self::LOI_QT );
		}
		$ten = trim( (string) $ten );
		if ( '' === $ten ) { return array( 'ok' => false, 'error' => 'Thiếu tên cơ sở.' ); }

		$so = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHCC_DB::t( 'cham_cong' ) . ' WHERE coso=%s', $ten ) );
		if ( (int) $mong_luot !== $so ) {
			return array( 'ok' => false, 'error' => 'Số lượt của "' . $ten . '" vừa đổi (' . $so
				. ' chứ không phải ' . (int) $mong_luot . '). Tải lại màn rồi bấm lại.' );
		}
		$luot = 0;
		if ( $so > 0 ) {
			$luot = (int) $wpdb->query( $wpdb->prepare(
				'DELETE FROM ' . VHCC_DB::t( 'cham_cong' ) . ' WHERE coso=%s', $ten ) );
		}
		$hs  = self::go_coso_ho_so( $ten );
		/* Máy thì GỠ GÁN, không xoá: cái máy vẫn là tài sản đang cắm ở đâu đó. Lượt bấm của nó
		   sẽ nằm ở hàng "chờ gán" cho tới khi được gán lại — thấy được, và gán lại được. */
		$may = (int) $wpdb->query( $wpdb->prepare(
			'UPDATE ' . VHCC_DB::t( 'may' ) . " SET cua_hang='' WHERE cua_hang=%s", $ten ) );
		$bp  = (int) $wpdb->query( $wpdb->prepare(
			'DELETE FROM ' . VHCC_DB::t( 'bo_phan_coso' ) . ' WHERE coso=%s', $ten ) );
		$bang = self::ten_coso_bang();
		$k    = self::chuan_coso( $ten );
		$xoa_ten = false;
		if ( isset( $bang[ $k ] ) ) { unset( $bang[ $k ] ); self::dat_ten_coso( $u, $bang ); $xoa_ten = true; }
		self::quen_ten_coso();

		return array( 'ok' => true, 'ten' => $ten, 'luot' => $luot, 'ho_so' => $hs,
			'may' => $may, 'bo_phan' => $bp, 'ten_day_du' => $xoa_ten );
	}

	/**
	 * XOÁ HẲN MỘT TÊN CƠ SỞ LẠ — gỡ khỏi mọi hồ sơ VÀ xoá mọi lượt chấm công mang đúng tên ấy.
	 *
	 * Anh Thắng 02/09/2026, ảnh lưới công của nhân viên có ba hàng cho một người: *"nó đang bị
	 * nhân lên, cách nào xoá luôn"*.
	 *
	 * 🔴 KHÁC `xoa_coso()` Ở ĐÚNG MỘT CHỖ, VÀ CHỖ ẤY QUAN TRỌNG: ở đây khớp theo TÊN THÔ, y
	 *    nguyên như trong kho. `xoa_coso()` chuẩn hoá mã trước khi khớp (`chuan_coso()` gỡ tiền
	 *    tố `CS_`, cắt tại dấu phẩy) — đúng cho cơ sở trong danh mục, nhưng SAI ở đây: tên lạ
	 *    thường lạ chính vì mấy ký tự mà phép chuẩn hoá sẽ cắt mất, và cắt xong thì câu xoá trỏ
	 *    vào một cái tên khác — có thể là một cơ sở đang chạy.
	 *
	 * ⚠️ MẤT LÀ MẤT THẬT. Nên `$mong_luot` bắt buộc phải khớp đúng số lượt màn hình vừa bày ra:
	 *    người mở màn lúc 9h, đi họp, 11h quay lại bấm — trong khoảng ấy máy có thể đã đẩy thêm
	 *    cả trăm lượt. Muốn GIỮ công thì đừng dùng hàm này, dùng `VHCC_Nhan::gop_coso()`.
	 */
	public static function xoa_coso_la( $u, $ten, $mong_luot ) {
		global $wpdb;
		if ( ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false, 'error' => 'Xoá cơ sở — ' . self::LOI_QT );
		}
		$ten = trim( (string) $ten );
		if ( '' === $ten ) { return array( 'ok' => false, 'error' => 'Thiếu tên cơ sở.' ); }
		foreach ( self::ds_coso() as $x ) {
			if ( 0 === strcasecmp( (string) $x, self::chuan_coso( $ten ) ) ) {
				return array( 'ok' => false, 'error' => '"' . $ten . '" là cơ sở ĐANG CÓ trong danh mục — '
					. 'xoá nó ở bảng Danh mục cơ sở, không phải ở khối Cơ sở lạ.' );
			}
		}
		$so = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHCC_DB::t( 'cham_cong' ) . ' WHERE coso=%s', $ten ) );
		if ( (int) $mong_luot !== $so ) {
			return array( 'ok' => false, 'error' => 'Số lượt của "' . $ten . '" vừa đổi (' . $so
				. ' chứ không phải ' . (int) $mong_luot . ') — có ai đó vừa chấm công vào tên này. '
				. 'Tải lại màn rồi bấm lại.' );
		}
		$xoa = 0;
		if ( $so > 0 ) {
			$xoa = (int) $wpdb->query( $wpdb->prepare(
				'DELETE FROM ' . VHCC_DB::t( 'cham_cong' ) . ' WHERE coso=%s', $ten ) );
		}
		$hs = self::go_coso_ho_so( $ten );
		return array( 'ok' => true, 'ten' => $ten, 'luot' => $xoa, 'ho_so' => $hs );
	}

	// ======================================================================= ghi

	/**
	 * Lưu hồ sơ. Trả array('ok'=>bool, 'error'=>..., 'tao_moi'=>bool).
	 *
	 * ⚠️ Bốn chốt, mỗi chốt một lý do khác nhau — bỏ chốt nào cũng mất một thứ khác nhau.
	 */
	/**
	 * PIN NÀY ĐANG LÀ CỦA AI — trả mã NV, hoặc chuỗi rỗng nếu chưa ai dùng.
	 *
	 * 🔴 HAI NGƯỜI CÙNG MỘT PIN LÀ ĐĂNG NHẬP NHẦM NGƯỜI. `VHCC_Auth::login()` tra theo PIN, nên
	 *    người vào được sẽ là người đầu tiên khớp — và người kia gõ đúng PIN của mình mà vào
	 *    nhầm tài khoản, thấy công của người khác, nộp đơn dưới tên người khác. Đây là loại lỗi
	 *    không ai báo, vì người dùng tưởng mình bấm nhầm.
	 *
	 * ⚠️ KHÔNG trả về PIN, chỉ trả MÃ NV. Nơi gọi cần biết "có đụng ai không", không cần biết số.
	 */
	public static function pin_dang_dung( $pin, $tru_ma = '' ) {
		global $wpdb;
		$pin    = trim( (string) $pin );
		if ( '' === $pin ) { return ''; }
		$tru_ma = trim( (string) $tru_ma );

		$ma = $wpdb->get_var( $wpdb->prepare(
			'SELECT ma_nv FROM ' . VHCC_DB::t( 'nhan_vien' )
			. ' WHERE pin_dang_nhap=%s AND ma_nv<>%s LIMIT 1', $pin, $tru_ma ) );
		if ( null !== $ma ) { return (string) $ma; }

		/* 🔴 08/09/2026 — PHẢI SOÁT CẢ SỔ PhanQuyen, KHÔNG CHỈ BẢNG HỒ SƠ.
		 *    Anh Thắng: *"thêm nhân viên bị lỗi ở chấm công"*. Dựng lại trong bộ giả lập thì ra
		 *    thế này: cửa trạm (`VHCC_Tram::tim_pin`) tra **sổ PhanQuyen TRƯỚC**, hồ sơ sau. Bản
		 *    3.47.0 chỉ soát bảng hồ sơ, nên cấp cho người mới đúng con số mà sổ cũ đã cấp cho
		 *    người khác vẫn lọt — rồi người mới gõ PIN của mình mà **vào nhầm tài khoản người
		 *    kia**: lượt chấm ghi sang mã người kia, tên hiện trên trạm là tên người kia. Hỏng
		 *    im lặng, đúng loại lỗi không ai báo vì tưởng mình bấm nhầm.
		 *    Chốt đặt ở ĐÂY chứ không ở nơi gọi: cả bốn đường ghi hồ sơ đều đi qua hàm này.
		 *
		 * ⚠️ CHỈ chặn hàng có `ma_cc_online` KHÁC RỖNG và khác mã đang sửa. Hai lý do:
		 *    (1) đó đúng là hàng cướp được phiên — `tim_pin` chỉ trả về từ sổ này khi có mã;
		 *    (2) hàng `ma_cc_online` rỗng thì KHÔNG biết là của ai, mà chuyện thường gặp nhất
		 *        là *chính người ấy* đã có tên trong sổ cũ và nay mới được lập hồ sơ với đúng
		 *        PIN quen dùng — chặn nhóm đó là chối oan hàng loạt.
		 */
		$t_pq = VHCC_DB::t( 'phan_quyen' );
		if ( ! VHCC_DB::co_bang( $t_pq ) ) { return ''; }
		$rows = VHCC_DB::rows( "SELECT pin, ma_cc_online FROM $t_pq WHERE pin <> '' AND ma_cc_online <> ''" );
		foreach ( (array) $rows as $r ) {
			/* So bằng `pin_sach` chứ không so chuỗi thô: sổ cũ kéo từ Sheets nên có hàng mang
			   dấu nháy đầu hoặc khoảng trắng thừa — đúng cái mà cửa trạm cũng gột trước khi so,
			   nên soát ở đây phải gột y hệt, kẻo chặn hụt đúng hàng sẽ cướp phiên. */
			if ( VHCC_Auth::pin_sach( $r['pin'] ) !== VHCC_Auth::pin_sach( $pin ) ) { continue; }
			$k = trim( (string) $r['ma_cc_online'] );
			if ( '' !== $k && $k !== $tru_ma ) { return $k; }
		}
		return '';
	}

	/**
	 * PIN MÁY NÀY ĐANG LÀ CỦA AI — trong CÙNG cơ sở. Trả mã NV, hoặc chuỗi rỗng.
	 *
	 * 🔴 08/09/2026 — anh Thắng: *"chặn trường hợp tạo mã pin trùng nhé"*.
	 *    PIN máy là mã BẤM PHÍM trên đầu đọc Hikvision (trường `password` của user). Hai người
	 *    cùng cơ sở mang cùng một PIN máy là **giờ của người này ghi vào người kia** — sai trực
	 *    tiếp trên bảng công, mà không có gì báo: cả hai bấm đều "mở được".
	 *
	 * ⚠️ SO TRONG CÙNG CƠ SỞ, KHÔNG so cả chuỗi. Mỗi đầu đọc chỉ giữ người của cơ sở nó, nên hai
	 *    cơ sở khác nhau trùng PIN máy là vô hại — chặn cả chuỗi thì tới cơ sở thứ mười là không
	 *    còn số 4 chữ số nào cấp được, và người ta sẽ đi vòng qua bằng cách bỏ trống ô.
	 * ⚠️ Tính CẢ cơ sở phụ: người tăng cường có mặt trên đầu đọc của cả hai nơi.
	 */
	public static function pin_may_dang_dung( $pin, $tru_ma = '', $coso_ds = array() ) {
		$pin = trim( (string) $pin );
		if ( '' === $pin ) { return ''; }
		$cs = array();
		foreach ( (array) $coso_ds as $x ) {
			$x = self::chu_thuong( self::chuan_coso( $x ) );
			if ( '' !== $x ) { $cs[ $x ] = 1; }
		}
		if ( ! $cs ) { return ''; }        // chưa khai cơ sở nào -> chưa đụng đầu đọc nào
		$tru_ma = trim( (string) $tru_ma );
		global $wpdb;
		$rows = VHCC_DB::rows( $wpdb->prepare(
			'SELECT ma_nv, cua_hang, coso_phu FROM ' . VHCC_DB::t( 'nhan_vien' )
			. ' WHERE pin_may=%s AND ma_nv<>%s', $pin, $tru_ma ) );
		foreach ( (array) $rows as $r ) {
			foreach ( self::ds_coso_hs( $r ) as $x ) {
				if ( isset( $cs[ self::chu_thuong( $x ) ] ) ) { return (string) $r['ma_nv']; }
			}
		}
		return '';
	}

	/**
	 * SOÁT HAI Ô PIN TRƯỚC KHI GHI — dùng chung cho MỌI đường lưu hồ sơ.
	 *
	 * 🔴 Một hàm duy nhất, vì có tới bốn đường ghi được vào hai ô ấy (màn Hồ sơ ngoài web, màn
	 *    wp-admin, nạp .csv, kéo từ app gốc). Mỗi đường tự viết một phép soát là sớm muộn có
	 *    đường quên, mà đường quên thì hỏng IM LẶNG: cổng đăng nhập nhận người gặp trước, hoặc
	 *    giờ chấm công của người này ghi sang người kia.
	 *
	 * @param array  $ghi     mảng sắp ghi (đọc `pin_dang_nhap`, `pin_may`; ô nào trống thì bỏ qua).
	 * @param string $ma      mã NV đang lưu — trừ chính nó ra khi so.
	 * @param array  $coso_ds cơ sở của người này (cho phép so PIN máy trong cùng cơ sở).
	 * @return string Câu báo lỗi, hoặc '' nếu sạch.
	 */
	public static function pin_trung_loi( $ghi, $ma, $coso_ds = array() ) {
		if ( ! empty( $ghi['pin_dang_nhap'] ) ) {
			$k = self::pin_dang_dung( $ghi['pin_dang_nhap'], $ma );
			if ( '' !== $k ) {
				$hs  = self::ho_so( $k );
				$ten = ( $hs && '' !== trim( (string) $hs['ho_ten'] ) ) ? $hs['ho_ten'] : $k;
				/* Không có hồ sơ mang mã ấy = số này tới từ SỔ PhanQuyen cũ. Nói thẳng ra, kẻo
				   người sửa đi tìm mã đó trong danh sách hồ sơ và không thấy đâu. */
				$o_dau = $hs ? '' : ' (đang nằm trong sổ PhanQuyen cũ, chưa có hồ sơ)';
				return 'PIN đăng nhập này đã cấp cho ' . $ten . ' (' . $k . ')' . $o_dau . '. Hai người '
					. 'cùng PIN thì cổng nhận người gặp trước, và nhật ký ghi tên người đó — người kia '
					. 'làm gì cũng mang tên người này. Chọn số khác.';
			}
		}
		if ( ! empty( $ghi['pin_may'] ) ) {
			$k = self::pin_may_dang_dung( $ghi['pin_may'], $ma, $coso_ds );
			if ( '' !== $k ) {
				$hs = self::ho_so( $k );
				$ten = ( $hs && '' !== trim( (string) $hs['ho_ten'] ) ) ? $hs['ho_ten'] : $k;
				return 'PIN máy chấm công này đã cấp cho ' . $ten . ' (' . $k . ') ở cùng cơ sở. '
					. 'Hai người cùng PIN máy thì giờ của người này ghi vào người kia. Chọn số khác.';
			}
		}
		return '';
	}

	/** Bốn ô liên lạc cửa hàng được sửa. Khai MỘT chỗ để cửa và màn không bao giờ lệch nhau. */
	const O_CUA_HANG_SUA = array(
		'sdt'                => 'Số điện thoại',
		'dia_chi'            => 'Địa chỉ',
		'nguoi_lien_he_khan' => 'Người liên hệ khẩn',
		'sdt_khan'           => 'SĐT khẩn',
	);

	/**
	 * CỬA SỬA HỒ SƠ DÀNH CHO CỬA HÀNG — hẹp, và hẹp là điểm chính của nó.
	 *
	 * Anh Thắng 31/08/2026: mỗi cơ sở có hệ thống quản lý nhân sự con của mình, *"để tại cửa
	 * hàng trực tiếp quản lý dễ hơn"*; cửa hàng trưởng được sửa thông tin liên lạc và cấp PIN.
	 *
	 * 🔴 DANH SÁCH TRẮNG, KHÔNG PHẢI DANH SÁCH ĐEN. Chỉ bốn ô ở `O_CUA_HANG_SUA` cộng ô PIN đi
	 *    qua được; mọi ô khác bị bỏ lặng lẽ. Viết theo kiểu "chặn mấy ô nhạy cảm" thì thêm một
	 *    cột mới vào bảng là tự động mở cửa cho nó, và không ai nhớ ra để chặn.
	 *
	 * 🔴 KHÔNG ĐỔI ĐƯỢC CƠ SỞ, VAI TRÒ, LƯƠNG, SỐ TÀI KHOẢN, MÃ NV. Đổi cơ sở là chuyển công và
	 *    lương sang cửa hàng khác; đổi vai trò là tự nâng quyền cho mình. Hai việc ấy ở bậc trên.
	 *
	 * ⚠️ NGƯỜI LÀM HAI NƠI THÌ CẢ HAI CỬA HÀNG SỬA ĐƯỢC (anh Thắng chốt 31/08) — nên gác bằng
	 *    `co_quyen_ho_so()` chứ không phải `co_quyen_coso()` trên cơ sở đứng đầu. Đổi lại, mọi
	 *    lượt sửa đều vào sổ `nhat_ky_ho_so` kèm TÊN người sửa và CỬA HÀNG họ đang đứng: hai nơi
	 *    cùng sửa mà không có sổ thì lúc lệch chỉ còn mỗi câu "chắc bên kia sửa".
	 *
	 * @return array `ok` · `doi`(mảng tên ô đã đổi) hoặc `error`.
	 */
	public static function sua_ho_so_coso( $u, $ma, $dat ) {
		global $wpdb;
		$ma = trim( (string) $ma );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu Mã NV.' ); }
		/* ⚠️ PHÁ THỬ KHÔNG BẮT ĐƯỢC VIỆC BỎ DÒNG NÀY, và đó là điều bình thường — đã tìm ra lý do
		   (pha70, 31/08/2026): `co_quyen_ho_so()` ngay dưới hỏi `co_quyen_coso()`, mà hàm ấy
		   chặn ngay ai không có `cong_coso` — cùng bậc Cửa hàng trưởng với `ho_so_coso`. Nên
		   hôm nay hai gác chặn đúng cùng một nhóm người.
		   VẪN GIỮ, vì nó nói ĐÚNG việc đang xin: "sửa hồ sơ" chứ không phải "xem công cơ sở".
		   Ngày ai đó hạ `cong_coso` xuống bậc Nhân viên (chuyện hoàn toàn có thể — nhân viên xem
		   công cơ sở mình là một yêu cầu hợp lý), dòng này là thứ duy nhất còn chặn. */
		if ( ! VHCC_Vai::duoc( $u, 'ho_so_coso' ) ) {
			return array( 'ok' => false, 'error' => VHCC_Vai::loi( $u, 'ho_so_coso', 'Sửa hồ sơ' ) );
		}
		$cu = self::ho_so( $ma );
		if ( ! $cu ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ ' . $ma . '.' ); }
		if ( ! self::co_quyen_ho_so( $u, $cu ) ) {
			return array( 'ok' => false, 'error' => 'Hồ sơ này không thuộc cơ sở bạn phụ trách.' );
		}

		$ghi = array();
		$sg  = array();
		foreach ( self::O_CUA_HANG_SUA as $o => $ten ) {
			if ( ! isset( $dat[ $o ] ) ) { continue; }
			$moi = trim( (string) $dat[ $o ] );
			if ( $moi === trim( (string) $cu[ $o ] ) ) { continue; }
			$ghi[ $o ] = $moi;
			$sg[]      = array( 'o' => $o, 'cu' => (string) $cu[ $o ], 'moi' => $moi );
		}

		/* PIN: trống = GIỮ NGUYÊN, không phải xoá — cùng luật với mọi ô PIN khác trong hệ. */
		if ( isset( $dat['pin_dang_nhap'] ) ) {
			$pin = VHCC_NapCsv::pin( (string) $dat['pin_dang_nhap'] );
			if ( '' !== $pin ) {
				$dung = self::pin_dang_dung( $pin, $ma );
				if ( '' !== $dung ) {
					return array( 'ok' => false,
						'error' => 'PIN này đang là PIN của một người khác. Chọn số khác.' );
				}
				$ghi['pin_dang_nhap'] = $pin;
				/* 🔴 SỔ KHÔNG BAO GIỜ GHI GIÁ TRỊ PIN — chỉ ghi rằng đã đổi. Sổ này người trong
				   công ty đọc được, mà PIN đọc một lần là dùng được mãi. */
				$sg[] = array( 'o' => 'pin_dang_nhap', 'cu' => '', 'moi' => 'đã đổi' );
			}
		}

		if ( ! $ghi ) { return array( 'ok' => true, 'doi' => array(), 'thong_bao' => 'Không có gì đổi.' ); }

		$ghi['cap_nhat'] = current_time( 'mysql' );
		$wpdb->update( VHCC_DB::t( 'nhan_vien' ), $ghi, array( 'ma_nv' => $ma ) );

		$ai = trim( isset( $u['name'] ) ? (string) $u['name'] : '' );
		$tu = implode( ', ', self::ds_coso_cua( $u ) );
		foreach ( $sg as $x ) {
			$wpdb->insert( VHCC_DB::t( 'nhat_ky_ho_so' ), array(
				'luc'     => current_time( 'mysql' ),
				'ma_nv'   => $ma,
				'ai'      => $ai,
				'tu_coso' => $tu,
				'o'       => $x['o'],
				'cu'      => mb_substr( $x['cu'], 0, 250 ),
				'moi'     => mb_substr( $x['moi'], 0, 250 ),
			) );
		}
		$ten_doi = array();
		foreach ( $sg as $x ) {
			$ten_doi[] = isset( self::O_CUA_HANG_SUA[ $x['o'] ] )
				? self::O_CUA_HANG_SUA[ $x['o'] ] : 'PIN đăng nhập';
		}
		return array( 'ok' => true, 'doi' => $ten_doi,
			'thong_bao' => 'Đã lưu: ' . implode( ', ', $ten_doi ) . '.' );
	}

	/**
	 * XEM SỐ PIN ĐANG DÙNG CỦA MỘT NGƯỜI — và ghi vào sổ rằng đã xem.
	 *
	 * Anh Thắng 31/08/2026, ảnh dãy nút dưới tên người ở trang Quản lý nhân sự: *"Bổ sung xem
	 * PIn được tại vị trí này"*.
	 *
	 * 🔴 TRẢ VỀ MỘT NGƯỜI MỘT LƯỢT, KHÔNG BAO GIỜ CẢ CỘT. Luật của cả hệ này từ đầu là không in
	 *    PIN ra màn — vì trang chạy ngoài internet và ảnh chụp bảng nhân sự đi khắp nơi (chính
	 *    anh Thắng gửi một tấm như thế kèm yêu cầu này). Nên đường xem là: bấm đúng một người,
	 *    tải lại trang, hiện đúng số của người ấy. Ảnh chụp cả bảng vẫn không lộ gì.
	 *
	 * 🔴 XEM LÀ MỘT VIỆC PHẢI VÀO SỔ. Biết PIN của người khác là đăng nhập thay họ được — đọc
	 *    công, nộp đơn, xin phép dưới tên họ — mà màn hình của họ không có gì đổi. Không ghi
	 *    lại thì ngày cần lần ra ai đã làm việc đó, không còn một dấu vết nào.
	 *
	 * ⚠️ SỔ GHI "đã xem", KHÔNG GHI SỐ. Sổ này người trong công ty đọc được.
	 *
	 * @return array `ok` · `pin` · `ho_ten`, hoặc `error`.
	 */
	public static function xem_pin( $u, $ma ) {
		global $wpdb;
		$ma = trim( (string) $ma );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu Mã NV.' ); }
		if ( ! VHCC_Vai::duoc( $u, 'xem_pin' ) ) {
			return array( 'ok' => false, 'error' => VHCC_Vai::loi( $u, 'xem_pin', 'Xem PIN' ) );
		}
		$hs = self::ho_so( $ma );
		if ( ! $hs ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ ' . $ma . '.' ); }
		if ( ! self::co_quyen_ho_so( $u, $hs ) ) {
			return array( 'ok' => false, 'error' => 'Hồ sơ này không thuộc cơ sở bạn phụ trách.' );
		}
		$pin = trim( (string) $hs['pin_dang_nhap'] );
		if ( '' === $pin ) {
			return array( 'ok' => true, 'pin' => '', 'ho_ten' => (string) $hs['ho_ten'] );
		}

		$wpdb->insert( VHCC_DB::t( 'nhat_ky_ho_so' ), array(
			'luc'     => current_time( 'mysql' ),
			'ma_nv'   => $ma,
			'ai'      => trim( isset( $u['name'] ) ? (string) $u['name'] : '' ),
			'tu_coso' => implode( ', ', self::ds_coso_cua( $u ) ),
			'o'       => 'xem_pin',
			'cu'      => '',
			'moi'     => 'đã xem',
		) );
		return array( 'ok' => true, 'pin' => $pin, 'ho_ten' => (string) $hs['ho_ten'] );
	}

	/** Tên tiếng Việt của một ô trong sổ nhật ký hồ sơ. Một chỗ, để ba màn không gọi ba tên. */
	public static function ten_o_nhat_ky( $o ) {
		if ( isset( self::O_CUA_HANG_SUA[ $o ] ) ) { return self::O_CUA_HANG_SUA[ $o ]; }
		if ( 'xem_pin' === $o ) { return 'XEM số PIN'; }
		return 'PIN đăng nhập';
	}

	/** Mấy lượt sửa gần nhất của một người — đọc để đối chiếu khi số liệu lệch. */
	public static function nhat_ky_ho_so( $ma, $tran = 20 ) {
		global $wpdb;
		return VHCC_DB::rows( $wpdb->prepare(
			'SELECT * FROM ' . VHCC_DB::t( 'nhat_ky_ho_so' )
			. ' WHERE ma_nv=%s ORDER BY id DESC LIMIT %d', trim( (string) $ma ), (int) $tran ) );
	}

	public static function luu_ho_so( $u, $dat ) {
		global $wpdb;
		$ma = trim( isset( $dat['ma_nv'] ) ? (string) $dat['ma_nv'] : '' );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu Mã NV.' ); }
		$cu = self::ho_so( $ma );
		$coso_moi = self::chuan_coso( isset( $dat['cua_hang'] ) ? $dat['cua_hang'] : '' );

		// Chốt 1: bậc dưới cùng.
		if ( ! self::co_sua_ho_so( $u ) ) {
			return array( 'ok' => false, 'error' => 'Không có quyền sửa hồ sơ nhân sự.' );
		}
		// Chốt 2: TẠO MỚI là cấp Mã NV dùng chung cả chuỗi -> chỉ Admin/Quản lý.
		if ( ! $cu && ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false,
				'error' => 'Tạo hồ sơ mới cần cấp Mã NV — mã dùng chung cả chuỗi nên ' . self::LOI_QT );
		}
		// Chốt 3: ĐỔI cửa hàng là chuyển cả công và lương giữa hai cửa hàng -> chỉ Admin/Quản lý.
		if ( $cu ) {
			$coso_cu = self::chuan_coso( $cu['cua_hang'] );
			/* 🔴 ĐỔI THỨ TỰ CHÍNH/PHỤ TRONG **CÙNG** DANH SÁCH KHÔNG PHẢI LÀ CHUYỂN CỬA HÀNG.
			   Từ 3.62.0 biểu mẫu có nút tròn "cơ sở chính" (anh Thắng 09/09/2026: *"làm sao để
			   chuyển đổi cơ sở chính và cơ sở phụ"*), và nó ghi vào đúng cột `cua_hang` mà chốt
			   này canh. Người ấy vẫn làm ở đủ những cơ sở cũ — không có công hay lương nào chạy
			   sang cửa hàng khác, nên bắt bậc Quản lý ở đây là khoá cái nút vừa thêm với Kế
			   toán và Cửa hàng trưởng, kèm một câu chối nói về "ô Cơ sở phụ" đã bỏ từ 3.13.0.
			   Chốt 4 ngay dưới vẫn gác: chỉ sửa được hồ sơ của cơ sở mình phụ trách. */
			$chi_doi_thu_tu = '' !== $coso_moi && self::hs_thuoc_coso( $cu, $coso_moi );
			if ( '' !== $coso_moi && strtolower( $coso_cu ) !== strtolower( $coso_moi )
				&& ! $chi_doi_thu_tu && ! self::co_quan_tri_nv( $u ) ) {
				return array( 'ok' => false,
					'error' => 'Đổi cửa hàng của một người là chuyển công và lương giữa hai cửa hàng — '
						. self::LOI_QT . ' Cần người này làm thêm ở cửa hàng bạn thì tích thêm ô cơ sở ấy.' );
			}
			/* Chốt 4: chỉ sửa người của cơ sở mình — nhưng tính CẢ cơ sở người ta tích thêm.
			   Anh Thắng 31/08/2026 chốt: người làm hai nơi thì CẢ HAI cửa hàng sửa được. Hỏi mỗi
			   cơ sở đứng đầu là dựng lại đúng cái thứ bậc chính/phụ vừa bỏ. */
			if ( ! self::co_quyen_ho_so( $u, $cu ) ) {
				return array( 'ok' => false, 'error' => 'Hồ sơ này không thuộc cơ sở bạn phụ trách.' );
			}
		} elseif ( '' !== $coso_moi && ! self::co_quyen_coso( $u, $coso_moi ) ) {
			return array( 'ok' => false, 'error' => 'Bạn không phụ trách cơ sở "' . $coso_moi . '".' );
		}

		$cho_phep = array( 'ho_ten', 'cua_hang', 'pin_may', 'sdt', 'ngay_sinh', 'gioi_tinh', 'cccd',
			'dia_chi', 'nguoi_lien_he_khan', 'sdt_khan', 'chuc_vu', 'ngay_vao_lam',
			'trang_thai_lam_viec', 'loai_hop_dong', 'nhiem_vu', 'coso_phu', 'coso_ql',
			'pin_dang_nhap' );
		if ( self::co_xem_luong( $u ) ) {
			$cho_phep = array_merge( $cho_phep, self::O_LUONG );
		}
		/* Danh sách CHO PHÉP, không phải danh sách CHẶN. Với danh sách chặn thì mỗi cột mới thêm
		   vào bảng là một ô người ta ghi được mà không ai nhớ ra phải chặn. */
		$ghi = array();
		foreach ( $cho_phep as $o ) {
			if ( ! array_key_exists( $o, $dat ) ) { continue; }
			$v = $dat[ $o ];
			if ( in_array( $o, array( 'ngay_sinh', 'ngay_vao_lam' ), true ) ) {
				$v = preg_match( '/^\d{4}-\d{2}-\d{2}$/', trim( (string) $v ) ) ? trim( (string) $v ) : null;
			} elseif ( 'luong_co_ban' === $o ) {
				$v = self::so_tien( $v );
			} else {
				$v = trim( (string) $v );
			}
			$ghi[ $o ] = $v;
		}
		if ( isset( $ghi['cua_hang'] ) ) { $ghi['cua_hang'] = self::chuan_coso( $ghi['cua_hang'] ); }

		/* 🔴 CHẶN PIN TRÙNG — anh Thắng 08/09/2026: *"chặn trường hợp tạo mã pin trùng nhé"*.
		   Đường này (màn wp-admin) trước đây ghi thẳng cả hai ô PIN, không soát gì: màn ngoài web
		   có soát PIN đăng nhập, nên cùng một việc mà hai cửa cho ra hai kết quả khác nhau.
		   ⚠️ Trống = KHÔNG ĐỔI/không đụng, nên `pin_trung_loi()` bỏ qua ô trống — coi trống là
		      phải soát thì mọi lượt sửa số điện thoại cũng bị chối oan. */
		$cs_soat = self::ds_coso_hs( array(
			'cua_hang' => isset( $ghi['cua_hang'] ) ? $ghi['cua_hang']
				: ( $cu ? $cu['cua_hang'] : '' ),
			'coso_phu' => isset( $ghi['coso_phu'] ) ? $ghi['coso_phu']
				: ( $cu && isset( $cu['coso_phu'] ) ? $cu['coso_phu'] : '' ),
			'coso_ql' => isset( $ghi['coso_ql'] ) ? $ghi['coso_ql']
				: ( $cu && isset( $cu['coso_ql'] ) ? $cu['coso_ql'] : '' ),
		) );
		$loi_pin = self::pin_trung_loi( $ghi, $ma, $cs_soat );
		if ( '' !== $loi_pin ) { return array( 'ok' => false, 'error' => $loi_pin ); }

		$ghi['cap_nhat'] = current_time( 'mysql' );

		if ( $cu ) {
			$ok = $wpdb->update( VHCC_DB::t( 'nhan_vien' ), $ghi, array( 'ma_nv' => $ma ) );
			return ( false === $ok )
				? array( 'ok' => false, 'error' => 'MySQL: ' . $wpdb->last_error )
				: array( 'ok' => true, 'tao_moi' => false );
		}
		$ghi['ma_nv'] = $ma;
		$ok = $wpdb->insert( VHCC_DB::t( 'nhan_vien' ), $ghi );
		return ( false === $ok )
			? array( 'ok' => false, 'error' => 'MySQL: ' . $wpdb->last_error )
			: array( 'ok' => true, 'tao_moi' => true );
	}

	/**
	 * CỬA HÀNG TRƯỞNG THÊM NGƯỜI MỚI VÀO CƠ SỞ CỦA MÌNH.
	 *
	 * =========================================================================================
	 * 🔴 VÌ SAO KHÔNG NỚI `luu_ho_so()` RA MÀ LÀM MỘT ĐƯỜNG RIÊNG.
	 * =========================================================================================
	 * Anh Thắng 28/08/2026: *"thêm phần cửa hàng trưởng bổ sung nhân sự cho cửa hàng mình"*, và
	 * trước đó: *"Khi thêm nó sẽ đẩy sang nhân sự và tự tạo mã NV tạm (Admin sẽ sửa lại sau),
	 * để tài khoản có thể dùng được ngay và đẩy lên máy chấm công"*.
	 *
	 * `luu_ho_so()` chặn tạo mới ở bậc Quản lý, và chốt ấy ĐÚNG: mã NV là mã dùng chung cả
	 * chuỗi, cấp bừa thì hai cửa hàng cấp trùng nhau và không ai biết cho tới kỳ lương. Hạ chốt
	 * đó xuống bậc Cửa hàng trưởng là mở luôn cả đường sửa lương, đổi cơ sở, cấp mã chuẩn.
	 *
	 * Nên: một cửa HẸP riêng. Cửa này chỉ làm được đúng một việc — mở hồ sơ TẠM cho người vừa
	 * vào làm ở CƠ SỞ MÌNH — và mã nó cấp mang tiền tố `TAM-` để Admin lọc ra đổi lại sau.
	 *
	 * ⚠️ BẮT BUỘC CĂN CƯỚC, VÀ ĐÓ LÀ ĐIỀU KIỆN ĐỂ "DÙNG ĐƯỢC NGAY".
	 *    Hệ không cấp PIN qua tay ai cả: người mới tự vào trang chấm công → "Quên PIN" → gõ Họ
	 *    tên + Căn cước của chính mình → tự đặt PIN. Thiếu căn cước là đường ấy tắc, và tài
	 *    khoản vừa tạo thành một hồ sơ chết mà cửa hàng trưởng tưởng đã xong.
	 *    Cách này cũng có nghĩa KHÔNG AI phải đọc PIN của ai — kể cả cửa hàng trưởng.
	 *
	 * ⚠️ CĂN CƯỚC TRÙNG THÌ CHỐI, VÀ CHỈ RA NGƯỜI ĐANG CÓ. Một người làm hai cơ sở là chuyện
	 *    thường ở chuỗi này (anh Thắng hỏi 28/08); nhưng đó là MỘT hồ sơ khai thêm Cơ sở phụ,
	 *    không phải hai hồ sơ. Tạo hồ sơ thứ hai là nhân đôi người trên bảng lương.
	 */
	public static function them_nv_cua_hang( $u, $dat ) {
		global $wpdb;
		if ( ! VHCC_Vai::duoc( $u, 'them_nv' ) ) {
			return array( 'ok' => false, 'error' => VHCC_Vai::loi( $u, 'them_nv', 'Thêm người mới' ) );
		}
		$ten = trim( (string) ( isset( $dat['ho_ten'] ) ? $dat['ho_ten'] : '' ) );
		if ( '' === $ten ) { return array( 'ok' => false, 'error' => 'Thiếu họ tên.' ); }

		/* Cơ sở: lấy ô người ta chọn, bỏ trống thì hiểu là cơ sở của chính mình. Dù đường nào
		   cũng phải qua `co_quyen_coso` — ô chọn trên màn hình không phải là chốt. */
		$coso = self::chuan_coso( isset( $dat['cua_hang'] ) ? $dat['cua_hang'] : '' );
		if ( '' === $coso ) { $coso = self::chuan_coso( isset( $u['coso'] ) ? $u['coso'] : '' ); }
		if ( '' === $coso ) {
			return array( 'ok' => false, 'error' => 'Chưa rõ thêm vào cơ sở nào.' );
		}
		if ( ! self::co_quyen_coso( $u, $coso ) ) {
			return array( 'ok' => false, 'error' => 'Bạn không phụ trách cơ sở "' . $coso . '".' );
		}

		$cccd = preg_replace( '/\D+/', '', (string) ( isset( $dat['cccd'] ) ? $dat['cccd'] : '' ) );
		if ( strlen( $cccd ) < 9 || strlen( $cccd ) > 12 ) {
			return array( 'ok' => false, 'error' => 'Phải có số căn cước (12 số, hoặc 9 số nếu là '
				. 'CMND cũ) — đó là thứ để người mới tự lấy mã PIN ở màn "Quên PIN".' );
		}
		$trung = self::ho_so_theo_cccd( $cccd );
		if ( $trung ) {
			return array( 'ok' => false, 'error' => 'Số căn cước này đã có hồ sơ: '
				. $trung['ho_ten'] . ' (' . $trung['ma_nv'] . ', cơ sở ' . $trung['cua_hang'] . '). '
				. 'Người làm ở hai cơ sở thì khai thêm vào ô "Cơ sở phụ" của hồ sơ ấy, '
				. 'đừng mở hồ sơ thứ hai — bảng lương sẽ tính người đó hai lần.' );
		}

		$ma = self::ma_tam( $coso );
		if ( '' === $ma ) {
			return array( 'ok' => false, 'error' => 'Không cấp được mã tạm — thử lại.' );
		}

		$ghi = array(
			'ma_nv'                => $ma,
			'ho_ten'               => $ten,
			'cua_hang'             => $coso,
			'cccd'                 => $cccd,
			'sdt'                  => trim( (string) ( isset( $dat['sdt'] ) ? $dat['sdt'] : '' ) ),
			'gioi_tinh'            => trim( (string) ( isset( $dat['gioi_tinh'] ) ? $dat['gioi_tinh'] : '' ) ),
			'chuc_vu'              => trim( (string) ( isset( $dat['chuc_vu'] ) ? $dat['chuc_vu'] : '' ) ),
			'ngay_vao_lam'         => current_time( 'Y-m-d' ),
			'trang_thai_lam_viec'  => 'Đang làm',
			/* 🔴 PHẢI ĐẶT VAI, KHÔNG ĐƯỢC ĐỂ TRỐNG.
			   Anh Thắng 28/08/2026: *"cửa hàng đã thêm nhân viên mới, mà bên nhân sự chưa thấy
			   thông tin nhân viên đó"* — kèm ảnh hàng `TAM-FZSCVIVO-001` với cột Vai trò ghi
			   «— chưa khai —». Hồ sơ CÓ sang, nhưng trống vai.
			   Vai rỗng không phải là "chưa quyết": nó là một hồ sơ mà mọi cửa trong hệ đều phải
			   ĐOÁN xem người ấy bậc mấy — và mỗi cửa đoán một kiểu. Người mới vào làm thì vai
			   là Nhân viên; Admin nâng lên sau nếu cần. */
			'vai_tro'              => VHCC_Vai::TEN[ VHCC_Vai::NV ],
			'cap_nhat'             => current_time( 'mysql' ),
		);
		/* ⚠️ ẢNH THẺ KHÔNG BẮT BUỘC — anh Thắng 28/08/2026 chốt *"không ép buộc, nhưng không có
		   là phải đưa ra cảnh báo bù sau"*. Nên thiếu ảnh vẫn tạo hồ sơ xong; chỗ nhắc nằm ở
		   khối "chưa có ảnh thẻ" trên màn Bảng công. */
		$anh = isset( $dat['anh_the'] ) ? trim( (string) $dat['anh_the'] ) : '';
		if ( '' !== $anh ) { $ghi['anh_the'] = $anh; }
		$ok = $wpdb->insert( VHCC_DB::t( 'nhan_vien' ), $ghi );
		if ( false === $ok ) {
			return array( 'ok' => false, 'error' => 'MySQL: ' . $wpdb->last_error );
		}

		$day = self::day_len_may( $ma, $ten, $coso, $ghi['gioi_tinh'], $u, $anh );

		/**
		 * 🔴 ẢNH THẺ CŨNG LÀ MẪU ĐỐI CHIẾU KHUÔN MẶT CHO CHẤM CÔNG ONLINE.
		 *
		 * Anh Thắng 29/08/2026: *"nếu chưa có máy thì ảnh chụp đó cũng dùng để xác định face qua
		 * chấm công online"*. Ý này đã được nhắc từ 28/08/2026 ở docblock của
		 * `VHCC_Web::khoi_them_nv()` ("làm mẫu đối chiếu khuôn mặt cho chấm công online") nhưng
		 * chưa có đường nối — trước bản này, mẫu (`VHCC_Mat`) CHỈ tự lấy từ lượt chấm công ONLINE
		 * ĐẦU TIÊN, và phải qua `cho` (chờ duyệt) vì không chắc ngày đầu có đúng người thật đứng
		 * chụp không (xem `VHCC_Mat::soi()`).
		 *
		 * `$dat['vector']` là dãy đặc trưng 128 số TRÌNH DUYỆT đã tính sẵn từ chính tấm ảnh thẻ
		 * lúc chụp — máy chủ không tính lại được (không có thư viện nhận diện, xem đầu
		 * `class-vhcc-mat.php`). Không có ô này (trình duyệt cũ, thư viện chưa tải kịp, ảnh không
		 * thấy mặt) thì bỏ qua — hồ sơ vẫn tạo bình thường, mẫu để dành cho lượt chấm công đầu
		 * tiên như trước giờ.
		 *
		 * ⚠️ SEED THẲNG THÀNH 'duyet', KHÔNG QUA 'cho'. Khác lượt chấm công ẩn danh, ảnh thẻ này
		 *    chụp có Cửa hàng trưởng đứng cạnh xác nhận đúng người — bắt Kế toán duyệt lại là bắt
		 *    xác nhận một việc CHT vừa làm xong trước mặt người đó rồi.
		 *
		 * ⚠️ KHÔNG PHÂN BIỆT CÓ MÁY HAY KHÔNG. Cơ sở có máy vẫn cần chấm công online làm phương
		 *    án dự phòng lúc máy mất mạng hay đứt điện — seed mẫu luôn, không đợi biết cơ sở có
		 *    máy hay chưa.
		 */
		$mau_mat = '';
		if ( '' !== $anh && isset( $dat['vector'] ) && class_exists( 'VHCC_Mat' )
			&& method_exists( 'VHCC_Mat', 'dat_mau_tu_anh_the' )
			&& VHCC_Mat::dat_mau_tu_anh_the( $ma, $dat['vector'] ) ) {
			$mau_mat = ' Đã lấy ảnh thẻ làm mẫu đối chiếu khuôn mặt cho chấm công online.';
		}

		return array( 'ok' => true, 'ma_nv' => $ma, 'coso' => $coso, 'day_may' => $day . $mau_mat,
			'co_anh' => ( '' !== $anh ) );
	}

	/** Ảnh thẻ tối đa sau khi thu nhỏ — cạnh dài, và cỡ chuỗi data URI. */
	const ANH_CANH   = 480;
	const ANH_TOI_DA = 400000;   // ~400 KB chuỗi: quá cỡ này thì máy chấm công cũng nuốt không nổi

	/**
	 * NHẬN MỘT TỆP ẢNH THẺ TỪ BIỂU MẪU, TRẢ VỀ data URI ĐÃ THU NHỎ.
	 *
	 * =========================================================================================
	 * 🔴 THU NHỎ Ở MÁY CHỦ, VÌ MÀN QUẢN TRỊ KHÔNG CÓ MỘT DÒNG SCRIPT NÀO.
	 * =========================================================================================
	 * Bình thường ảnh được thu nhỏ ngay trên trình duyệt trước khi gửi (trạm chấm công làm thế).
	 * Màn quản trị thì cố ý không có JavaScript — nên ảnh từ điện thoại lên đây vẫn là ảnh gốc
	 * 3–5 MB. Không thu nhỏ thì cột `anh_the` phình, và cái ảnh ấy còn phải chui qua hàng đợi
	 * xuống một con ESP32 có vài trăm KB bộ nhớ.
	 *
	 * ⚠️ TRẢ VỀ LỖI CÓ CHỮ, KHÔNG TRẢ VỀ RỖNG. Ảnh là phần KHÔNG BẮT BUỘC, nên một lỗi nuốt im
	 *    sẽ thành "đã thêm người xong" mà ảnh biến mất — và không ai biết để chụp lại.
	 *
	 * @return array [ 'ok' => bool, 'anh' => data URI, 'error' => câu chối ]
	 */
	public static function rua_anh_the( $tep ) {
		$tep = (array) $tep;
		$loi = isset( $tep['error'] ) ? (int) $tep['error'] : UPLOAD_ERR_NO_FILE;
		if ( UPLOAD_ERR_NO_FILE === $loi ) { return array( 'ok' => true, 'anh' => '' ); }
		if ( UPLOAD_ERR_OK !== $loi ) {
			return array( 'ok' => false, 'anh' => '',
				'error' => 'Ảnh không tải lên được (mã lỗi ' . $loi . ') — thử ảnh nhỏ hơn.' );
		}
		$duong = isset( $tep['tmp_name'] ) ? (string) $tep['tmp_name'] : '';
		if ( '' === $duong || ! is_readable( $duong ) ) {
			return array( 'ok' => false, 'anh' => '', 'error' => 'Không đọc được tệp ảnh vừa gửi.' );
		}
		return self::rua_anh_tep( $duong );
	}

	/**
	 * LÕI RỬA ẢNH — nhận ĐƯỜNG DẪN MỘT TỆP, trả data URI đã thu nhỏ.
	 *
	 * 🔴 09/09/2026 — tách ra khỏi `rua_anh_the()` để dùng lại cho ảnh CHẤM CÔNG (anh Thắng:
	 *    *"lấy ảnh nhận diện chuẩn đặt để đẩy vào đây luôn được không"*). Hai đường vào khác
	 *    nhau — một là tệp người ta vừa tải lên, một là tệp đã nằm sẵn trong thư mục uploads —
	 *    nhưng phần rửa phải Y HỆT NHAU: cùng cạnh, cùng chất lượng, cùng trần dung lượng. Chép
	 *    đoạn này ra làm bản thứ hai là sớm muộn hai đường sinh ra hai cỡ ảnh khác nhau, mà cỡ
	 *    ảnh thì còn phải chui qua hàng đợi xuống một con ESP32 vài trăm KB bộ nhớ.
	 */
	public static function rua_anh_tep( $duong ) {
		$duong = (string) $duong;
		if ( '' === $duong || ! is_readable( $duong ) ) {
			return array( 'ok' => false, 'anh' => '', 'error' => 'Không đọc được tệp ảnh.' );
		}
		/* ⚠️ Tin phần đuôi tên tệp là tin người gửi. Hỏi CHÍNH TỆP xem nó là ảnh gì. */
		$co = @getimagesize( $duong );
		if ( ! $co || empty( $co['mime'] ) ) {
			return array( 'ok' => false, 'anh' => '', 'error' => 'Tệp này không phải ảnh.' );
		}
		if ( ! in_array( $co['mime'], array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ) {
			return array( 'ok' => false, 'anh' => '',
				'error' => 'Chỉ nhận ảnh JPG, PNG hoặc WEBP — tệp này là ' . $co['mime'] . '.' );
		}

		/* ⚠️ Gác `function_exists` cùng chỗ với lời gọi. Hosting thiếu bộ ảnh của WordPress thì
		   nói thẳng, đừng lưu đại ảnh gốc 5 MB vào cột dữ liệu. */
		if ( ! function_exists( 'wp_get_image_editor' ) ) {
			return array( 'ok' => false, 'anh' => '',
				'error' => 'Máy chủ chưa có bộ xử lý ảnh — nhờ Admin bật GD hoặc Imagick.' );
		}
		$bt = wp_get_image_editor( $duong );
		if ( is_wp_error( $bt ) ) {
			return array( 'ok' => false, 'anh' => '',
				'error' => 'Không mở được ảnh: ' . $bt->get_error_message() );
		}
		$bt->resize( self::ANH_CANH, self::ANH_CANH, false );   // false = giữ nguyên tỉ lệ
		if ( method_exists( $bt, 'set_quality' ) ) { $bt->set_quality( 82 ); }
		$tam = VHCC_DB::tep_tam( 'vhcc-anh-the' );
		$luu = $bt->save( $tam, 'image/jpeg' );
		if ( is_wp_error( $luu ) || empty( $luu['path'] ) || ! is_readable( $luu['path'] ) ) {
			return array( 'ok' => false, 'anh' => '', 'error' => 'Không lưu được ảnh sau khi thu nhỏ.' );
		}
		$noi = file_get_contents( $luu['path'] );
		@unlink( $luu['path'] );
		if ( $tam !== $luu['path'] ) { @unlink( $tam ); }
		if ( false === $noi || '' === $noi ) {
			return array( 'ok' => false, 'anh' => '', 'error' => 'Ảnh sau khi thu nhỏ bị rỗng.' );
		}
		$uri = 'data:image/jpeg;base64,' . base64_encode( $noi );
		if ( strlen( $uri ) > self::ANH_TOI_DA ) {
			return array( 'ok' => false, 'anh' => '',
				'error' => 'Ảnh vẫn quá nặng sau khi thu nhỏ — chụp lại bằng ảnh thường, đừng dùng ảnh RAW.' );
		}
		return array( 'ok' => true, 'anh' => $uri );
	}

	/**
	 * CHỨC VỤ ĐỂ CHỌN SẴN, TỪ BẬC NGƯỜI ĐANG THÊM ĐỔ XUỐNG.
	 *
	 * =========================================================================================
	 * Anh Thắng 28/08/2026: *"Thiếu chức vụ, lấy sẵn từ hệ thống (chức vụ lấy từ chức vụ của
	 * cửa hàng trưởng đi xuống)"*.
	 *
	 * Chức vụ trong sổ là chữ tự do — "Nhân viên bán hàng", "Thu ngân", "Ca trưởng"… Không có
	 * thang bậc nào cho nó, nên KHÔNG suy ra được cái nào "cao hơn" cái nào. Cái CÓ thang là
	 * VAI TRÒ. Nên luật ở đây đọc là: bày ra những chức vụ đang có thật ở cơ sở này, TRỪ chức
	 * vụ của những người mang vai CAO HƠN người đang thêm.
	 *
	 * ⚠️ LẤY TỪ CƠ SỞ NÀY, KHÔNG LẤY CẢ CHUỖI. Danh sách cả chuỗi có "Kế toán trưởng", "Giám
	 *    sát vùng" — bày ra là mời người ta chọn nhầm, và chức vụ ấy đi thẳng vào bảng lương.
	 *
	 * ⚠️ VẪN PHẢI CÓ ĐƯỜNG GÕ TAY. Cửa hàng mới mở thì sổ chưa có chức vụ nào; ô chọn rỗng mà
	 *    không gõ được là bế tắc, và người ta bỏ trống luôn ô ấy.
	 */
	/**
	 * Chức vụ khai sẵn — có ngay cả khi sổ chưa có gì để gợi ý.
	 *
	 * 🔴 PHẢI CÓ DANH SÁCH NÀY, KHÔNG CHỈ DỰA VÀO SỔ. Anh Thắng 28/08/2026 nhìn ô gợi ý và nói
	 *    *"Nhầm chức vụ rồi"* — nó bày ra "Khu vui chơi", vốn là một BỘ PHẬN. Đúng dữ liệu: sổ
	 *    thật nạp từ Sheets cũ có cột `chuc_vu` chứa lẫn tên bộ phận. Lấy nguyên xi ra là dạy
	 *    người dùng khai tiếp cái sai ấy cho người mới.
	 */
	const CHUC_VU_SAN = array( 'Nhân viên', 'Nhân viên bán hàng', 'Thu ngân', 'Ca trưởng',
		'Giám sát', 'Kỹ thuật', 'Bảo vệ', 'Tạp vụ', 'Pha chế', 'Phục vụ' );

	public static function chuc_vu_cho( $u, $coso ) {
		$cs = self::chuan_coso( $coso );
		if ( '' === $cs ) { return array(); }
		$bac_toi = class_exists( 'VHCC_Vai' ) && method_exists( 'VHCC_Vai', 'bac' )
			? (int) VHCC_Vai::bac( $u ) : 99;
		$ra = array();
		foreach ( (array) VHCC_DB::rows( 'SELECT chuc_vu, cua_hang, vai_tro, trang_thai_lam_viec'
			. ' FROM ' . VHCC_DB::t( 'nhan_vien' ) . " WHERE TRIM(chuc_vu) <> ''" ) as $r ) {
			if ( strtolower( self::chuan_coso( (string) $r['cua_hang'] ) ) !== strtolower( $cs ) ) { continue; }
			if ( self::da_nghi( $r['trang_thai_lam_viec'] ) ) { continue; }
			/* Người mang vai cao hơn mình thì chức vụ của họ cũng không phải thứ mình cấp được. */
			if ( class_exists( 'VHCC_Vai' ) && method_exists( 'VHCC_Vai', 'bac' ) ) {
				$bac_ho = (int) VHCC_Vai::bac( array( 'role' => (string) $r['vai_tro'] ) );
				if ( $bac_ho > $bac_toi ) { continue; }
			}
			$cv = trim( (string) $r['chuc_vu'] );
			if ( '' === $cv ) { continue; }
			/* 🔴 BỎ NHỮNG GIÁ TRỊ VỐN LÀ TÊN BỘ PHẬN. Sổ cũ trộn hai thứ vào một cột, và bày
			   "Khu vui chơi" ra ô Chức vụ là mời người ta chép tiếp cái nhầm ấy sang người mới.
			   Lọc ở ĐÂY chứ không đi sửa sổ: sổ là dữ liệu thật của anh Thắng, sửa hàng loạt là
			   việc khác và phải anh quyết. */
			if ( self::la_ten_bo_phan( $cv ) ) { continue; }
			/* ⚠️ GIỮ CÁCH VIẾT GẶP TRƯỚC, không để bản sau đè. Hai hồ sơ ghi "Thu ngân" và
			   "THU NGÂN" là CÙNG một chức vụ — gom làm một dòng gợi ý là đúng, nhưng bày ra bản
			   nào thì phải ổn định. Đè bừa thì danh sách đổi mặt mỗi lần có người mới nhập ẩu. */
			$k_cv = self::chu_thuong( $cv );
			if ( ! isset( $ra[ $k_cv ] ) ) { $ra[ $k_cv ] = $cv; }
		}
		/* Danh sách khai sẵn đứng TRƯỚC, rồi mới tới cái dò từ sổ — người mở ô ra thấy ngay
		   những chức vụ đúng nghĩa, không phải cuộn qua một mớ tên bộ phận cũ. */
		ksort( $ra );
		$dau = array();
		foreach ( self::CHUC_VU_SAN as $x ) {
			$k = self::chu_thuong( $x );
			if ( isset( $ra[ $k ] ) ) { unset( $ra[ $k ] ); }
			$dau[] = $x;
		}
		return array_merge( $dau, array_values( $ra ) );
	}

	/**
	 * Chuỗi này có phải tên một BỘ PHẬN không.
	 *
	 * ⚠️ So bằng `chu_thuong` chứ không `strtolower`: `strtolower` của PHP không hạ được chữ CÓ
	 *    DẤU, nên "KHU VUI CHƠI" viết hoa lọt qua và vẫn hiện ra ô Chức vụ.
	 */
	public static function la_ten_bo_phan( $s ) {
		$k = self::chu_thuong( trim( (string) $s ) );
		if ( '' === $k ) { return false; }
		if ( ! class_exists( 'VHCC_Luong' ) || ! defined( 'VHCC_Luong::BP_DS' ) ) { return false; }
		$ds = (array) constant( 'VHCC_Luong::BP_DS' );
		if ( defined( 'VHCC_Luong::BP_CHUA_XEP' ) ) { $ds[] = constant( 'VHCC_Luong::BP_CHUA_XEP' ); }
		foreach ( $ds as $x ) {
			if ( self::chu_thuong( $x ) === $k ) { return true; }
		}
		return false;
	}

	/** Ai trong cơ sở này CHƯA có ảnh thẻ — để bày ra mà bù sau. */
	public static function thieu_anh_the( $coso ) {
		$cs = self::chuan_coso( $coso );
		if ( '' === $cs ) { return array(); }
		$ra = array();
		foreach ( (array) VHCC_DB::rows( 'SELECT ma_nv, ho_ten, cua_hang, trang_thai_lam_viec,'
			. " anh_the FROM " . VHCC_DB::t( 'nhan_vien' )
			. " WHERE TRIM(ma_nv) <> ''" ) as $r ) {
			if ( strtolower( self::chuan_coso( (string) $r['cua_hang'] ) ) !== strtolower( $cs ) ) { continue; }
			/* Người đã nghỉ thì thôi — nhắc chụp ảnh một người không còn đi làm là nhiễu. */
			if ( self::da_nghi( $r['trang_thai_lam_viec'] ) ) { continue; }
			if ( '' !== trim( (string) $r['anh_the'] ) ) { continue; }
			$ra[] = array( 'ma_nv' => (string) $r['ma_nv'], 'ho_ten' => (string) $r['ho_ten'] );
		}
		return $ra;
	}

	/** Hồ sơ mang số căn cước này — null là chưa ai. So bằng CHỮ SỐ, bỏ mọi dấu cách / gạch. */
	public static function ho_so_theo_cccd( $cccd ) {
		$so = preg_replace( '/\D+/', '', (string) $cccd );
		if ( '' === $so ) { return null; }
		foreach ( (array) VHCC_DB::rows( 'SELECT ma_nv, ho_ten, cua_hang, cccd FROM '
			. VHCC_DB::t( 'nhan_vien' ) . " WHERE TRIM(cccd) <> ''" ) as $r ) {
			if ( preg_replace( '/\D+/', '', (string) $r['cccd'] ) === $so ) { return $r; }
		}
		return null;
	}

	/**
	 * Cấp một mã TẠM chưa ai dùng, dạng `TAM-<CƠ SỞ>-<số>`.
	 *
	 * ⚠️ TIỀN TỐ `TAM-` LÀ CỐ Ý, KHÔNG PHẢI CHO ĐẸP. Mã tạm mà trông giống mã chuẩn thì không ai
	 *    lọc ra được để đổi, và nó nằm lại trong bảng lương vài tháng. Nhìn là biết ngay.
	 *
	 * ⚠️ ĐẾM TỪ SỐ ĐANG CÓ, KHÔNG PHẢI TỪ SỐ HỒ SƠ. Xoá một hồ sơ tạm rồi tạo lại là cấp trùng
	 *    mã vừa xoá — mà lượt chấm công cũ vẫn mang mã ấy, nên công của người cũ chảy sang
	 *    người mới. Nên: dò tới khi gặp một mã chưa ai dùng.
	 */
	public static function ma_tam( $coso ) {
		$cs = strtoupper( preg_replace( '/[^A-Za-z0-9]+/', '', self::chuan_coso( $coso ) ) );
		if ( '' === $cs ) { $cs = 'CS'; }
		$cs = substr( $cs, 0, 8 );
		for ( $i = 1; $i <= 999; $i++ ) {
			$thu = 'TAM-' . $cs . '-' . str_pad( (string) $i, 3, '0', STR_PAD_LEFT );
			if ( ! self::ho_so( $thu ) && ! self::co_cham_cong( $thu ) ) { return $thu; }
		}
		return '';
	}

	/** Mã này đã có lượt chấm công nào chưa — kể cả khi hồ sơ đã bị xoá. */
	public static function co_cham_cong( $ma_nv ) {
		return self::so_luot_cham( $ma_nv ) > 0;
	}

	/**
	 * ĐẾM lượt chấm công của một mã.
	 *
	 * Cùng phép đếm mà `xoa_ho_so()` dùng để chối — cố ý dùng chung một hàm, để màn hỏi trước
	 * khi xoá nói ra ĐÚNG con số hệ sẽ dựa vào. Hai phép đếm viết rời nhau thì có ngày màn báo
	 * "chưa có lượt nào" mà bấm xong lại bị chối, và không ai hiểu vì sao.
	 */
	public static function so_luot_cham( $ma_nv ) {
		global $wpdb;
		$ma = trim( (string) $ma_nv );
		if ( '' === $ma ) { return 0; }
		return (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHCC_DB::t( 'cham_cong' ) . ' WHERE ma_nv=%s', $ma ) );
	}

	/**
	 * ĐẶT LỆNH XUỐNG ĐẦU ĐỌC CỦA CƠ SỞ — dùng chung cho cả ba việc add/edit/delete.
	 *
	 * Firmware (`esp32_hik_chamcong_full.ino`) đã nhận đủ cả ba action này từ trước (ISAPI
	 * UserInfo add/edit, UserInfoDetail delete-by-employeeNo) — chỉ là phía web trước đây CHỈ
	 * GỌI action `add` (lúc tạo hồ sơ), chưa có đường gọi `edit`/`delete`. Gộp chung một hàm để
	 * ba việc luôn cùng một luật tìm máy/báo tình trạng, không lệch nhau khi sửa sau này.
	 *
	 * ⚠️ KHÔNG CÓ MÁY THÌ KHÔNG PHẢI LỖI. Cơ sở chưa gắn máy, hay máy đang mất mạng, thì việc
	 *    trên web (tạo/sửa/cho nghỉ) vẫn phải xong — trả về câu nói rõ tình trạng để màn hình bày
	 *    ra, chứ không nuốt lời rồi để người ta tưởng đã xong.
	 *
	 * ⚠️ Máy chỉ nhận TÊN và MÃ (cùng ảnh nếu có). Khuôn mặt vẫn phải lấy tại máy khi KHÔNG có
	 *    ảnh — không đường nào đẩy mặt từ web xuống được nếu thiếu ảnh, và nói khác đi là hứa
	 *    một thứ không có.
	 *
	 * @param string $action 'add' | 'edit' | 'delete'.
	 */
	/**
	 * ⚠️ `$can_duyet=true` GIỮ LỆNH LẠI CHỜ ADMIN, KHÔNG ĐƯA THẲNG CHO MÁY.
	 * Anh Thắng 29/08/2026: *"trước khi đẩy xuống máy, nó sẽ gửi qua admin duyệt 1 lệnh để check
	 * đạt yêu cầu chưa trước khi đẩy"*. Chỉ `day_len_may()` (đường "Cửa hàng trưởng thêm nhanh",
	 * KHÔNG có quyền `ho_so`) truyền `true` — đó là đường DUY NHẤT một vai không có quyền hồ sơ
	 * tự đẩy được xuống máy. `sua_lai_tren_may()`/`xoa_khoi_may()` không truyền, vì cả hai đã đòi
	 * `co_sua_ho_so()` (Kế toán+) rồi — bắt Kế toán duyệt lại việc Kế toán vừa tự bấm là một vòng
	 * không ai canh thêm được gì, chỉ thêm bước bấm.
	 */
	private static function lenh_may_( $ma_nv, $ho_ten, $coso, $gioi_tinh, $u, $anh, $action, $can_duyet = false ) {
		if ( ! class_exists( 'VHCC_May' ) || ! method_exists( 'VHCC_May', 'ds_may' ) ) {
			return 'Chưa cài phần máy chấm công.';
		}
		$ds = VHCC_May::ds_may();
		$cs = strtolower( self::chuan_coso( $coso ) );
		$so = 0;
		foreach ( (array) ( isset( $ds['data'] ) ? $ds['data'] : array() ) as $m ) {
			if ( strtolower( self::chuan_coso( (string) $m['cua_hang'] ) ) !== $cs ) { continue; }
			/* Lệnh xoá chỉ cần mã — máy tự tra rồi bỏ đúng người, không cần tên/ảnh đi kèm. */
			$kem = array( 'ma_nv' => $ma_nv, 'cua_hang' => $coso );
			if ( 'delete' !== $action ) {
				/* Ảnh đi kèm LỆNH chứ không phải đi kèm hồ sơ: firmware hỏi ảnh bằng `opId` ở một
				   lượt gọi RIÊNG (xem `VHCC_MayCong::anh_cua_lenh`), vì con ESP32 không đủ bộ nhớ
				   nhận cả JSON lệnh lẫn ảnh trong một lượt. Cột `anh_b64` bị xoá ngay khi máy báo
				   xong — ảnh gốc vẫn nằm trong hồ sơ, đây chỉ là bản đi đường. */
				$kem['ho_ten']    = $ho_ten;
				$kem['gioi_tinh'] = in_array( $gioi_tinh, array( 'male', 'female' ), true ) ? $gioi_tinh : '';
				$kem['co_anh']    = ( '' !== $anh ) ? 1 : 0;
				if ( '' !== $anh ) { $kem['anh_b64'] = $anh; }
			}
			$kq = VHCC_May::dat_lenh( (string) $m['tram'], $action, $kem,
				isset( $u['name'] ) ? (string) $u['name'] : '', $can_duyet );
			if ( ! empty( $kq['ok'] ) ) { $so++; }
		}
		if ( 0 === $so ) { return 'Cơ sở này chưa gắn máy chấm công nào.'; }
		$viec = array( 'add' => 'ghi tên xuống', 'edit' => 'sửa lại thông tin trên', 'delete' => 'gỡ khỏi' );
		$cau = $can_duyet
			? 'Đã gửi lệnh ' . $viec[ $action ] . ' ' . $so . ' máy tới Admin để duyệt — '
				. 'máy CHƯA nhận được gì cho tới khi có người duyệt.'
			: 'Đã đặt lệnh ' . $viec[ $action ] . ' ' . $so . ' máy (máy nhận trong ~10 giây nếu đang online).';
		if ( 'delete' === $action ) { return $cau; }
		return $cau . ' ' . ( '' !== $anh
			? 'Ảnh thẻ đi kèm — máy tự nhận khuôn mặt, không phải gọi người ra máy chụp lại.'
			: 'CHƯA có ảnh thẻ nên khuôn mặt vẫn phải lấy trực tiếp tại máy.' );
	}

	/**
	 * Đặt lệnh ghi người này xuống đầu đọc của cơ sở — dùng lúc TẠO hồ sơ mới.
	 *
	 * 🔴 QUA ADMIN DUYỆT (`$can_duyet=true`) — đây là đường DUY NHẤT mà một Cửa hàng trưởng (vai
	 *    không có quyền `ho_so`) tự đẩy được một khuôn mặt xuống máy chấm công, qua form "Thêm
	 *    người mới vào cửa hàng" (`VHCC_NhanSu::them_nv_cua_hang()`). Trước 29/08/2026 lệnh này đi
	 *    THẲNG xuống máy — Admin không có cơ hội soi trước khi một khuôn mặt lạ được ghi vào đầu
	 *    đọc. Xem VHCC_May::duyet_lenh()/tu_choi_lenh() và khối "Chờ Admin duyệt" ở the_bang().
	 */
	private static function day_len_may( $ma_nv, $ho_ten, $coso, $gioi_tinh, $u, $anh = '' ) {
		$cau = self::lenh_may_( $ma_nv, $ho_ten, $coso, $gioi_tinh, $u, $anh, 'add', true );
		/* Câu báo lúc TẠO MỚI khác câu chung: nói rõ hồ sơ web đã xong, máy chỉ là phần thêm —
		   không có máy hay máy không nhận được cũng không phải là hồ sơ tạo hỏng. */
		if ( 'Chưa cài phần máy chấm công.' === $cau ) {
			return 'Chưa cài phần máy chấm công — hồ sơ đã tạo, chấm công online dùng được ngay.';
		}
		if ( 'Cơ sở này chưa gắn máy chấm công nào.' === $cau ) {
			return 'Cơ sở này chưa gắn máy chấm công nào — hồ sơ đã tạo, chấm công bằng điện thoại dùng được ngay.';
		}
		return $cau;
	}

	/**
	 * SỬA LẠI THÔNG TIN TRÊN MÁY — cho trường hợp gõ sai lúc tạo (tên, giới tính, ảnh thẻ).
	 *
	 * Anh Thắng 29/08/2026: *"thêm tính năng xóa, sửa trường hợp lỗi hoặc nhân viên nghỉ việc"*.
	 * Firmware đã nhận action `edit` từ trước (ISAPI UserInfo edit) — hàm này chỉ là đường GỌI
	 * nó từ web, đọc lại đúng hồ sơ hiện có (không tin dữ liệu cũ đã gửi lần trước) rồi gửi lại.
	 *
	 * ⚠️ AI ĐƯỢC SỬA THÌ ĐƯỢC GỌI LỆNH NÀY — cùng quyền với sửa hồ sơ (`co_sua_ho_so`), không
	 *    phải một quyền riêng: đây chỉ là đẩy lại đúng cái đã lưu, không phải một việc mới.
	 */
	public static function sua_lai_tren_may( $u, $ma_nv ) {
		$ma = trim( (string) $ma_nv );
		$hs = self::ho_so( $ma );
		if ( ! $hs ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ ' . $ma . '.' ); }
		if ( ! self::co_sua_ho_so( $u ) || ! self::co_quyen_coso( $u, $hs['cua_hang'] ) ) {
			return array( 'ok' => false, 'error' => 'Không có quyền với hồ sơ này.' );
		}
		$anh = trim( (string) ( isset( $hs['anh_the'] ) ? $hs['anh_the'] : '' ) );
		$cau = self::lenh_may_( $ma, (string) $hs['ho_ten'], (string) $hs['cua_hang'],
			(string) ( isset( $hs['gioi_tinh'] ) ? $hs['gioi_tinh'] : '' ), $u, $anh, 'edit' );
		return array( 'ok' => true, 'thong_bao' => $cau );
	}

	/**
	 * GỠ KHỎI MÁY CHẤM CÔNG — cho trường hợp nhân viên nghỉ việc, không xoá hồ sơ/công đã chấm.
	 *
	 * Anh Thắng 29/08/2026: *"thêm tính năng xóa... trường hợp... nhân viên nghỉ việc"*. Xoá
	 * HỒ SƠ WEB không phải đường đúng khi còn công đã chấm (xem `xoa_ho_so()`) — nhưng người đã
	 * nghỉ thì vẫn cần GỠ KHỎI MÁY để không chấm công được nữa và nhường chỗ lưu khuôn mặt cho
	 * người mới (đầu đọc Hikvision có giới hạn số khuôn mặt lưu được).
	 */
	public static function xoa_khoi_may( $u, $ma_nv ) {
		$ma = trim( (string) $ma_nv );
		$hs = self::ho_so( $ma );
		if ( ! $hs ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ ' . $ma . '.' ); }
		if ( ! self::co_sua_ho_so( $u ) || ! self::co_quyen_coso( $u, $hs['cua_hang'] ) ) {
			return array( 'ok' => false, 'error' => 'Không có quyền với hồ sơ này.' );
		}
		$cau = self::lenh_may_( $ma, '', (string) $hs['cua_hang'], '', $u, '', 'delete' );
		return array( 'ok' => true, 'thong_bao' => $cau );
	}

	/**
	 * ĐẨY HỒ SƠ VỪA TẠO XUỐNG MÁY — đường "Hồ sơ & tài khoản" (tab Admin), song song với
	 * `them_nv_cua_hang()` (đường Cửa hàng trưởng "Thêm nhanh") vốn đã có việc này từ trước.
	 *
	 * Anh Thắng 29/08/2026: *"hiện tại đẩy xuống chỉ có cửa hàng trưởng mới thấy, bổ sung bên tab
	 * admin cũng bổ sung được cho đợt đầu này"*. Trước bản này, `VHCC_Web::luu_ho_so()` (màn "Hồ
	 * sơ & tài khoản" trong quản trị chấm công) ghi thẳng vào bảng `nhan_vien`, không đụng gì tới
	 * máy chấm công hay mẫu đối chiếu khuôn mặt — hai lối tạo hồ sơ mới ra hai kết quả khác nhau.
	 *
	 * 🔴 KHÔNG QUA ADMIN DUYỆT — khác `day_len_may()`. Đường ấy `$can_duyet=true` vì Cửa hàng
	 *    trưởng KHÔNG có quyền `ho_so`; còn màn "Hồ sơ & tài khoản" chỉ người có quyền `ho_so`
	 *    (Kế toán trở lên — CHÍNH quyền để duyệt lệnh) mới vào tới nơi mà gọi hàm này. Bắt một
	 *    người tự duyệt lại việc mình vừa làm là thêm một cú bấm chứ không thêm một lớp soi nào.
	 *
	 * @param array  $u       người đang thao tác — dùng để chốt quyền và ghi "người đặt lệnh".
	 * @param string $ma_nv   mã hồ sơ VỪA GHI XONG vào bảng (đọc lại từ DB, không tin dữ liệu form).
	 * @param mixed  $vector  dãy đặc trưng khuôn mặt trình duyệt tính từ ảnh thẻ, hoặc rỗng/null
	 *                        nếu không có — xem `VHCC_NhanSu::them_nv_cua_hang()` cho cùng cơ chế.
	 */
	public static function day_ho_so_moi_len_may( $u, $ma_nv, $vector = null ) {
		$ma = trim( (string) $ma_nv );
		$hs = self::ho_so( $ma );
		if ( ! $hs ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ ' . $ma . '.' ); }
		if ( ! self::co_sua_ho_so( $u ) || ! self::co_quyen_coso( $u, $hs['cua_hang'] ) ) {
			return array( 'ok' => false, 'error' => 'Không có quyền với hồ sơ này.' );
		}
		$anh = trim( (string) ( isset( $hs['anh_the'] ) ? $hs['anh_the'] : '' ) );
		$cau = self::lenh_may_( $ma, (string) $hs['ho_ten'], (string) $hs['cua_hang'],
			(string) ( isset( $hs['gioi_tinh'] ) ? $hs['gioi_tinh'] : '' ), $u, $anh, 'add' );

		/* Cùng cơ chế "ảnh thẻ làm mẫu" của `them_nv_cua_hang()` — xem chú thích đầy đủ ở đó. */
		if ( '' !== $anh && null !== $vector && class_exists( 'VHCC_Mat' )
			&& method_exists( 'VHCC_Mat', 'dat_mau_tu_anh_the' )
			&& VHCC_Mat::dat_mau_tu_anh_the( $ma, $vector ) ) {
			$cau .= ' Đã lấy ảnh thẻ làm mẫu đối chiếu khuôn mặt cho chấm công online.';
		}
		return array( 'ok' => true, 'thong_bao' => $cau );
	}

	/**
	 * BÙ ẢNH THẺ CHO MỘT HỒ SƠ ĐÃ CÓ — cửa hẹp, chỉ đụng cột `anh_the`.
	 *
	 * Anh Thắng 07/09/2026: *"bổ sung thêm trực tiếp ảnh thẻ nhân viên trên này"*, ngay dưới
	 * khối "N người chưa có ảnh thẻ" trên màn Bảng công.
	 *
	 * 🔴 VÌ SAO KHÔNG ĐI QUA `luu_ho_so()`. Hàm ấy có một danh sách CHO PHÉP (`$cho_phep`) và
	 *    `anh_the` không nằm trong đó — cố tình, vì `luu_ho_so()` là form "Sửa hồ sơ" chung, còn
	 *    ảnh thẻ trước giờ chỉ có đường TẠO MỚI (`them_nv_cua_hang()`/`day_ho_so_moi_len_may()`
	 *    gọi từ nhánh tạo mới của `VHCC_Web::luu_ho_so()`). Nới `$cho_phep` là mở đường ẢNH THẺ
	 *    CHO CẢ FORM SỬA HỒ SƠ DÀI — không phải việc đang xin, và form ấy có nhiều trường khác
	 *    cần soi lại cẩn thận hơn trước khi thêm tệp tải lên. Một cửa RIÊNG, hẹp, chỉ làm một
	 *    việc thì rủi ro chỉ nằm gọn trong đúng cột `anh_the`.
	 *
	 * ⚠️ KHÔNG TÍNH VECTOR KHUÔN MẶT Ở ĐÂY (khác `them_nv_cua_hang()`). Khối gọi hàm này hiện
	 *    cho CẢ Admin lẫn Cửa hàng trưởng trên chính màn Bảng công — màn phải giữ nguyên luật
	 *    "KHÔNG một dòng script" cho MỌI vai (xem `VHCC_Web::khoi_thieu_anh()`). Mẫu đối chiếu
	 *    khuôn mặt cho chấm công online vẫn tự lấy được từ lượt chấm công online ĐẦU TIÊN của
	 *    người này — đường vốn có từ trước khi có ảnh thẻ, xem `VHCC_Mat::soi()`.
	 */
	public static function luu_anh_the_rieng( $u, $ma_nv, $tep ) {
		global $wpdb;
		$ma = trim( (string) $ma_nv );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu Mã NV.' ); }
		$hs = self::ho_so( $ma );
		if ( ! $hs ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ mang mã ' . $ma . '.' ); }
		if ( ! self::co_sua_ho_so( $u ) || ! self::co_quyen_coso( $u, $hs['cua_hang'] ) ) {
			return array( 'ok' => false, 'error' => 'Hồ sơ này không thuộc cơ sở bạn phụ trách.' );
		}
		$anh_kq = self::rua_anh_the( $tep );
		if ( empty( $anh_kq['ok'] ) ) {
			return array( 'ok' => false, 'error' => $anh_kq['error'] );
		}
		if ( '' === $anh_kq['anh'] ) {
			return array( 'ok' => false, 'error' => 'Chưa chọn ảnh nào — bấm chọn tệp rồi tải lại.' );
		}
		$ok = $wpdb->update( VHCC_DB::t( 'nhan_vien' ),
			array( 'anh_the' => $anh_kq['anh'], 'cap_nhat' => current_time( 'mysql' ) ),
			array( 'ma_nv' => $ma ) );
		if ( false === $ok ) { return array( 'ok' => false, 'error' => 'MySQL: ' . $wpdb->last_error ); }
		/* Đẩy luôn xuống máy — cùng đường với "sửa lại trên máy 🔄" ở trang Quản lý nhân sự,
		   nhưng khỏi bắt bấm thêm một lượt riêng ngay sau khi vừa tải ảnh xong. */
		$day = self::day_ho_so_moi_len_may( $u, $ma, null );
		return array( 'ok' => true, 'thong_bao' => 'Đã lưu ảnh thẻ cho ' . $hs['ho_ten'] . '.'
			. ( ! empty( $day['ok'] ) ? ' ' . $day['thong_bao'] : '' ) );
	}

	/**
	 * LẤY ẢNH CHẤM CÔNG LÀM ẢNH THẺ — cùng cửa hẹp với `luu_anh_the_rieng()`.
	 *
	 * 🔴 09/09/2026 — anh Thắng: *"lấy ảnh nhận diện chuẩn đặt để đẩy vào đây luôn được không"*.
	 *    Tấm nào là "chuẩn" thì `VHCC_Mat::anh_chuan_cho()` quyết (theo khoảng cách `d` nhỏ
	 *    nhất trong những lượt kết luận 'khop') — xem chú thích ở đó.
	 *
	 * ⚠️ KHÔNG GHI ĐÈ ảnh thẻ đang có. Ảnh chấm công là ảnh chụp tại chỗ; ảnh thẻ do người ta
	 *    chụp tử tế thì tốt hơn hẳn. Đè lên là thay thứ tốt bằng thứ tạm, một cách im lặng.
	 * ⚠️ Gác quyền Y HỆT đường tải tay: cùng `co_sua_ho_so` + `co_quyen_coso`. Một cửa mới mà
	 *    gác nhẹ hơn cửa cũ là cửa cũ thành vô nghĩa.
	 * ⚠️ Lời gọi `VHCC_Mat` gác bằng `class_exists`/`method_exists` NGAY TRONG hàm này (luật
	 *    `tools/test/kiem-goi-cheo.php`): gỡ lớp nhận diện ra thì đường này tự tắt, không nổ.
	 */
	public static function anh_the_tu_cham( $u, $ma_nv, $day_may = true ) {
		global $wpdb;
		$ma = trim( (string) $ma_nv );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu Mã NV.' ); }
		$hs = self::ho_so( $ma );
		if ( ! $hs ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ mang mã ' . $ma . '.' ); }
		if ( ! self::co_sua_ho_so( $u ) || ! self::co_quyen_coso( $u, $hs['cua_hang'] ) ) {
			return array( 'ok' => false, 'error' => 'Hồ sơ này không thuộc cơ sở bạn phụ trách.' );
		}
		if ( '' !== trim( (string) $hs['anh_the'] ) ) {
			return array( 'ok' => false, 'error' => $hs['ho_ten'] . ' ĐÃ CÓ ảnh thẻ rồi — '
				. 'không đè lên. Muốn thay thì tải ảnh mới lên trong hồ sơ.' );
		}
		if ( ! class_exists( 'VHCC_Mat' ) || ! method_exists( 'VHCC_Mat', 'anh_chuan_cho' )
			|| ! method_exists( 'VHCC_Mat', 'tep_anh' ) ) {
			return array( 'ok' => false, 'error' => 'Chưa bật phần đối chiếu khuôn mặt nên không '
				. 'biết tấm nào là tấm rõ mặt. Tải ảnh thẻ lên bằng tay.' );
		}
		$a = VHCC_Mat::anh_chuan_cho( $ma );
		if ( '' === $a['duong'] ) {
			return array( 'ok' => false, 'error' => $hs['ho_ten'] . ' chưa có lượt chấm công nào '
				. 'ĐƯỢC ĐỐI CHIẾU KHỚP với mẫu (hoặc ảnh của mấy lượt ấy đã bị dọn). Chưa có gì '
				. 'để lấy — tải ảnh thẻ lên bằng tay.' );
		}
		$tep = VHCC_Mat::tep_anh( $a['duong'] );
		if ( '' === $tep ) {
			return array( 'ok' => false, 'error' => 'Tệp ảnh của lượt ' . $a['ngay'] . ' không còn '
				. 'đọc được trên máy chủ.' );
		}
		$kq = self::rua_anh_tep( $tep );
		if ( empty( $kq['ok'] ) || '' === $kq['anh'] ) {
			return array( 'ok' => false, 'error' => isset( $kq['error'] ) ? $kq['error'] : 'Không rửa được ảnh.' );
		}
		$ok = $wpdb->update( VHCC_DB::t( 'nhan_vien' ),
			array( 'anh_the' => $kq['anh'], 'cap_nhat' => current_time( 'mysql' ) ),
			array( 'ma_nv' => $ma ) );
		if ( false === $ok ) { return array( 'ok' => false, 'error' => 'MySQL: ' . $wpdb->last_error ); }
		$cau = 'Đã lấy ảnh chấm công ngày ' . $a['ngay'] . ' (lệch '
			. number_format( (float) $a['d'], 3 ) . ' — càng nhỏ càng rõ mặt) làm ảnh thẻ cho '
			. $hs['ho_ten'] . '.';

		/* 🔴 09/09/2026 — HAI VIỆC, HAI NÚT. Anh Thắng: *"nên tách ra 2 phần, vì 1 số cơ sở không
		   có máy chấm công, việc đẩy sẽ sinh ra lệnh thừa"*.
		   Lệnh thừa KHÔNG sinh ra thật (`lenh_may_()` không máy nào thì không lệnh nào). Nhưng
		   gộp hai việc vào một nút vẫn sai ở chỗ khác: lưu ảnh là việc TRONG phần mềm, lùi được
		   bằng một lượt sửa hồ sơ; đẩy xuống máy là việc ĐI RA NGOÀI, tới một cái máy đang chạy ở
		   cửa hàng, và gỡ thì phải qua lệnh `delete`. Hai mức hậu quả khác nhau thì phải là hai
		   quyết định khác nhau — nhất là khi người ta chỉ muốn dọn cho xong cột ảnh thẻ, chưa
		   muốn động vào máy.
		   ⚠️ Mặc định VẪN đẩy (`$day_may = true`) để mấy đường gọi cũ không đổi hành vi. */
		if ( $day_may ) {
			$day = self::day_ho_so_moi_len_may( $u, $ma, null );
			if ( ! empty( $day['ok'] ) ) { $cau .= ' ' . $day['thong_bao']; }
		} else {
			$cau .= ' CHƯA đẩy xuống máy chấm công — ảnh mới chỉ nằm trong hồ sơ.';
		}
		return array( 'ok' => true, 'thong_bao' => $cau );
	}

	/**
	 * XOÁ hồ sơ.
	 * ⚠️ CHẶN khi người đó CÒN chấm công. Xoá hồ sơ mà giữ lại chấm công là bảng lương có mã
	 *    không tra ra được tên — người thật, công thật, mà không biết trả cho ai. Muốn cho nghỉ
	 *    thì đổi "Trạng thái làm việc", đừng xoá.
	 */
	public static function xoa_ho_so( $u, $ma_nv ) {
		global $wpdb;
		/* 🔴 CHỈ ADMIN — cùng bậc với đổi Mã NV, cùng một lý do: cả hai đều làm dữ liệu cũ mất
		   chỗ bám. Trước đây bậc Quản lý. Chốt "còn chấm công thì không xoá" ở dưới VẪN GIỮ —
		   hai tầng, không thay nhau. */
		if ( ! VHCC_Vai::duoc( $u, 'xoa_ho_so' ) ) {
			return array( 'ok' => false, 'error' => 'Xoá hẳn một hồ sơ là bỏ chỗ bám của mọi dữ liệu '
				. 'cũ mang mã ấy — chỉ Admin xoá được. Cho nghỉ việc thì đổi "Trạng thái làm việc".' );
		}
		$ma = trim( (string) $ma_nv );
		$so = self::so_luot_cham( $ma );
		if ( $so > 0 ) {
			return array( 'ok' => false, 'error' => 'Người này còn ' . $so . ' lượt chấm công. '
				. 'Xoá hồ sơ là bảng lương có mã mà không tra ra tên. Muốn cho nghỉ thì đổi '
				. '"Trạng thái làm việc" thành Đã nghỉ.' );
		}
		$wpdb->delete( VHCC_DB::t( 'nhan_vien' ), array( 'ma_nv' => $ma ) );
		return array( 'ok' => true );
	}

	/** Xoá nhiều hồ sơ. Từng cái đi qua ĐÚNG chốt của xoa_ho_so — không có đường tắt hàng loạt. */
	public static function xoa_nhieu_ho_so( $u, $ds_ma ) {
		$xong = array();
		$bo = array();
		foreach ( (array) $ds_ma as $ma ) {
			$r = self::xoa_ho_so( $u, $ma );
			if ( ! empty( $r['ok'] ) ) { $xong[] = trim( (string) $ma ); }
			else { $bo[] = trim( (string) $ma ) . ': ' . $r['error']; }
		}
		return array( 'ok' => true, 'xong' => $xong, 'bo' => $bo );
	}

	/**
	 * CHO NGHỈ VIỆC — đường ĐÚNG thay cho xoá hồ sơ.
	 * Giữ nguyên hồ sơ và toàn bộ chấm công; chỉ đổi trạng thái. Nhờ vậy bảng lương tháng cũ vẫn
	 * tra ra tên, mà người đó không còn hiện trong danh sách đang làm.
	 */
	public static function dat_nghi_viec( $u, $ma_nv, $ngay_nghi = '', $ly_do = '' ) {
		global $wpdb;
		$ma = trim( (string) $ma_nv );
		$cu = self::ho_so( $ma );
		if ( ! $cu ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ ' . $ma . '.' ); }
		if ( ! self::co_sua_ho_so( $u ) || ! self::co_quyen_coso( $u, $cu['cua_hang'] ) ) {
			return array( 'ok' => false, 'error' => 'Không có quyền với hồ sơ này.' );
		}
		$gc = 'Đã nghỉ';
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', trim( (string) $ngay_nghi ) ) ) {
			$gc .= ' từ ' . trim( (string) $ngay_nghi );
		}
		if ( '' !== trim( (string) $ly_do ) ) { $gc .= ' — ' . trim( (string) $ly_do ); }
		$wpdb->update( VHCC_DB::t( 'nhan_vien' ),
			array( 'trang_thai_lam_viec' => $gc, 'cap_nhat' => current_time( 'mysql' ) ),
			array( 'ma_nv' => $ma ) );
		return array( 'ok' => true, 'trangThai' => $gc );
	}

	/**
	 * XEM TRƯỚC khi đổi mã NV — hàm CHỈ ĐỌC.
	 *
	 * ⚠️ Phải có bước xem trước vì đổi mã là sửa MỌI hàng chấm công đã có của người đó. Đổi rồi mới
	 *    thấy sai thì không có đường lùi: hàng cũ đã mang mã mới, không phân biệt được với hàng
	 *    vốn thuộc mã mới.
	 */
	public static function xem_truoc_doi_ma( $u, $ma_cu, $ma_moi ) {
		global $wpdb;
		$cu  = trim( (string) $ma_cu );
		$moi = trim( (string) $ma_moi );
		if ( '' === $cu || '' === $moi ) { return array( 'ok' => false, 'error' => 'Thiếu mã cũ hoặc mã mới.' ); }
		if ( strtolower( $cu ) === strtolower( $moi ) ) {
			return array( 'ok' => false, 'error' => 'Hai mã giống nhau.' );
		}
		$hs = self::ho_so( $cu );
		if ( ! $hs ) { return array( 'ok' => false, 'error' => 'Không thấy hồ sơ mã ' . $cu . '.' ); }
		if ( self::ho_so( $moi ) ) {
			return array( 'ok' => false, 'error' => 'Mã mới "' . $moi . '" ĐÃ có hồ sơ khác dùng. '
				. 'Đổi vào là gộp công hai người.' );
		}
		$so_cc = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHCC_DB::t( 'cham_cong' ) . ' WHERE ma_nv=%s', $cu ) );
		$coso_lq = $wpdb->get_col( $wpdb->prepare(
			'SELECT DISTINCT coso FROM ' . VHCC_DB::t( 'cham_cong' ) . ' WHERE ma_nv=%s', $cu ) );
		$so_lich = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHCC_DB::t( 'lich_cv' ) . ' WHERE ma_nv=%s', $cu ) );
		$so_pq = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHCC_DB::t( 'phan_quyen' ) . ' WHERE LOWER(ma_cc_online)=LOWER(%s)', $cu ) );
		/* Mã song song: nếu mã cũ đang được khai là chạy song song với mã khác thì đổi mã làm hỏng
		   cặp đó. Nói ra trước, đừng để phát hiện sau. */
		$ss = VHCC_DB::rows( $wpdb->prepare(
			'SELECT * FROM ' . VHCC_DB::t( 'ma_song_song' )
			. ' WHERE LOWER(ma_a)=LOWER(%s) OR LOWER(ma_b)=LOWER(%s)', $cu, $cu ) );
		return array( 'ok' => true, 'maCu' => $cu, 'maMoi' => $moi, 'hoTen' => $hs['ho_ten'],
			'soHangChamCong' => $so_cc, 'coSoLienQuan' => array_values( (array) $coso_lq ),
			'soOLich' => $so_lich, 'soDongPhanQuyen' => $so_pq, 'maSongSong' => $ss,
			'canhBao' => $ss ? 'Mã này đang khai chạy song song — đổi mã sẽ làm cặp mã đó trỏ sai.' : '' );
	}

	/**
	 * ĐỔI MÃ NV. Chỉ Admin/Quản lý, và phải có quyền trên MỌI cơ sở người đó có mặt.
	 *
	 * ⚠️ Người làm nhiều cơ sở: đổi mã phải sửa cả những cơ sở kia. Cho người chỉ quản một cơ sở
	 *    làm là họ ghi được vào dữ liệu cơ sở khác.
	 * ⚠️ KHÔNG đụng máy chấm công. Bên Apps Script hàm này còn xoá/tạo lại người trên máy Hikvision
	 *    (nên nó đòi có ảnh trước khi xoá). Ở đây phần máy vẫn do Apps Script + Firebase lo, nên
	 *    hàm này CHỈ đổi dữ liệu web — và phải nói rõ, không thì người dùng tưởng máy cũng đã đổi.
	 */
	public static function doi_ma_nv( $u, $ma_cu, $ma_moi ) {
		global $wpdb;
		/* 🔴 CHỈ ADMIN. Anh Thắng 27/08/2026: *"Mã NV thì cố định chỉ có admin chỉnh được thôi"*.
		   Trước đây `co_quan_tri_nv()` (bậc Quản lý) — nay siết lên bậc Admin qua quyền riêng
		   `doi_ma_nv`. Đây là THU HẸP quyền có chủ ý: Quản lý mất một việc họ từng làm được. */
		if ( ! VHCC_Vai::duoc( $u, 'doi_ma_nv' ) ) {
			return array( 'ok' => false, 'error' => 'Mã NV là khoá của mọi hàng chấm công và mọi dòng '
				. 'lương đã có — chỉ Admin đổi được.' );
		}
		$xt = self::xem_truoc_doi_ma( $u, $ma_cu, $ma_moi );
		if ( empty( $xt['ok'] ) ) { return $xt; }
		$cu  = $xt['maCu'];
		$moi = $xt['maMoi'];
		foreach ( $xt['coSoLienQuan'] as $cs ) {
			if ( ! self::co_quyen_coso( $u, $cs ) ) {
				return array( 'ok' => false, 'error' => 'Người này còn có mặt ở ' . $cs
					. ' — đổi mã phải sửa cả nơi đó, nên chỉ Admin làm được.' );
			}
		}
		foreach ( array( 'nhan_vien' => 'ma_nv', 'cham_cong' => 'ma_nv', 'lich_cv' => 'ma_nv',
			'doi_lich_cv' => 'ma_nv', 'cham_cong_nhiem_vu' => 'ma_nv', 'tang_cuong' => 'ma_nv',
			'ghi_chu' => 'ma_nv' ) as $bang => $cot ) {
			$wpdb->query( $wpdb->prepare(
				'UPDATE ' . VHCC_DB::t( $bang ) . " SET $cot=%s WHERE $cot=%s", $moi, $cu ) );
		}
		$wpdb->query( $wpdb->prepare(
			'UPDATE ' . VHCC_DB::t( 'phan_quyen' ) . ' SET ma_cc_online=%s WHERE LOWER(ma_cc_online)=LOWER(%s)',
			$moi, $cu ) );
		return array( 'ok' => true, 'maCu' => $cu, 'maMoi' => $moi,
			'daSua' => $xt['soHangChamCong'] . ' hàng chấm công, ' . $xt['soOLich'] . ' ô lịch',
			'canhBao' => 'Chỉ đổi dữ liệu trên web. Người trên MÁY chấm công vẫn mang mã cũ — '
				. 'xoá/tạo lại trên máy làm ở màn "Máy & Firmware".' );
	}

	/**
	 * XEM TRƯỚC nhập nhân sự hàng loạt — CHỈ ĐỌC, không ghi một dòng nào.
	 * Trả từng dòng kèm việc sẽ làm (thêm / cập nhật / bỏ) và lý do bỏ.
	 */
	public static function xem_truoc_nhap( $u, $ds ) {
		if ( ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false, 'error' => 'Nhập nhân sự toàn chuỗi — ' . self::LOI_QT );
		}
		$ra = array();
		$thay = array();
		foreach ( (array) $ds as $i => $d ) {
			$d = (array) $d;
			$ma = trim( isset( $d['ma_nv'] ) ? (string) $d['ma_nv'] : '' );
			$dong = array( 'dong' => (int) $i + 1, 'maNV' => $ma,
				'hoTen' => trim( isset( $d['ho_ten'] ) ? (string) $d['ho_ten'] : '' ),
				'cuaHang' => self::chuan_coso( isset( $d['cua_hang'] ) ? $d['cua_hang'] : '' ) );
			if ( '' === $ma ) { $dong['viec'] = 'bỏ'; $dong['vaoSao'] = 'thiếu Mã NV'; $ra[] = $dong; continue; }
			/* Trùng mã TRONG CHÍNH tệp nhập: hai dòng cùng mã là một cái ghi đè cái kia mà không
			   ai thấy. Bắt ở bước xem trước, đừng để chạy xong mới biết mất một dòng. */
			if ( isset( $thay[ strtolower( $ma ) ] ) ) {
				$dong['viec'] = 'bỏ';
				$dong['vaoSao'] = 'trùng mã với dòng ' . $thay[ strtolower( $ma ) ] . ' trong cùng tệp';
				$ra[] = $dong; continue;
			}
			$thay[ strtolower( $ma ) ] = (int) $i + 1;
			$dong['viec'] = self::ho_so( $ma ) ? 'cập nhật' : 'thêm';
			$ra[] = $dong;
		}
		$dem = array( 'them' => 0, 'capNhat' => 0, 'bo' => 0 );
		foreach ( $ra as $x ) {
			if ( 'thêm' === $x['viec'] ) { $dem['them']++; }
			elseif ( 'cập nhật' === $x['viec'] ) { $dem['capNhat']++; }
			else { $dem['bo']++; }
		}
		return array( 'ok' => true, 'dong' => $ra, 'dem' => $dem );
	}

	/**
	 * NHẬP NHÂN SỰ HÀNG LOẠT. Từng dòng đi qua ĐÚNG `luu_ho_so` — không có đường ghi tắt.
	 * ⚠️ Đòi chạy `xem_truoc_nhap` sạch trước: `$xac_nhan` phải là số dòng mà bước xem trước đếm
	 *    được. Lệch số nghĩa là tệp đã đổi giữa hai bước, và lúc đó người bấm không biết mình đang
	 *    nhập cái gì.
	 */
	public static function nhap_hang_loat( $u, $ds, $xac_nhan = null ) {
		if ( ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false, 'error' => 'Nhập nhân sự toàn chuỗi — ' . self::LOI_QT );
		}
		$xt = self::xem_truoc_nhap( $u, $ds );
		if ( empty( $xt['ok'] ) ) { return $xt; }
		$se_ghi = $xt['dem']['them'] + $xt['dem']['capNhat'];
		if ( null !== $xac_nhan && (int) $xac_nhan !== $se_ghi ) {
			return array( 'ok' => false, 'error' => 'Số dòng sẽ ghi (' . $se_ghi . ') khác số đã xem '
				. 'trước (' . (int) $xac_nhan . ') — tệp đã đổi giữa hai bước. Xem lại rồi nhập.' );
		}
		$xong = array();
		$bo = array();
		$thay = array();
		foreach ( (array) $ds as $i => $d ) {
			$d = (array) $d;
			$ma = trim( isset( $d['ma_nv'] ) ? (string) $d['ma_nv'] : '' );
			if ( '' === $ma || isset( $thay[ strtolower( $ma ) ] ) ) {
				$bo[] = 'dòng ' . ( (int) $i + 1 ) . ( '' === $ma ? ': thiếu Mã NV' : ': trùng mã trong tệp' );
				continue;
			}
			$thay[ strtolower( $ma ) ] = 1;
			$r = self::luu_ho_so( $u, $d );
			if ( ! empty( $r['ok'] ) ) { $xong[] = $ma; }
			else { $bo[] = 'dòng ' . ( (int) $i + 1 ) . ' (' . $ma . '): ' . $r['error']; }
		}
		return array( 'ok' => true, 'xong' => $xong, 'bo' => $bo );
	}

	/** Bộ phận + nhóm lương của MỌI cơ sở — một bảng cho màn quản trị. */
	public static function bo_phan_va_coso() {
		$out = array();
		foreach ( self::ds_coso() as $cs ) {
			$nh = VHCC_Luong::nhom_coso( $cs );
			$out[] = array( 'coSo' => $cs, 'boPhan' => VHCC_Luong::bo_phan_cua( $cs ),
				'nhom' => $nh ? $nh['ten'] : '', 'theoGio' => VHCC_Luong::coso_tinh_theo_gio( $cs ),
				'laVanPhong' => VHCC_Luong::la_van_phong( $cs ) );
		}
		return $out;
	}

	/**
	 * Nhiệm vụ của một người TẠI một cơ sở, cho một ngày.
	 * ⚠️ Nhiệm vụ chỉ có nghĩa ở Nhóm Máy Tự Động — cơ sở khác thì từ chối, đừng ghi một giá trị
	 *    không ảnh hưởng gì rồi để người ta tưởng đã khai xong.
	 */
	public static function dat_nhiem_vu( $u, $ngay, $coso, $ma_nv, $nhiem_vu ) {
		global $wpdb;
		$coso = self::chuan_coso( $coso );
		/* Hỏi `lich_lam`, không hỏi quyền HỒ SƠ: khai nhiệm vụ NGÀY là việc vận hành hằng ngày
		   của cửa hàng — cùng loại với xếp lịch — chứ không phải sửa hồ sơ nhân sự. */
		if ( ! VHCC_Vai::duoc( $u, 'lich_lam' ) || ! self::co_quyen_coso( $u, $coso ) ) {
			return array( 'ok' => false, 'error' => 'Không có quyền cơ sở này.' );
		}
		if ( ! VHCC_Luong::la_may_tu_dong( $coso ) ) {
			return array( 'ok' => false, 'error' => 'Nhiệm vụ chỉ có nghĩa ở Nhóm Máy Tự Động. '
				. 'Cơ sở "' . $coso . '" không thuộc nhóm đó nên khai vào cũng không đổi cách tính công.' );
		}
		$ngay = trim( (string) $ngay );
		$ma = trim( (string) $ma_nv );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $ngay ) || '' === $ma ) {
			return array( 'ok' => false, 'error' => 'Thiếu ngày hoặc mã NV.' );
		}
		$nv = trim( (string) $nhiem_vu );
		$bang = VHCC_DB::t( 'cham_cong_nhiem_vu' );
		$cu = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM $bang WHERE ngay=%s AND LOWER(coso)=LOWER(%s) AND ma_nv=%s", $ngay, $coso, $ma ) );
		$ghi = array( 'ngay' => $ngay, 'coso' => $coso, 'ma_nv' => $ma, 'nhiem_vu' => $nv,
			'ghi_luc' => current_time( 'mysql' ),
			'nguoi_ghi' => isset( $u['name'] ) ? (string) $u['name'] : '' );
		// Ghi ĐÈ, không thêm dòng thứ hai cho cùng (ngày, cơ sở, mã).
		if ( $cu ) { $wpdb->update( $bang, $ghi, array( 'id' => (int) $cu ) ); }
		else       { $wpdb->insert( $bang, $ghi ); }
		return array( 'ok' => true, 'nhiemVu' => $nv );
	}

	/** Mã đã CHẤM CÔNG mà chưa có hồ sơ — người thật, công thật, mà bảng lương không tra ra tên. */
	public static function ds_chua_co_ho_so( $u ) {
		global $wpdb;
		$out = array();
		foreach ( VHCC_DB::rows(
			'SELECT c.coso, c.ma_nv, MAX(c.ho_ten) ho_ten, COUNT(*) so, MAX(c.ngay) ngay_cuoi FROM '
			. VHCC_DB::t( 'cham_cong' ) . ' c LEFT JOIN ' . VHCC_DB::t( 'nhan_vien' ) . ' n'
			. ' ON n.ma_nv = c.ma_nv WHERE n.id IS NULL GROUP BY c.coso, c.ma_nv ORDER BY so DESC' ) as $r ) {
			if ( ! self::co_quyen_coso( $u, $r['coso'] ) ) { continue; }
			$out[] = $r;
		}
		return $out;
	}

	public static function ds_ma_song_song() {
		return VHCC_DB::rows( 'SELECT * FROM ' . VHCC_DB::t( 'ma_song_song' ) . ' ORDER BY id DESC' );
	}

	public static function bo_ma_song_song( $u, $ma_a, $ma_b ) {
		global $wpdb;
		if ( ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false, 'error' => 'Mã song song ảnh hưởng cả chuỗi — ' . self::LOI_QT );
		}
		$so = $wpdb->query( $wpdb->prepare(
			'DELETE FROM ' . VHCC_DB::t( 'ma_song_song' )
			. ' WHERE (LOWER(ma_a)=LOWER(%s) AND LOWER(ma_b)=LOWER(%s))'
			. ' OR (LOWER(ma_a)=LOWER(%s) AND LOWER(ma_b)=LOWER(%s))',
			$ma_a, $ma_b, $ma_b, $ma_a ) );
		return ( 0 === (int) $so )
			? array( 'ok' => false, 'error' => 'Không thấy cặp mã này.' )
			: array( 'ok' => true );
	}

	/** Xếp bộ phận cho một cơ sở. Bộ phận quyết định công thức lương -> chỉ Admin/Quản lý. */
	public static function xep_bo_phan( $u, $coso, $bo_phan, $theo_gio = null ) {
		global $wpdb;
		if ( ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false,
				'error' => 'Bộ phận quyết định CÔNG THỨC LƯƠNG của cả cơ sở — ' . self::LOI_QT );
		}
		$coso = self::chuan_coso( $coso );
		if ( '' === $coso ) { return array( 'ok' => false, 'error' => 'Thiếu cơ sở.' ); }
		$bp = trim( (string) $bo_phan );
		/* Chỉ nhận đúng danh sách. Bộ phận lạ chuẩn hoá thành 'Chưa xếp' = KHÔNG có công thức
		   lương — đó là hành vi bản gốc, và nó đúng: thà không tính còn hơn tính bằng công thức
		   của bộ phận khác. Nhưng ở ĐÂY thì phải nói ra, đừng lặng lẽ đổi thành Chưa xếp. */
		if ( '' !== $bp && ! in_array( $bp, VHCC_Luong::BP_DS, true ) ) {
			return array( 'ok' => false, 'error' => 'Bộ phận "' . $bp . '" không có trong danh sách ('
				. implode( ' · ', VHCC_Luong::BP_DS ) . '). Khai tên khác là cơ sở đó thành "Chưa xếp" '
				. 'và KHÔNG được tính lương.' );
		}
		$cu = $wpdb->get_row( $wpdb->prepare(
			'SELECT id FROM ' . VHCC_DB::t( 'bo_phan_coso' ) . ' WHERE LOWER(coso)=LOWER(%s) LIMIT 1',
			$coso ), ARRAY_A );
		$ghi = array( 'coso' => $coso, 'bo_phan' => $bp );
		if ( null !== $theo_gio ) { $ghi['theo_gio'] = $theo_gio ? 1 : 0; }
		if ( $cu ) { $wpdb->update( VHCC_DB::t( 'bo_phan_coso' ), $ghi, array( 'id' => (int) $cu['id'] ) ); }
		else       { $wpdb->insert( VHCC_DB::t( 'bo_phan_coso' ), $ghi ); }
		return array( 'ok' => true );
	}

	/**
	 * DÒ SẴN CÁC CẶP MÃ ĐÁNG NGỜ LÀ MỘT NGƯỜI — theo họ tên.
	 *
	 * =========================================================================================
	 * Anh Thắng 28/08/2026: *"cách dò tên nhân viên trùng để ghép mã được không: theo họ tên
	 * nhân viên"*. Đúng — 400 nhân sự mà gõ tay từng cặp thì không ai làm nổi.
	 * =========================================================================================
	 *
	 * 🔴 GỢI Ý THÌ ĐƯỢC, TỰ GHÉP THÌ KHÔNG. Tên người Việt trùng rất nhiều; đoán sai là gộp
	 *    lương hai người khác nhau — và gộp xong thì `don_ma()` không đảo lại được. Hàm này chỉ
	 *    dọn sẵn danh sách; người vẫn là bên bấm nút.
	 *
	 * CÁCH DÒ, DỰA ĐÚNG VÀO HÌNH DẠNG CỦA CHỖ HỎNG:
	 *   • Mã MÁY  — có lượt chấm công, KHÔNG có hồ sơ nhân sự (máy mang một dãy số của riêng nó)
	 *   • Mã CÔNG TY — có hồ sơ, thường chưa có lượt nào
	 * Nên đi từ mã lạ trong bảng chấm công, lấy tên mà máy gửi kèm, rồi tìm hồ sơ trùng tên.
	 *
	 * ⚠️ TÊN KHỚP NHIỀU HỒ SƠ THÌ KHÔNG GỢI Ý — nói ra là "khớp N hồ sơ" rồi thôi. Chọn đại một
	 *    cái là đúng kiểu sai mà bình luận ở `khai_ma_song_song()` đã dặn phải tránh.
	 *
	 * ⚠️ BỎ QUA CẶP ĐÃ KHAI. Bày lại một việc vừa làm xong là người ta bấm hai lần rồi ngờ chính
	 *    mình.
	 *
	 * @return array [ ['maMay','maCty','ten','coso','soLuot','soHoSoKhop'], … ]
	 */
	public static function goi_y_ghep_ma( $u, $toi_da = 200 ) {
		global $wpdb;
		if ( ! self::co_quan_tri_nv( $u ) ) { return array(); }
		$t_cc = VHCC_DB::t( 'cham_cong' );
		$t_nv = VHCC_DB::t( 'nhan_vien' );

		/* Mã có lượt chấm công mà KHÔNG có hồ sơ — gần như chắc là mã của máy. */
		$la = VHCC_DB::rows( "SELECT c.ma_nv, COUNT(*) AS so, MAX(c.ho_ten) AS ho_ten,"
			. " MAX(c.coso) AS coso FROM $t_cc c"
			. " LEFT JOIN $t_nv n ON n.ma_nv = c.ma_nv"
			. " WHERE n.ma_nv IS NULL AND TRIM(c.ma_nv) <> ''"
			. ' GROUP BY c.ma_nv ORDER BY so DESC LIMIT ' . max( 1, (int) $toi_da ) );
		if ( ! $la ) { return array(); }

		/* Sổ nhân sự gom theo khoá tên — một khoá có thể ứng với nhiều hồ sơ, phải giữ cả cụm. */
		$theo_ten = array();
		foreach ( (array) VHCC_DB::rows( "SELECT ma_nv, ho_ten, cua_hang FROM $t_nv"
			. " WHERE TRIM(ma_nv) <> ''" ) as $r ) {
			$k = self::khoa_so( (string) $r['ho_ten'] );
			if ( '' === $k ) { continue; }
			$theo_ten[ $k ][] = $r;
		}

		$da_khai = array();
		foreach ( (array) self::ds_ma_song_song() as $r ) {
			$da_khai[ strtoupper( trim( (string) $r['ma_a'] ) ) . '|' . strtoupper( trim( (string) $r['ma_b'] ) ) ] = 1;
			$da_khai[ strtoupper( trim( (string) $r['ma_b'] ) ) . '|' . strtoupper( trim( (string) $r['ma_a'] ) ) ] = 1;
		}

		$ra = array();
		foreach ( $la as $x ) {
			$ten = trim( (string) $x['ho_ten'] );
			$k   = self::khoa_so( $ten );
			if ( '' === $k || ! isset( $theo_ten[ $k ] ) ) { continue; }
			$khop = $theo_ten[ $k ];
			$mot  = ( 1 === count( $khop ) ) ? $khop[0] : null;
			$ma_cty = $mot ? trim( (string) $mot['ma_nv'] ) : '';
			if ( '' !== $ma_cty && isset( $da_khai[ strtoupper( $ma_cty ) . '|' . strtoupper( (string) $x['ma_nv'] ) ] ) ) {
				continue;
			}
			$ra[] = array(
				'maMay'      => (string) $x['ma_nv'],
				'maCty'      => $ma_cty,
				'ten'        => $ten,
				'tenHoSo'    => $mot ? trim( (string) $mot['ho_ten'] ) : '',
				'coso'       => (string) $x['coso'],
				'cosoHoSo'   => $mot ? trim( (string) $mot['cua_hang'] ) : '',
				'soLuot'     => (int) $x['so'],
				'soHoSoKhop' => count( $khop ),
			);
		}
		return $ra;
	}

	/**
	 * GHÉP HAI MÃ LÀM MỘT, MỘT LƯỢT: tự chọn mã chính → khai cặp → dồn lượt cũ.
	 *
	 * =========================================================================================
	 * 🔴 ANH THẮNG CHỐT 16/09/2026: *"thêm tính năng ghép 2 mã nhân viên lại 1"*, và khi hỏi giữ
	 *    mã nào: **"Luôn giữ mã có nhiều công hơn"**.
	 * =========================================================================================
	 * Đồ nghề đã có đủ từ trước (`khai_ma_song_song()` + `don_ma()`), nhưng chúng bắt người dùng
	 * tự gõ mã nào chính mã nào phụ. Đứng trước bảng công thấy hai hàng cùng tên thì không ai
	 * biết mã nào "đúng" — và gõ ngược thì công dồn về cái mã sắp bị bỏ.
	 *
	 * Thước chọn: **mã nào nhiều LƯỢT CHẤM hơn thì làm mã chính.** Không đếm số giờ — một lượt
	 * quên bấm giờ ra có 0 giờ nhưng vẫn là một ngày người ta đi làm, và nó vẫn phải kéo theo
	 * mã của mình.
	 *
	 * ⚠️ NÓI RA ĐÃ CHỌN MÃ NÀO VÀ VÌ SAO. Chọn ngầm rồi im lặng là thứ không lần lại được: việc
	 *    này KHÔNG ĐẢO ĐƯỢC (xem `don_ma()`), nên người bấm phải đọc được ngay sau đó rằng công
	 *    đã dồn về đâu.
	 *
	 * ⚠️ HOÀ THÌ ƯU TIÊN MÃ CÓ HỒ SƠ. `ma_that()` chỉ dịch được về một mã CÓ hồ sơ, nên chọn mã
	 *    không hồ sơ làm mã chính là tự tay làm cho lần đồng bộ sau hết tác dụng. Hoà nữa thì
	 *    lấy mã đứng trước theo abc — cốt để hai lần bấm cùng một cặp ra cùng một kết quả.
	 */
	public static function ghep_hai_ma( $u, $ma_x, $ma_y ) {
		global $wpdb;
		if ( ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false, 'error' => 'Ghép hai mã ảnh hưởng cả chuỗi — ' . self::LOI_QT );
		}
		$x = trim( (string) $ma_x );
		$y = trim( (string) $ma_y );
		if ( '' === $x || '' === $y ) { return array( 'ok' => false, 'error' => 'Thiếu một trong hai mã.' ); }
		if ( 0 === strcasecmp( $x, $y ) ) { return array( 'ok' => false, 'error' => 'Hai mã giống nhau.' ); }

		$t  = VHCC_DB::t( 'cham_cong' );
		$dem = function ( $ma ) use ( $wpdb, $t ) {
			return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE ma_nv=%s", $ma ) );
		};
		$lx = $dem( $x );
		$ly = $dem( $y );

		if ( $lx !== $ly ) {
			$chinh = ( $lx > $ly ) ? $x : $y;
			$vi_sao = 'nhiều lượt chấm hơn (' . max( $lx, $ly ) . ' so với ' . min( $lx, $ly ) . ')';
		} else {
			$hx = (bool) self::ho_so( $x );
			$hy = (bool) self::ho_so( $y );
			if ( $hx !== $hy ) {
				$chinh  = $hx ? $x : $y;
				$vi_sao = 'hai mã bằng nhau về số lượt (' . $lx . '), nhưng mã này CÓ hồ sơ';
			} else {
				$chinh  = ( strcasecmp( $x, $y ) <= 0 ) ? $x : $y;
				$vi_sao = 'hai mã bằng nhau mọi mặt (' . $lx . ' lượt), lấy mã đứng trước theo abc';
			}
		}
		$phu = ( $chinh === $x ) ? $y : $x;

		$kh = self::khai_ma_song_song( $u, $chinh, $phu, '', 'ghép từ bảng công' );
		/* Cặp đã khai từ trước thì KHÔNG phải lỗi — người ta đang muốn dồn nốt phần cũ. */
		if ( empty( $kh['ok'] ) && false === strpos( (string) $kh['error'], 'đã khai' ) ) {
			return array( 'ok' => false, 'error' => (string) $kh['error'] );
		}
		$dm = self::don_ma( $u, $chinh, $phu );
		if ( empty( $dm['ok'] ) ) { return array( 'ok' => false, 'error' => (string) $dm['error'] ); }

		return array( 'ok' => true, 'chinh' => $chinh, 'phu' => $phu, 'viSao' => $vi_sao,
			'chuyen' => (int) $dm['chuyen'], 'gop' => (int) $dm['gop'] );
	}

	/**
	 * ĐẾM XEM DỒN MÃ PHỤ VỀ MÃ CHÍNH THÌ ĐỘNG VÀO BAO NHIÊU HÀNG.
	 *
	 * Trả [ 'chuyen' => số hàng chỉ việc đổi mã, 'gop' => số hàng phải gộp vì trùng ngày ].
	 */
	public static function dem_don_ma( $ma_chinh, $ma_phu ) {
		global $wpdb;
		$t = VHCC_DB::t( 'cham_cong' );
		$a = trim( (string) $ma_chinh );
		$b = trim( (string) $ma_phu );
		if ( '' === $a || '' === $b || 0 === strcasecmp( $a, $b ) ) {
			return array( 'chuyen' => 0, 'gop' => 0 );
		}
		$gop = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $t p JOIN $t c ON p.coso=c.coso AND p.ngay=c.ngay"
			. ' AND p.hau_to=c.hau_to WHERE p.ma_nv=%s AND c.ma_nv=%s', $b, $a ) );
		$tong = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $t WHERE ma_nv=%s", $b ) );
		return array( 'chuyen' => max( 0, $tong - $gop ), 'gop' => $gop );
	}

	/**
	 * DỒN LƯỢT CHẤM CÔNG CŨ CỦA MÃ PHỤ VỀ MÃ CHÍNH.
	 *
	 * =========================================================================================
	 * 🔴 KHAI CẶP MÃ CHỈ CHỮA TỪ NAY VỀ SAU. DỮ LIỆU CŨ VẪN TÁCH ĐÔI.
	 * =========================================================================================
	 * Anh Thắng 28/08/2026, ảnh lưới cả tháng với mỗi người hiện thành HAI hàng — một hàng có
	 * giờ, một hàng "chưa chấm": *"Trên máy chấm công là 1 mã, trên web là 1 mã (trên máy thì
	 * không sửa được), trên web thì mã chuẩn công ty, nên cần đồng bộ 2 mã chạy song song được
	 * không, chứ nó đang nhân 2 nhân viên ra"*.
	 *
	 * Cơ chế đồng bộ đã có: khai cặp ở `ma_song_song`, rồi `ma_that()` dịch mã máy về mã chính.
	 * Nhưng `ma_that()` CHỈ được gọi ở `VHCC_Nhan::mot_luot()` — tức là lúc GHI một lượt mới.
	 * Hàng đã nằm trong bảng từ trước thì không ai đụng tới, nên vẫn mang mã máy, và lưới vẫn
	 * vẽ ra hai người.
	 *
	 * ⚠️ VIỆC NÀY KHÔNG ĐẢO ĐƯỢC. Bỏ ghép sau đó cũng không tách lại được — hàng đã mang mã
	 *    chính rồi thì không còn dấu vết nó từng thuộc mã nào. Vì thế nó là một NÚT RIÊNG, đứng
	 *    sau việc khai cặp, chứ không chạy kèm: khai cặp là việc nhẹ và bỏ được, dồn thì không.
	 *
	 * 🔴 TRÙNG NGÀY THÌ GIỮ LƯỢT DÀI HƠN, BỎ LƯỢT KIA. Bảng có `UNIQUE KEY o (coso,ngay,ma_nv,
	 *    hau_to)` nên đổi mã thẳng sẽ đụng khoá ở những ngày cả hai mã cùng có giờ.
	 *
	 *    ⚠️ LUẬT NÀY ĐÃ ĐỔI 16/09/2026. Bản trước gộp bằng cách lấy giờ vào SỚM NHẤT và giờ ra
	 *       MUỘN NHẤT của hai hàng, với lý do "hai mã là MỘT người, một ngày họ chỉ có một ca".
	 *       Lý do ấy nghe xuôi nhưng phép tính thì NỚI KHOẢNG RA: một người thật sự làm hai ca
	 *       rời trong ngày (08:00–12:00 ở mã này, 14:00–18:00 ở mã kia) bị gộp thành một khoảng
	 *       08:00–18:00 = 10 giờ, tức **trả dư 2 giờ tiền cho giờ không ai làm**.
	 *
	 *       Anh Thắng chốt: *"Giữ lượt dài hơn, bỏ lượt kia"* — vì cảnh có thật ở đây là app cũ
	 *       và máy mới cùng chép về MỘT ca, hai hàng gần như trùng nhau. Giữ hàng dài hơn cho ra
	 *       đúng ca ấy, và không bao giờ sinh ra giờ chưa ai làm. Đổi lại, nếu đúng là hai ca
	 *       rời thật thì mất ca ngắn — nhưng thiếu giờ thì người ta kêu và bù được, còn dư giờ
	 *       thì không ai biết mà kêu.
	 *
	 *    ⚠️ Hàng thiếu một đầu giờ (chỉ có giờ vào, hoặc chỉ có giờ ra) coi như dài 0 — hàng nào
	 *       ĐỦ CẶP thì luôn thắng. Cả hai cùng thiếu thì giữ hàng của mã chính, vì nó đã nằm sẵn
	 *       đúng khoá.
	 */
	public static function don_ma( $u, $ma_chinh, $ma_phu ) {
		global $wpdb;
		if ( ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false, 'error' => 'Dồn lượt chấm công ảnh hưởng cả chuỗi — ' . self::LOI_QT );
		}
		$a = trim( (string) $ma_chinh );
		$b = trim( (string) $ma_phu );
		if ( '' === $a || '' === $b ) { return array( 'ok' => false, 'error' => 'Thiếu một trong hai mã.' ); }
		if ( 0 === strcasecmp( $a, $b ) ) {
			return array( 'ok' => false, 'error' => 'Hai mã giống nhau.' );
		}
		/* ⚠️ CHỈ DỒN CẶP ĐÃ KHAI. Cho dồn hai mã bất kỳ là mở đường ném công của người này sang
		   người khác chỉ bằng hai ô gõ tay. */
		$da = $wpdb->get_var( $wpdb->prepare(
			'SELECT 1 FROM ' . VHCC_DB::t( 'ma_song_song' )
			. ' WHERE (LOWER(ma_a)=LOWER(%s) AND LOWER(ma_b)=LOWER(%s))'
			. ' OR (LOWER(ma_a)=LOWER(%s) AND LOWER(ma_b)=LOWER(%s)) LIMIT 1', $a, $b, $b, $a ) );
		if ( ! $da ) {
			return array( 'ok' => false, 'error' => 'Cặp mã này chưa khai — khai ghép trước rồi mới dồn.' );
		}

		$t   = VHCC_DB::t( 'cham_cong' );
		$phu = VHCC_DB::rows( $wpdb->prepare( "SELECT * FROM $t WHERE ma_nv=%s", $b ) );
		$chuyen = 0;
		$gop    = 0;
		foreach ( (array) $phu as $r ) {
			$cu = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM $t WHERE coso=%s AND ngay=%s AND ma_nv=%s AND hau_to=%s LIMIT 1",
				$r['coso'], $r['ngay'], $a, $r['hau_to'] ), ARRAY_A );
			if ( ! $cu ) {
				$wpdb->update( $t, array( 'ma_nv' => $a ), array( 'id' => (int) $r['id'] ) );
				$chuyen++;
				continue;
			}
			/* Giữ lượt DÀI HƠN, bỏ lượt kia — xem khối chú thích của hàm. */
			$d_cu  = self::dai_luot( $cu['gio_vao_giay'], $cu['gio_ra_giay'] );
			$d_moi = self::dai_luot( $r['gio_vao_giay'],  $r['gio_ra_giay'] );
			/* 🔴 HAI NGUỒN KHÁC NHAU THÌ VẪN GHI `hon-hop`, DÙ CHỈ GIỮ MỘT HÀNG. Hàng còn lại
			   là giờ của một nguồn, nhưng việc "có hai nguồn cùng ghi ngày này và chúng khác
			   nhau" là thứ người đi soi cần biết — xoá dấu vết ấy đi thì sau này không ai lần
			   ra vì sao một ca biến mất. */
			$ng = ( '' !== trim( (string) $r['nguon'] )
				&& (string) $cu['nguon'] !== (string) $r['nguon'] ) ? 'hon-hop' : $cu['nguon'];
			$vao = ( $d_moi > $d_cu ) ? $r['gio_vao_giay'] : $cu['gio_vao_giay'];
			$ra  = ( $d_moi > $d_cu ) ? $r['gio_ra_giay']  : $cu['gio_ra_giay'];
			$wpdb->update( $t, array(
				'gio_vao_giay' => $vao, 'gio_ra_giay' => $ra, 'nguon' => $ng,
				'chuan' => trim( VHCC_DB::hhmm( $vao ) . ' ' . VHCC_DB::hhmm( $ra ) ),
			), array( 'id' => (int) $cu['id'] ) );
			$wpdb->delete( $t, array( 'id' => (int) $r['id'] ) );
			$gop++;
		}
		return array( 'ok' => true, 'chuyen' => $chuyen, 'gop' => $gop );
	}

	/**
	 * Một lượt dài bao nhiêu phút — để so xem hàng nào "dài hơn" lúc dồn mã.
	 *
	 * 🔴 THIẾU MỘT ĐẦU GIỜ THÌ COI LÀ 0, không phải "chưa biết". Một hàng chỉ có giờ vào không
	 *    nói được người ta làm bao lâu; đặt nó bằng 0 để hàng ĐỦ CẶP luôn thắng — đó đúng là
	 *    hàng đáng giữ.
	 * ⚠️ Ca vắt qua nửa đêm: cộng bù `+24h`, cùng luật với `VHCC_Luong::phut_ca()`. Không cộng
	 *    bù thì một ca 22:00 → 02:00 ra số ÂM và luôn thua — tức luôn bị bỏ.
	 */
	private static function dai_luot( $vao, $ra ) {
		if ( null === $vao || '' === $vao || null === $ra || '' === $ra ) { return 0; }
		$d = (int) $ra - (int) $vao;
		if ( $d < 0 ) { $d += VHCC_DB::NGAY_GIAY; }
		return $d;
	}

	/** Nhỏ hơn, bỏ qua null. Cả hai null -> null. */
	private static function nho_hon( $x, $y ) {
		if ( null === $x || '' === $x ) { return ( '' === $y ) ? null : $y; }
		if ( null === $y || '' === $y ) { return $x; }
		return min( (int) $x, (int) $y );
	}

	/** Lớn hơn, bỏ qua null. */
	private static function lon_hon( $x, $y ) {
		if ( null === $x || '' === $x ) { return ( '' === $y ) ? null : $y; }
		if ( null === $y || '' === $y ) { return $x; }
		return max( (int) $x, (int) $y );
	}

	/**
	 * Khai MÃ SONG SONG (một người, hai mã: máy cũ chưa nhận lệnh đổi mã).
	 * ⚠️ PHẢI KHAI, hệ thống KHÔNG được tự suy "hai mã này chắc là một người" từ tên — tên người
	 *    Việt trùng rất nhiều, đoán sai là gộp lương hai người khác nhau.
	 */
	public static function khai_ma_song_song( $u, $ma_a, $ma_b, $ho_ten, $ly_do ) {
		global $wpdb;
		if ( ! self::co_quan_tri_nv( $u ) ) {
			return array( 'ok' => false, 'error' => 'Mã song song ảnh hưởng cả chuỗi — ' . self::LOI_QT );
		}
		$a = trim( (string) $ma_a );
		$b = trim( (string) $ma_b );
		if ( '' === $a || '' === $b ) { return array( 'ok' => false, 'error' => 'Thiếu một trong hai mã.' ); }
		if ( strtolower( $a ) === strtolower( $b ) ) {
			return array( 'ok' => false, 'error' => 'Hai mã giống nhau — không phải mã song song.' );
		}
		$da = $wpdb->get_var( $wpdb->prepare(
			'SELECT 1 FROM ' . VHCC_DB::t( 'ma_song_song' )
			. ' WHERE (LOWER(ma_a)=LOWER(%s) AND LOWER(ma_b)=LOWER(%s))'
			. ' OR (LOWER(ma_a)=LOWER(%s) AND LOWER(ma_b)=LOWER(%s)) LIMIT 1', $a, $b, $b, $a ) );
		if ( $da ) { return array( 'ok' => false, 'error' => 'Cặp mã này đã khai rồi.' ); }
		$wpdb->insert( VHCC_DB::t( 'ma_song_song' ), array(
			'ma_a' => $a, 'ma_b' => $b, 'ho_ten' => trim( (string) $ho_ten ),
			'ly_do' => trim( (string) $ly_do ),
			'nguoi_khai' => isset( $u['name'] ) ? (string) $u['name'] : '',
			'tao_luc' => current_time( 'mysql' ) ) );
		return array( 'ok' => true );
	}
}
