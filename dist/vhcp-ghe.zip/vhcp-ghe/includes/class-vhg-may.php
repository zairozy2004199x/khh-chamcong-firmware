<?php
/**
 * MÁY (GHẾ): cấu hình, cơ sở, hàng chờ chạy, nhịp sống, lệnh bật/tắt tay.
 *
 * =============================================================================================
 * HAI THỨ RẤT DỄ LẪN, VÀ LẪN LÀ MẤT TIỀN
 * =============================================================================================
 *   `cho`  — KHÁCH ĐÃ TRẢ TIỀN, ghế chưa chạy. Sinh ra từ webhook. Ghế lấy về rồi chạy.
 *   `lenh` — NGƯỜI BẤM TAY trên màn để cho chạy (khách kêu máy không nhận, đền bù…). KHÔNG có
 *            tiền đi kèm.
 * Gộp hai thứ này vào một bảng là cuối tháng không tách được "chạy vì có tiền" với "chạy vì
 * được cho", tức không biết máy nào đang bị cho chạy chùa. Nên tách hẳn, và `lenh` bắt buộc ghi
 * người đặt.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class VHG_May {

	/** Quá bao lâu không có nhịp thì coi là máy đứt (giây). */
	const HET_SONG = 120;

	// ======================================================================= cơ sở

	public static function ds_coso() {
		return VHG_DB::rows( 'SELECT * FROM ' . VHG_DB::t( 'coso' ) . ' ORDER BY ten ASC' );
	}

	/**
	 * 🔴 BÁO RA NGOÀI BẰNG MÓC `vhg_coso_da_luu` (tên cơ sở). Plugin Vận Hành Chi Phí nghe móc
	 * này để đưa cơ sở mới sang danh mục của nó — anh Thắng 08/09/2026: *"khi tạo cơ sở mới bên
	 * ghế, hệ thống tự đẩy cơ sở sang luôn"*.
	 *
	 * ⚠️ PHÁT MÓC CHỨ KHÔNG GỌI THẲNG SANG PLUGIN KIA. Hai plugin cài rời nhau; gọi thẳng thì gỡ
	 *    một cái là cái còn lại chết. Không ai nghe thì `do_action` là lệnh rỗng, không tốn gì.
	 *
	 * ⚠️ PHÁT Ở CẢ BA NHÁNH, kể cả nhánh "cơ sở này đã có". Bên kia CHỈ THÊM khi chưa có nên phát
	 *    thừa là vô hại, mà phát thiếu thì cơ sở ấy im lặng không bao giờ sang — và không có gì
	 *    báo là nó thiếu. Nhánh "đã có" còn tự vá được lượt đẩy nào lỡ rơi mất trước đó.
	 *
	 * @param string|null $ma_kh Mã khách hàng bên sổ kế toán (KH00108…). null = KHÔNG đụng.
	 *
	 * ⚠️ `null` KHÁC chuỗi rỗng, và sự khác nhau ấy quan trọng. Mọi chỗ gọi hàm này từ trước
	 *    (đổi tên cơ sở, thêm cơ sở lúc gán ghế…) đều không truyền `ma_kh` — nếu coi thiếu tham
	 *    số là "đặt về rỗng" thì mỗi lần ai đó sửa tên một cơ sở là mã KH của nó bị xoá, im lặng.
	 */
	/**
	 * Đang xử lý cơ sở NHẬN TỪ plugin chi phí hay không — xem `moc_coso_chi_phi()`.
	 *
	 * 🔴 CHỐNG NÉM QUA NÉM LẠI. Hai chiều đã nối: lưu bên này báo sang chi phí, lưu bên chi phí
	 *    báo về đây. Không có cờ này thì một cái tên đi vòng: chi phí -> đây -> chi phí -> đây…
	 *    Vòng ấy THỰC RA vẫn dừng (mỗi đầu chỉ thêm khi chưa có, nên lượt hai không ghi gì và
	 *    không báo tiếp), nhưng nó tốn một vòng thừa và, quan trọng hơn, nó dựa vào một thứ ở
	 *    plugin KHÁC vẫn cư xử đúng. Cắt ngay tại nguồn thì không phải tin vào ai.
	 */
	private static $dang_nhan_tu_chi_phi = false;

	/**
	 * Tai nghe cho móc `vhcp_coso_posh_da_luu` của plugin Vận Hành Chi Phí — xem chỗ đăng ký ở
	 * `vhcp-ghe.php`. Anh Thắng 09/09/2026: *"chỉ đẩy sang nếu nó là đơn vị posh thôi"*; việc
	 * lọc đơn vị làm ở BÊN ẤY, vì chỉ bên ấy mới biết cơ sở nào thuộc đơn vị nào.
	 *
	 * CHỈ THÊM: `luu_coso()` với id 0 tự nhận ra tên đã có và không đụng gì tới dòng ấy — mã KH,
	 * tỉnh, cờ reset của cơ sở đang chạy giữ nguyên.
	 */
	public static function moc_coso_chi_phi( $ten ) {
		/* ⚠️ KHÔNG chép lại luật "tên thế nào là hợp lệ" ở đây. `luu_coso()` đã chối tên rỗng và
		   là nơi DUY NHẤT quyết định chuyện ấy — giữ bản sao ở đây là hai chỗ có thể lệch nhau,
		   mà lệch thì chỗ nào đúng cũng không ai biết. Phá thử chỉ ra bản sao ấy không canh gì. */
		self::$dang_nhan_tu_chi_phi = true;
		try {
			self::luu_coso( 0, $ten );
		} catch ( Exception $e ) {
			self::$dang_nhan_tu_chi_phi = false;
			throw $e;
		}
		self::$dang_nhan_tu_chi_phi = false;
	}

	/** Báo ra ngoài, trừ khi chính cơ sở này vừa nhận TỪ ngoài vào. */
	private static function bao_da_luu_( $ten ) {
		if ( self::$dang_nhan_tu_chi_phi ) { return; }
		do_action( 'vhg_coso_da_luu', $ten );
	}

	public static function luu_coso( $id, $ten, $tinh = null, $ma_kh = null, $reset = null ) {
		global $wpdb;
		$ten = trim( (string) $ten );
		if ( '' === $ten ) { return array( 'ok' => false, 'error' => 'Thiếu tên cơ sở.' ); }
		$bang = VHG_DB::t( 'coso' );
		/* `tinh` (tỉnh/thành) — null = KHÔNG đụng (giữ nguyên), chuỗi = đặt lại. Để lọc theo địa bàn. */
		$co_tinh = ( null !== $tinh );
		$tinh = mb_substr( trim( (string) $tinh ), 0, 120 );
		$co_makh = ( null !== $ma_kh );
		$ma_kh = mb_substr( trim( (string) $ma_kh ), 0, 40 );
		/* `reset_moi_lan` — null = KHÔNG đụng (giữ nguyên), có giá trị = đặt lại. Cùng lối với
		   `tinh` / `ma_kh` ở trên: mấy lượt gọi cũ không truyền thì không vô tình tắt cờ. */
		$co_reset = ( null !== $reset );
		$reset = $reset ? 1 : 0;
		if ( (int) $id > 0 ) {
			$ten_cu = (string) $wpdb->get_var( $wpdb->prepare( "SELECT ten FROM $bang WHERE id=%d", (int) $id ) );
			$doi_ten = ( '' !== $ten_cu && $ten_cu !== $ten );
			$kc = VHG_BaoCao::squash( $ten_cu ); $kd = VHG_BaoCao::squash( $ten );
			if ( $doi_ten ) {
				/* Đổi sang tên (hoặc bí danh) của một cơ sở KHÁC là hai cơ sở chung một tên — sổ hai nơi
				   trộn vào nhau mà không ai gộp. Chặn; cùng một chỗ thì ⇄ gộp cơ sở mới đúng đường. */
				foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, ten, bi_danh FROM $bang WHERE id<>%d", (int) $id ), ARRAY_A ) as $x ) {
					foreach ( array_merge( array( (string) $x['ten'] ), self::bi_danh_tach_( isset( $x['bi_danh'] ) ? $x['bi_danh'] : '' ) ) as $t ) {
						if ( VHG_BaoCao::squash( $t ) === $kd ) {
							return array( 'ok' => false, 'error' => 'Đã có cơ sở "' . $x['ten'] . '" mang tên/bí danh ấy. Nếu là cùng một chỗ, dùng ⇄ để GỘP cơ sở này vào đó (sổ đi theo); không phải thì đặt tên phân biệt.' );
						}
					}
				}
			}
			$data = array( 'ten' => $ten );
			if ( $co_tinh ) { $data['tinh'] = $tinh; }
			if ( $co_makh ) { $data['ma_kh'] = $ma_kh; }
			if ( $co_reset ) { $data['reset_moi_lan'] = $reset; }
			$wpdb->update( $bang, $data, array( 'id' => (int) $id ) );
			$so = null;
			if ( $doi_ten ) {
				/* 🔴 ĐỔI TÊN THÌ SỔ ĐI THEO — 2.139.0, anh Thắng 24/09/2026: *"Địa điểm đã xoá, nhưng nó đang
				   dính dữ liệu cũ, nên xuất MISA nó ra cả điểm xoá và điểm mới"*. Gốc của ca POSH MN CGV
				   VINCOM LANDMARK / CGV LANDMARK 81: tên đổi (hoặc xoá rồi tạo mới) mà `bc` vẫn giữ tên cũ →
				   Báo cáo tổng, MISA ra hai dòng cho một chỗ. Đổi tên là ĐỔI NHÃN cùng một điểm, sổ phải
				   đi theo; tên cũ giữ làm bí danh để tiền VietQR cổng còn ghi tên cũ vẫn về đây. */
				if ( $kc !== $kd ) {
					$so = self::gop_so_coso( $ten, array( $ten_cu ) );
					$bd = (string) $wpdb->get_var( $wpdb->prepare( "SELECT bi_danh FROM $bang WHERE id=%d", (int) $id ) );
					$wpdb->update( $bang, array( 'bi_danh' => self::bi_danh_gop_( $bd, array( $ten_cu ), $ten ) ), array( 'id' => (int) $id ) );
				} else {
					self::dong_bo_nhan_so_( $ten, $kd );   // chỉ khác hoa-thường / dấu: cùng khoá, đổi nhãn hiển thị
				}
			}
			self::quen_dem_reset_();
			self::bao_da_luu_( $ten );
			return array( 'ok' => true, 'id' => (int) $id, 'so' => $so,
				'thong_bao' => 'Đã lưu cơ sở.' . ( $so && isset( $so['tom_tat'] ) ? ' ' . $so['tom_tat'] : '' ) );
		}
		$co = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $bang WHERE ten=%s LIMIT 1", $ten ) );
		if ( $co ) {
			$data_cu = array();
			if ( $co_tinh ) { $data_cu['tinh'] = $tinh; }
			if ( $co_makh ) { $data_cu['ma_kh'] = $ma_kh; }
			if ( $co_reset ) { $data_cu['reset_moi_lan'] = $reset; }
			if ( $data_cu ) { $wpdb->update( $bang, $data_cu, array( 'id' => (int) $co ) ); self::quen_dem_reset_(); }
			self::bao_da_luu_( $ten );
			return array( 'ok' => true, 'id' => (int) $co, 'thong_bao' => 'Cơ sở này đã có.' );
		}
		/* GỘP THEO TÊN CHUẨN HOÁ (bỏ dấu + hoa/thường + khoảng trắng): chặn tạo cơ sở GẦN TRÙNG để
		   tránh "cơ sở tự tách" ('CGV Pear Plaza' vs 'CGV PEARL PLAZA', thừa/thiếu dấu cách...).
		   Đã có bản chuẩn hoá giống -> báo để sửa cơ sở cũ, không đẻ thêm bản sao. */
		$sq = VHG_BaoCao::squash( $ten );
		if ( '' !== $sq ) {
			$ds_cs = $wpdb->get_results( "SELECT id, ten FROM $bang", ARRAY_A );
			foreach ( (array) $ds_cs as $c ) {
				if ( VHG_BaoCao::squash( (string) $c['ten'] ) === $sq ) {
					return array( 'ok' => false, 'error' => 'Đã có cơ sở gần giống: "' . $c['ten'] . '". '
						. 'Nếu đúng là nơi đó, sửa cơ sở cũ (nút ✎) thay vì tạo mới; nếu thật sự cần một cơ sở KHÁC, đặt tên phân biệt rõ hơn.' );
				}
			}
		}
		$wpdb->insert( $bang, array( 'ten' => $ten, 'tinh' => $co_tinh ? $tinh : '',
			'ma_kh' => $co_makh ? $ma_kh : '', 'reset_moi_lan' => $co_reset ? $reset : 0 ) );
		self::quen_dem_reset_();
		self::bao_da_luu_( $ten );
		return array( 'ok' => true, 'id' => (int) $wpdb->insert_id, 'thong_bao' => 'Đã thêm cơ sở ' . $ten . '.' );
	}

	/**
	 * Xoá cơ sở. Máy đang gán vào đó KHÔNG bị xoá theo — chỉ thành "chưa gán".
	 * ⚠️ Xoá máy theo là mất cấu hình giá/thời lượng/số tài khoản của những máy đang chạy thật,
	 *    chỉ vì người ta gõ nhầm tên một cơ sở rồi muốn xoá đi làm lại.
	 */
	/** Đổi cấu hình cơ sở thì dọn đệm cờ reset — không thì lượt tính tiếp theo còn đọc số cũ. */
	private static function quen_dem_reset_() {
		if ( class_exists( 'VHG_BaoCao' ) && method_exists( 'VHG_BaoCao', 'quen_reset_memo' ) ) {
			VHG_BaoCao::quen_reset_memo();
		}
	}

	/**
	 * GỘP hai cơ sở trùng nhau: dời hết ghế của `$nguon` sang `$dich`, rồi xoá dòng `$nguon`.
	 *
	 * Anh Thắng 14/09/2026: *"cần xoá hẳn CÁC CƠ SỞ TRÙNG"*. Ca thật: "CGV PEAR PLAZA" và
	 * "CGV PEARL PLAZA" — lệch đúng một chữ L nên `luu_coso` không bắt được (nó chỉ chặn khác
	 * dấu / hoa-thường / khoảng trắng, không chặn gõ sai chữ).
	 *
	 * 🔴 DỜI GHẾ TRƯỚC, XOÁ SAU — và xoá bằng `xoa_coso()` chứ không `DELETE` thẳng. `xoa_coso()`
	 *    có chốt "còn ghế thì không cho xoá"; đi qua nó nghĩa là nếu bước dời hụt một ghế nào thì
	 *    bước xoá TỰ CHẶN, cơ sở nguồn còn nguyên để làm lại. Xoá thẳng là ghế sót mất cơ sở, rơi
	 *    khỏi mọi phạm vi PIN — đúng cái đã gây "cả loạt VHM biến mất" (xem chú thích `xoa_coso`).
	 *
	 * 🔴 2.138.0 — GỘP CẢ SỔ, KHÔNG CHỈ GHẾ. Bản trước để báo cáo cũ nằm dưới tên cũ ("sổ tháng đã
	 *    chốt không sửa lại"); anh Thắng 24/09/2026 chỉ vào Báo cáo tổng hai dòng POSH MN CGV VINCOM
	 *    LANDMARK (1.040.000 tiền mặt) / CGV LANDMARK 81 (VietQR 870.000): *"Nhập 2 điểm này lại
	 *    thành 1"*. Một điểm hai tên là một dòng thừa ở mọi màn (Báo cáo tổng, MISA, công nợ). Nay
	 *    gộp xong thì gọi `gop_so_coso()` đổi NHÃN cơ sở trên mọi dòng sổ của tên cũ sang tên đích —
	 *    không xoá, không sửa một con số nào. Xem chú thích hàm ấy về các ca trùng khoá.
	 * ⚠️ Mã ghế TRÙNG NHAU giữa hai cơ sở thì gộp xong chúng nằm chung một chỗ — app sẽ hiện cảnh
	 *    báo "mã ghế trùng" ngay trên hàng. Đó là việc phải xử tiếp (đổi mã), không phải lỗi gộp.
	 */
	public static function gop_coso( $nguon, $dich ) {
		global $wpdb;
		$nguon = (int) $nguon; $dich = (int) $dich;
		if ( $nguon <= 0 || $dich <= 0 ) { return array( 'ok' => false, 'error' => 'Thiếu cơ sở nguồn hoặc cơ sở đích.' ); }
		if ( $nguon === $dich )          { return array( 'ok' => false, 'error' => 'Hai cơ sở trùng nhau — không gộp được.' ); }
		$bang = VHG_DB::t( 'coso' );
		$ten_n = $wpdb->get_var( $wpdb->prepare( "SELECT ten FROM $bang WHERE id=%d", $nguon ) );
		$ten_d = $wpdb->get_var( $wpdb->prepare( "SELECT ten FROM $bang WHERE id=%d", $dich ) );
		if ( null === $ten_n || null === $ten_d ) { return array( 'ok' => false, 'error' => 'Không thấy một trong hai cơ sở (có thể vừa bị xoá).' ); }

		$doi = (int) $wpdb->query( $wpdb->prepare(
			'UPDATE ' . VHG_DB::t( 'may' ) . ' SET coso_id=%d WHERE coso_id=%d', $dich, $nguon ) );

		/* 🔴 TÊN CŨ THÀNH BÍ DANH CỦA CƠ SỞ ĐÍCH — anh Thắng 24/09/2026: "POSH MN CGV VINCOM LANDMARK"
		   là tên cửa hàng bên cổng VietQR; Sao Kê quy tiền về cơ sở Ghế theo đúng tên ấy. Gộp mà
		   xoá suông tên cũ thì tiền VietQR của máy Landmark rơi thành "không khớp" — biến khỏi báo
		   cáo, không sang được cơ sở mới. Giữ tên cũ (và mọi bí danh của nó) trong `bi_danh` của
		   đích: Sao Kê tra bí danh → về đúng cơ sở mới. Lấy trước khi xoá, kẻo mất. */
		$bd_n = (string) $wpdb->get_var( $wpdb->prepare( "SELECT bi_danh FROM $bang WHERE id=%d", $nguon ) );
		$bd_d = (string) $wpdb->get_var( $wpdb->prepare( "SELECT bi_danh FROM $bang WHERE id=%d", $dich ) );

		$xoa = self::xoa_coso( $nguon );
		if ( empty( $xoa['ok'] ) ) {
			return array( 'ok' => false, 'error' => 'Đã dời ' . $doi . ' ghế sang "' . $ten_d . '" nhưng CHƯA xoá được cơ sở cũ: '
				. ( isset( $xoa['error'] ) ? $xoa['error'] : '' ) . ' Cơ sở cũ vẫn còn, anh xem lại rồi xoá tay.' );
		}
		$ds_cu = array_merge( array( (string) $ten_n ), self::bi_danh_tach_( $bd_n ) );
		$bd_moi = self::bi_danh_gop_( $bd_d, $ds_cu, (string) $ten_d );
		$wpdb->update( $bang, array( 'bi_danh' => $bd_moi ), array( 'id' => $dich ) );
		/* GỘP SỔ SAU KHI XOÁ NGUỒN XONG — xoá hụt thì chưa dời một dòng sổ nào (return ở trên). */
		$so = self::gop_so_coso( (string) $ten_d, $ds_cu );
		self::quen_dem_reset_();
		self::bao_da_luu_( (string) $ten_d );
		return array( 'ok' => true, 'doi' => $doi, 'ten_nguon' => (string) $ten_n, 'ten_dich' => (string) $ten_d, 'bi_danh' => $bd_moi, 'so' => $so,
			'thong_bao' => 'Đã gộp "' . $ten_n . '" vào "' . $ten_d . '": dời ' . $doi . ' ghế, xoá cơ sở cũ; "' . $ten_n . '" nay là BÍ DANH của "' . $ten_d
				. '" (tiền VietQR mang tên cũ vẫn quy về đây). ' . ( isset( $so['tom_tat'] ) ? $so['tom_tat'] : '' ) );
	}

	/**
	 * GỘP SỔ — dời mọi dòng sổ sách mang TÊN CŨ (so theo `coso_key`) sang TÊN ĐÍCH.
	 *
	 * Anh Thắng 24/09/2026, ảnh Báo cáo tổng: "POSH MN CGV VINCOM LANDMARK" (1.040.000 tiền mặt theo
	 * báo cáo nhân viên, không QR) nằm cạnh "CGV LANDMARK 81 · KH00245" (VietQR 870.000, không báo
	 * cáo) — *"Nhập 2 điểm này lại thành 1"*. Bí danh (2.137.0) chỉ kéo được TIỀN VIETQR về đích; báo
	 * cáo tiền mặt vẫn nằm dưới tên cũ vì bảng `bc` lưu tên cơ sở dạng chữ. Muốn một dòng thì phải đổi
	 * NHÃN cơ sở trên các dòng sổ — không xoá một đồng, không sửa một con số.
	 *
	 * 🔴 KHÔNG XOÁ DÒNG TIỀN. `bc` chỉ đổi coso/coso_key (`bc_dong` nối theo report_id, không có cột
	 *    cơ sở, đi theo tự nhiên). Dòng "một tháng một cơ sở" (bc_thang_bs, bc_congno_dau) mà ĐÍCH đã
	 *    có cùng tháng thì ĐỂ NGUYÊN dưới tên cũ và KỂ RA: cộng bừa là đếm đôi, xoá là mất tiền —
	 *    người quyết. Dòng không phải tiền (khoá ngày, Unit MISA) trùng khoá thì bỏ dòng cũ, kể ra.
	 * 🔴 UNIQUE (coso_key, ngay, lan) của `bc`: đích đã có báo cáo cùng ngày cùng lần thì dòng cũ nhận
	 *    `lan` kế tiếp — hai báo cáo cùng ngày cùng tồn tại, Báo cáo tổng cộng cả hai.
	 * 🔴 `bc_pin.coso` là DANH SÁCH tên (phạm vi phụ trách của nhân viên): thay tên cũ bằng tên đích,
	 *    không thì nhân viên đang phụ trách điểm ấy mất điểm khỏi màn nhập sau khi gộp.
	 *
	 * Trả ['ok','ten_dich','ten_cu'=>[…],'bc','bc_lan','khoa','khoa_bo','misa','misa_bo'=>[…],
	 *      'bs','bs_treo'=>[tháng…],'congno','congno_treo'=>[tháng…],'khac','pin','tom_tat'].
	 */
	public static function gop_so_coso( $ten_dich, $ds_ten_cu ) {
		global $wpdb;
		$ten_dich = trim( (string) $ten_dich );
		$kd = VHG_BaoCao::squash( $ten_dich );
		if ( '' === $kd ) { return array( 'ok' => false, 'error' => 'Thiếu tên cơ sở đích.' ); }
		$ra = array( 'ok' => true, 'ten_dich' => $ten_dich, 'ten_cu' => array(), 'bc' => 0, 'bc_lan' => 0, 'khoa' => 0, 'khoa_bo' => 0,
			'misa' => 0, 'misa_bo' => array(), 'bs' => 0, 'bs_treo' => array(), 'congno' => 0, 'congno_treo' => array(), 'khac' => 0, 'pin' => 0 );
		$bc = VHG_DB::t( 'bc' );
		foreach ( (array) $ds_ten_cu as $tc ) {
			$tc = trim( (string) $tc ); $kc = VHG_BaoCao::squash( $tc );
			if ( '' === $kc || $kc === $kd ) { continue; }   // chính tên đích (khác cách gõ) thì không phải tên cũ
			$ra['ten_cu'][] = $tc;

			/* bc — dòng tiền: chỉ đổi nhãn; trùng (ngày, lần) với đích thì sang lần kế tiếp. */
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, ngay, lan FROM $bc WHERE coso_key=%s", $kc ), ARRAY_A ) as $r ) {
				$lan = (int) $r['lan'];
				if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $bc WHERE coso_key=%s AND ngay=%s AND lan=%d", $kd, $r['ngay'], $lan ) ) ) {
					$lan = 1 + (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(lan) FROM $bc WHERE coso_key=%s AND ngay=%s", $kd, $r['ngay'] ) );
					$ra['bc_lan']++;
				}
				$wpdb->update( $bc, array( 'coso' => $ten_dich, 'coso_key' => $kd, 'lan' => $lan ), array( 'id' => (int) $r['id'] ) );
				$ra['bc']++;
			}

			/* bc_khoa — UNIQUE (coso_key, ngay): đích đã khoá ngày ấy thì bỏ khoá cũ (khoá không phải tiền). */
			$tk = VHG_DB::t( 'bc_khoa' );
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, ngay FROM $tk WHERE coso_key=%s", $kc ), ARRAY_A ) as $r ) {
				if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $tk WHERE coso_key=%s AND ngay=%s", $kd, $r['ngay'] ) ) ) {
					$wpdb->delete( $tk, array( 'id' => (int) $r['id'] ) ); $ra['khoa_bo']++;
				} else {
					$wpdb->update( $tk, array( 'coso' => $ten_dich, 'coso_key' => $kd ), array( 'id' => (int) $r['id'] ) ); $ra['khoa']++;
				}
			}

			/* bc_ma_misa — PK coso_key: đích chưa có Unit thì Unit của tên cũ đi theo; đã có thì bỏ dòng cũ, kể ra. */
			$tm = VHG_DB::t( 'bc_ma_misa' );
			$mc = $wpdb->get_row( $wpdb->prepare( "SELECT coso_key, unit_id, unit_name FROM $tm WHERE coso_key=%s", $kc ), ARRAY_A );
			if ( $mc ) {
				if ( $wpdb->get_var( $wpdb->prepare( "SELECT coso_key FROM $tm WHERE coso_key=%s", $kd ) ) ) {
					$wpdb->delete( $tm, array( 'coso_key' => $kc ) ); $ra['misa_bo'][] = $tc . ' (Unit ' . $mc['unit_id'] . ')';
				} else {
					$wpdb->update( $tm, array( 'coso' => $ten_dich, 'coso_key' => $kd ), array( 'coso_key' => $kc ) ); $ra['misa']++;
				}
			}

			/* bc_thang_bs, bc_congno_dau — UNIQUE (coso_key, thang): trùng tháng thì TREO lại dưới tên cũ, kể ra. */
			foreach ( array( 'bc_thang_bs' => 'bs', 'bc_congno_dau' => 'congno' ) as $bang => $k ) {
				$tb = VHG_DB::t( $bang );
				if ( 'bc_thang_bs' === $bang && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $tb ) ) !== $tb ) { continue; }
				foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, thang FROM $tb WHERE coso_key=%s", $kc ), ARRAY_A ) as $r ) {
					if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $tb WHERE coso_key=%s AND thang=%s", $kd, $r['thang'] ) ) ) {
						$ra[ $k . '_treo' ][] = (string) $r['thang'];
					} else {
						$wpdb->update( $tb, array( 'coso' => $ten_dich, 'coso_key' => $kd ), array( 'id' => (int) $r['id'] ) ); $ra[ $k ]++;
					}
				}
			}

			/* Bảng chỉ mang nhãn cơ sở, không có khoá duy nhất theo cơ sở: đổi thẳng. */
			foreach ( array( 'bc_yeucau', 'bao_tri', 'bc_ma_nop' ) as $bang ) {
				$ra['khac'] += (int) $wpdb->query( $wpdb->prepare( 'UPDATE ' . VHG_DB::t( $bang ) . ' SET coso=%s, coso_key=%s WHERE coso_key=%s', $ten_dich, $kd, $kc ) );
			}
			foreach ( array( 'bc_denghi', 'chot_tien', 'phien' ) as $bang ) {
				$ra['khac'] += (int) $wpdb->query( $wpdb->prepare( 'UPDATE ' . VHG_DB::t( $bang ) . ' SET coso=%s WHERE coso=%s', $ten_dich, $tc ) );
			}
			/* bc_vqr — kho VietQR SUY RA từ Sao Kê (2.142.0): không đổi nhãn, mà QUÊN các ngày mang khoá cũ; lượt Xem
			   kế tiếp kéo lại từ Sao Kê dưới tên đích (Sao Kê tra bí danh → tên đích). Không phải dòng tiền gốc. */
			if ( class_exists( 'VHG_VietQR' ) ) { $ra['khac'] += (int) VHG_VietQR::quen_coso( $kc ); }

			/* bc_pin.coso — danh sách tên ngăn bằng , hoặc ; — thay tên cũ bằng tên đích, bỏ trùng. */
			$tp = VHG_DB::t( 'bc_pin' );
			foreach ( (array) $wpdb->get_results( "SELECT pin, coso FROM $tp WHERE coso<>''", ARRAY_A ) as $r ) {
				$ds = array(); $doi = false;
				foreach ( preg_split( '/[;,]/', (string) $r['coso'] ) as $x ) {
					$x = trim( $x ); if ( '' === $x ) { continue; }
					if ( VHG_BaoCao::squash( $x ) === $kc ) { $x = $ten_dich; $doi = true; }
					if ( ! in_array( $x, $ds, true ) ) { $ds[] = $x; }
				}
				if ( $doi ) { $wpdb->update( $tp, array( 'coso' => implode( ', ', $ds ) ), array( 'pin' => $r['pin'] ) ); $ra['pin']++; }
			}
		}
		$ra['tom_tat'] = self::gop_so_tom_tat_( $ra );
		return $ra;
	}

	/* Một câu kể đủ những gì đã dời và những gì còn TREO — hộp thoại sau khi gộp và nhật ký cùng dùng. */
	private static function gop_so_tom_tat_( $ra ) {
		$p = array( $ra['bc'] . ' báo cáo tiền mặt' . ( $ra['bc_lan'] ? ' (' . $ra['bc_lan'] . ' dòng trùng ngày → thành lần thu kế tiếp)' : '' ) );
		if ( $ra['khoa'] || $ra['khoa_bo'] ) { $p[] = $ra['khoa'] . ' khoá ngày' . ( $ra['khoa_bo'] ? ' (bỏ ' . $ra['khoa_bo'] . ' khoá trùng)' : '' ); }
		if ( $ra['misa'] ) { $p[] = 'Unit MISA đi theo'; }
		if ( $ra['misa_bo'] ) { $p[] = 'bỏ Unit MISA của tên cũ vì đích đã có: ' . implode( ', ', $ra['misa_bo'] ); }
		if ( $ra['bs'] ) { $p[] = $ra['bs'] . ' tháng doanh thu bổ sung'; }
		if ( $ra['congno'] ) { $p[] = $ra['congno'] . ' dư đầu kỳ công nợ'; }
		if ( $ra['khac'] ) { $p[] = $ra['khac'] . ' dòng khác (yêu cầu / bảo trì / mã nộp / phiên)'; }
		if ( $ra['pin'] ) { $p[] = $ra['pin'] . ' PIN đổi phạm vi phụ trách'; }
		$s = 'GỘP SỔ về "' . $ra['ten_dich'] . '"' . ( $ra['ten_cu'] ? ' từ "' . implode( '", "', $ra['ten_cu'] ) . '"' : '' ) . ': ' . implode( '; ', $p ) . '. Không mất một đồng.';
		if ( $ra['bs_treo'] ) { $s .= ' ⚠ CHƯA gộp doanh thu bổ sung tháng ' . implode( ', ', array_unique( $ra['bs_treo'] ) ) . ' — đích đã có số của tháng ấy, anh xem hai số rồi tự cộng / xoá (Lịch sử → bổ sung).'; }
		if ( $ra['congno_treo'] ) { $s .= ' ⚠ CHƯA gộp dư đầu kỳ công nợ tháng ' . implode( ', ', array_unique( $ra['congno_treo'] ) ) . ' — đích đã có, anh xem tay.'; }
		return $s;
	}

	/**
	 * GỘP SỔ THEO BÍ DANH — cho cơ sở ĐÃ gộp ở bản 2.137.0 (tên cũ đã thành bí danh, nhưng sổ còn
	 * nằm dưới tên cũ nên Báo cáo tổng vẫn ra hai dòng). Nút 📒 trên hàng cơ sở, chỉ Quản trị.
	 */
	public static function gop_so_bi_danh( $id ) {
		global $wpdb;
		$id = (int) $id; if ( $id <= 0 ) { return array( 'ok' => false, 'error' => 'Thiếu cơ sở.' ); }
		$bang = VHG_DB::t( 'coso' );
		$c = $wpdb->get_row( $wpdb->prepare( "SELECT ten, bi_danh FROM $bang WHERE id=%d", $id ), ARRAY_A );
		if ( ! $c ) { return array( 'ok' => false, 'error' => 'Không thấy cơ sở.' ); }
		$ds = self::bi_danh_tach_( isset( $c['bi_danh'] ) ? $c['bi_danh'] : '' );
		if ( ! $ds ) { return array( 'ok' => false, 'error' => 'Cơ sở "' . $c['ten'] . '" chưa có bí danh (tên cũ) nào — không có sổ nào để kéo về. Dùng ⇄ để gộp một cơ sở khác vào đây.' ); }
		$so = self::gop_so_coso( (string) $c['ten'], $ds );
		if ( empty( $so['ok'] ) ) { return $so; }
		self::quen_dem_reset_();
		$so['thong_bao'] = $so['tom_tat'];
		return $so;
	}

	/**
	 * TÊN CÒN TRONG SỔ NHƯNG KHÔNG CÒN TRONG DANH MỤC — anh Thắng 24/09/2026: *"Địa điểm đã xoá, nhưng
	 * nó đang dính dữ liệu cũ, nên xuất MISA nó ra cả điểm xoá và điểm mới"*. Xoá cơ sở không đụng
	 * sổ (đúng luật giữ tiền), nên tên cũ vẫn đứng một dòng riêng ở Báo cáo tổng và MISA — và không có
	 * hàng nào trong danh mục để bấm ⇄. Kể ra đây cho Quản trị kéo sổ ấy về đúng điểm bằng một nút.
	 * Trả [ ['ten','key','n','tu','den','tien','unit'] … ], mới nhất lên đầu; bỏ tên/bí danh đang có.
	 */
	public static function ten_so_mo_coi() {
		global $wpdb;
		$co = array();
		foreach ( (array) self::ds_coso() as $c ) {
			$co[ VHG_BaoCao::squash( (string) $c['ten'] ) ] = 1;
			foreach ( self::bi_danh_tach_( isset( $c['bi_danh'] ) ? $c['bi_danh'] : '' ) as $b ) { $co[ VHG_BaoCao::squash( $b ) ] = 1; }
		}
		$ra = array();
		$bc = VHG_DB::t( 'bc' ); $bd = VHG_DB::t( 'bc_dong' );
		$rows = $wpdb->get_results( "SELECT h.coso_key k, MAX(h.coso) ten, COUNT(DISTINCT h.id) n, MIN(h.ngay) tu, MAX(h.ngay) den, COALESCE(SUM(d.tong),0) tien"
			. " FROM $bc h LEFT JOIN $bd d ON d.report_id=h.report_id GROUP BY h.coso_key", ARRAY_A );
		foreach ( (array) $rows as $r ) {
			$k = (string) $r['k']; if ( '' === $k || isset( $co[ $k ] ) ) { continue; }
			$ra[ $k ] = array( 'ten' => (string) $r['ten'], 'key' => $k, 'n' => (int) $r['n'], 'tu' => (string) $r['tu'], 'den' => (string) $r['den'], 'tien' => (int) $r['tien'], 'unit' => '' );
		}
		/* Dòng Unit MISA của tên đã xoá — chính cái "dính vào MISA" — cũng là sổ mồ côi, dù không còn báo cáo. */
		foreach ( (array) $wpdb->get_results( 'SELECT coso_key, coso, unit_id FROM ' . VHG_DB::t( 'bc_ma_misa' ), ARRAY_A ) as $r ) {
			$k = (string) $r['coso_key']; if ( '' === $k || isset( $co[ $k ] ) ) { continue; }
			if ( ! isset( $ra[ $k ] ) ) { $ra[ $k ] = array( 'ten' => (string) $r['coso'], 'key' => $k, 'n' => 0, 'tu' => '', 'den' => '', 'tien' => 0, 'unit' => '' ); }
			$ra[ $k ]['unit'] = (string) $r['unit_id'];
		}
		usort( $ra, function ( $a, $b ) { return strcmp( (string) $b['den'], (string) $a['den'] ); } );
		return array_values( $ra );
	}

	/**
	 * GỘP SỔ MỘT TÊN CŨ (không còn trong danh mục) VÀO CƠ SỞ ĐÍCH — nút 📒 ở khối "tên cũ còn trong
	 * sổ". Tên cũ thành bí danh của đích để tiền VietQR cổng còn ghi tên cũ vẫn về đây.
	 */
	public static function gop_so_ten_cu( $ten_cu, $dich ) {
		global $wpdb;
		$ten_cu = trim( (string) $ten_cu ); $dich = (int) $dich;
		if ( '' === $ten_cu || $dich <= 0 ) { return array( 'ok' => false, 'error' => 'Thiếu tên cũ hoặc cơ sở đích.' ); }
		$bang = VHG_DB::t( 'coso' );
		$c = $wpdb->get_row( $wpdb->prepare( "SELECT id, ten, bi_danh FROM $bang WHERE id=%d", $dich ), ARRAY_A );
		if ( ! $c ) { return array( 'ok' => false, 'error' => 'Không thấy cơ sở đích.' ); }
		$kc = VHG_BaoCao::squash( $ten_cu );
		if ( $kc === VHG_BaoCao::squash( (string) $c['ten'] ) ) { return array( 'ok' => false, 'error' => '"' . $ten_cu . '" chính là tên của cơ sở đích — không có gì để gộp.' ); }
		/* Còn là tên/bí danh của một cơ sở ĐANG CÓ thì không phải sổ mồ côi — ⇄ gộp cơ sở mới đúng đường. */
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, ten, bi_danh FROM $bang WHERE id<>%d", $dich ), ARRAY_A ) as $x ) {
			foreach ( array_merge( array( (string) $x['ten'] ), self::bi_danh_tach_( isset( $x['bi_danh'] ) ? $x['bi_danh'] : '' ) ) as $t ) {
				if ( VHG_BaoCao::squash( $t ) === $kc ) {
					return array( 'ok' => false, 'error' => '"' . $ten_cu . '" đang là tên/bí danh của cơ sở "' . $x['ten'] . '" — dùng ⇄ trên hàng ấy để gộp cả cơ sở.' );
				}
			}
		}
		$so = self::gop_so_coso( (string) $c['ten'], array( $ten_cu ) );
		if ( empty( $so['ok'] ) ) { return $so; }
		$bd = self::bi_danh_gop_( isset( $c['bi_danh'] ) ? (string) $c['bi_danh'] : '', array( $ten_cu ), (string) $c['ten'] );
		$wpdb->update( $bang, array( 'bi_danh' => $bd ), array( 'id' => $dich ) );
		self::quen_dem_reset_();
		$so['bi_danh'] = $bd;
		$so['thong_bao'] = $so['tom_tat'] . ' "' . $ten_cu . '" nay là bí danh của "' . $c['ten'] . '".';
		return $so;
	}

	/* Cùng khoá (chỉ khác hoa-thường / dấu / khoảng trắng): đổi NHÃN hiển thị trên dòng sổ cho khớp tên mới,
	   không thì Báo cáo tổng (gom theo chuỗi `coso`) tách "CGV Landmark 81" và "CGV LANDMARK 81" làm hai. */
	private static function dong_bo_nhan_so_( $ten, $key ) {
		global $wpdb;
		foreach ( array( 'bc', 'bc_khoa', 'bc_ma_misa', 'bc_congno_dau', 'bc_yeucau', 'bao_tri', 'bc_ma_nop', 'bc_thang_bs' ) as $b ) {
			$t = VHG_DB::t( $b );
			if ( 'bc_thang_bs' === $b && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ) !== $t ) { continue; }
			$wpdb->query( $wpdb->prepare( "UPDATE $t SET coso=%s WHERE coso_key=%s", $ten, $key ) );
		}
	}

	/* Bí danh lưu một dòng một tên (ngăn bằng xuống dòng) — tên cửa hàng có thể chứa dấu phẩy. */
	public static function bi_danh_tach_( $raw ) {
		$ra = array();
		foreach ( preg_split( '/[\r\n;|]+/', (string) $raw ) as $x ) { $x = trim( $x ); if ( '' !== $x && ! in_array( $x, $ra, true ) ) { $ra[] = $x; } }
		return $ra;
	}
	/* Gộp bí danh: bỏ trùng theo VHG_BaoCao::squash(), bỏ chính tên cơ sở (tên thật không phải bí danh). */
	public static function bi_danh_gop_( $raw_cu, $them, $ten_chinh ) {
		$ra = array(); $thay = array( VHG_BaoCao::squash( (string) $ten_chinh ) => 1 );
		foreach ( array_merge( self::bi_danh_tach_( $raw_cu ), (array) $them ) as $x ) {
			$x = trim( (string) $x ); $k = VHG_BaoCao::squash( $x );
			if ( '' === $k || isset( $thay[ $k ] ) ) { continue; }
			$thay[ $k ] = 1; $ra[] = $x;
		}
		return implode( "\n", $ra );
	}
	/**
	 * Khai BÍ DANH cho một cơ sở (tên cũ, tên cửa hàng bên cổng VietQR…) — anh Thắng 24/09/2026.
	 * Mỗi dòng một tên. Một tên không được là bí danh của hai cơ sở, cũng không được trùng tên thật
	 * của cơ sở khác: hai nơi cùng nhận một tên là Sao Kê quy tiền cho nơi nào tuỳ thứ tự đọc.
	 */
	public static function bi_danh_luu( $id, $bi_danh ) {
		global $wpdb;
		$id = (int) $id; if ( $id <= 0 ) { return array( 'ok' => false, 'error' => 'Thiếu cơ sở.' ); }
		$bang = VHG_DB::t( 'coso' );
		$ten = $wpdb->get_var( $wpdb->prepare( "SELECT ten FROM $bang WHERE id=%d", $id ) );
		if ( null === $ten ) { return array( 'ok' => false, 'error' => 'Không thấy cơ sở.' ); }
		$ds = self::bi_danh_tach_( $bi_danh );
		$moi = self::bi_danh_gop_( '', $ds, (string) $ten );
		$ds_moi = self::bi_danh_tach_( $moi );
		/* Không trùng tên thật / bí danh của cơ sở KHÁC. */
		$khac = $wpdb->get_results( $wpdb->prepare( "SELECT id, ten, bi_danh FROM $bang WHERE id<>%d", $id ), ARRAY_A );
		foreach ( (array) $khac as $c ) {
			$co = array_merge( array( (string) $c['ten'] ), self::bi_danh_tach_( isset( $c['bi_danh'] ) ? $c['bi_danh'] : '' ) );
			foreach ( $ds_moi as $b ) {
				foreach ( $co as $t ) {
					if ( VHG_BaoCao::squash( $b ) === VHG_BaoCao::squash( $t ) ) {
						return array( 'ok' => false, 'error' => '"' . $b . '" đang là tên/bí danh của cơ sở "' . $c['ten'] . '" — một tên không thể thuộc hai nơi. Gộp hai cơ sở nếu đó là cùng một điểm.' );
					}
				}
			}
		}
		$wpdb->update( $bang, array( 'bi_danh' => $moi ), array( 'id' => $id ) );
		self::quen_dem_reset_();
		return array( 'ok' => true, 'bi_danh' => $moi, 'ds' => $ds_moi,
			'thong_bao' => count( $ds_moi ) ? ( 'Đã khai ' . count( $ds_moi ) . ' bí danh cho "' . $ten . '": ' . implode( ' · ', $ds_moi ) ) : ( 'Đã xoá hết bí danh của "' . $ten . '".' ) );
	}

	/**
	 * Đánh dấu cơ sở ĐÃ ĐÓNG CỬA (hoặc mở lại). Chỉ ẩn khỏi danh sách làm việc — KHÔNG xoá gì.
	 * Anh Thắng 14/09/2026: *"cơ sở đóng cửa thì ẩn, chứ không hiện 2, 3 cơ sở như này"*.
	 */
	public static function dong_cua_coso( $id, $dong ) {
		global $wpdb;
		$id = (int) $id;
		if ( $id <= 0 ) { return array( 'ok' => false, 'error' => 'Thiếu cơ sở.' ); }
		$bang = VHG_DB::t( 'coso' );
		$ten = $wpdb->get_var( $wpdb->prepare( "SELECT ten FROM $bang WHERE id=%d", $id ) );
		if ( null === $ten ) { return array( 'ok' => false, 'error' => 'Không thấy cơ sở.' ); }
		$wpdb->update( $bang, array( 'dong_cua' => $dong ? 1 : 0 ), array( 'id' => $id ) );
		self::quen_dem_reset_();
		return array( 'ok' => true, 'dong_cua' => $dong ? 1 : 0,
			'thong_bao' => $dong
				? ( '🚪 Đã đánh dấu "' . $ten . '" ĐÓNG CỬA — ẩn khỏi danh sách. Ghế và báo cáo cũ giữ nguyên.' )
				: ( '↩ Đã mở lại "' . $ten . '".' ) );
	}

	public static function xoa_coso( $id ) {
		global $wpdb;
		$id = (int) $id;
		$so = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHG_DB::t( 'may' ) . ' WHERE coso_id=%d', $id ) );
		/* 🔴 KHÔNG XOÁ CƠ SỞ CÒN GHẾ — anh Thắng 12/09/2026: *"không ẩn số ghế tự nhiên, rồi tìm
		   lại không thấy… tình trạng bị liên tục"*. Bản trước đặt `coso_id=0` cho CẢ LOẠT ghế rồi xoá
		   luôn dòng cơ sở: mỗi ghế mất tên cơ sở → rơi khỏi mọi phạm vi PIN (ds_ghe/trong_pham_vi),
		   biến mất khỏi màn nhập THEO CỤM; tệ hơn, tên cơ sở bị xoá nên không còn tra ngược được. Đây
		   là NGUYÊN NHÂN gốc "cả loạt VHM biến mất một lúc ở một cơ sở". Nay chặn thẳng: phải điều
		   chuyển hết ghế sang cơ sở khác (nút "Đổi cơ sở"/"Điều chuyển") rồi mới xoá được cơ sở rỗng. */
		if ( $so > 0 ) {
			return array( 'ok' => false, 'error' => 'Cơ sở còn ' . $so . ' ghế — KHÔNG xoá được (xoá là '
				. 'cả loạt ghế mất khỏi màn nhập). Hãy "Đổi cơ sở" chuyển hết ghế sang nơi khác trước, '
				. 'rồi xoá cơ sở rỗng.' );
		}
		$wpdb->delete( VHG_DB::t( 'coso' ), array( 'id' => $id ) );
		return array( 'ok' => true, 'thong_bao' => 'Đã xoá cơ sở (rỗng, không còn ghế).' );
	}

	/**
	 * XOÁ HẲN MỘT CƠ SỞ (ĐIỂM) — anh Thắng 23/09/2026: *"một số cơ sở đã ẩn, nhưng khi xuất misa
	 * vẫn nhảy vào, nên anh cần xoá hẳn điểm đó luôn"*, kèm ảnh: ghế 80107 · CGV-PLZ-01 · CGV PEAR
	 * PLAZA · "đã ẩn".
	 *
	 * 🔴 VÌ SAO NÚT 🗑 CŨ KHÔNG XOÁ ĐƯỢC. `xoa_coso()` đếm `COUNT(*) WHERE coso_id=%d` — đếm cả ghế
	 *    ĐÃ ẨN. CGV PEAR PLAZA còn đúng một ghế ẩn (80107) nên bị chối "còn 1 ghế", mà ghế ấy thì
	 *    từ 2.115.0 không ẩn/xoá mềm được nữa, và xoá hẳn ghế lại nằm ở màn khác. Anh đi vòng ba
	 *    màn không ra: cơ sở "đã ẩn" mà vẫn nằm trong danh mục, nên Báo cáo tổng vẫn in nó thành
	 *    một dòng 0đ — đúng cái "vẫn nhảy vào".
	 *
	 * 🔴 NỚI ĐÚNG MỘT BẬC, Y NHƯ `xoa_han_may()` ĐÃ NỚI: ghế ĐÃ ẨN không chặn nữa — xoá hẳn luôn
	 *    cùng cơ sở. Ghế ĐANG CHẠY (không ẩn) vẫn chặn tuyệt đối: xoá cơ sở còn ghế sống là cả loạt
	 *    ghế rơi khỏi màn nhập (đúng vụ "cả loạt VHM biến mất" 12/09). Phải "Đổi cơ sở" trước.
	 *
	 * 🔴 CHỈ XOÁ DANH MỤC, KHÔNG XOÁ SỔ. Dòng `coso` + dòng `bc_ma_misa` + các ghế ẩn của nó ở
	 *    `may`. Báo cáo (`bc`/`bc_dong`), thu, chốt, nộp… nối bằng TÊN/`ma_may` chứ không bằng id,
	 *    nên còn nguyên: tổng tiền các tháng đã chốt KHÔNG đổi. Xuất MISA cho một tháng cơ sở này
	 *    còn doanh thu vẫn ra dòng của nó — đó là tiền thật, phải ra. Xoá xong thì nó chỉ hết
	 *    nằm trong danh mục: hết dòng 0đ ở Báo cáo tổng, hết chỗ để gán ghế mới vào.
	 * ⚠️ HỆ QUẢ PHẢI BIẾT: tạo lại cơ sở TRÙNG TÊN là báo cáo cũ ghép lại vào nó (ghép qua
	 *    squash(tên)). Đừng dùng lại tên đã xoá cho một điểm khác.
	 *
	 * `$that=false` = XEM TRƯỚC: kể ghế sống / ghế ẩn / số báo cáo còn trong sổ, chưa đụng gì.
	 *
	 * 🔴 `$cuong_che` — ADMIN TOÀN QUYỀN, anh Thắng 23/09/2026 sau khi bị chốt "còn 2 ghế ĐANG CHẠY
	 *    (80199, 80200)": *"cho phép admin toàn quyền xoá. Miễn giữ doanh thu là được. Xoá cả mã
	 *    ghế. Để anh lấy mã đó gán cho ghế đúng."*
	 *    Cưỡng chế bỏ chốt "ghế đang chạy": xoá luôn mọi dòng `may` của cơ sở, kể cả ghế sống —
	 *    mã được GIẢI PHÓNG để tạo lại ở đúng nơi. Điều KHÔNG bỏ: sổ tiền. Cưỡng chế hay không thì
	 *    bc/bc_dong/thu/chot/nop vẫn nằm nguyên — đó là điều kiện anh đặt, và cũng là điều kiện
	 *    của xoa_han_may() cưỡng chế từ 2.119.0. Ai được bấm: cổng kiểm `la_quan_tri()` (xem
	 *    router), hàm này chỉ làm việc, không tự kiểm quyền.
	 * ⚠️ HỆ QUẢ ANH CẦN BIẾT TRƯỚC KHI GÁN LẠI: tạo lại ghế TRÙNG MÃ (80199) ở cơ sở khác là nó
	 *    NHẶT LẠI toàn bộ lịch sử tiền của mã ấy (mọi bảng nối bằng chuỗi `ma_may`). Với "gán cho
	 *    ghế đúng" — cùng cái ghế, chỉ đổi chỗ — thì đúng là điều anh muốn: tiền theo ghế. Nhưng
	 *    gán mã ấy cho MỘT GHẾ KHÁC thì lịch sử của ghế cũ dính vào ghế mới. Hộp hỏi nói câu này.
	 */
	public static function xoa_han_coso( $id, $that = false, $cuong_che = false ) {
		global $wpdb;
		$id = (int) $id;
		if ( $id <= 0 ) { return array( 'ok' => false, 'error' => 'Thiếu cơ sở.' ); }
		$t_cs = VHG_DB::t( 'coso' ); $t_may = VHG_DB::t( 'may' );
		$cs = $wpdb->get_row( $wpdb->prepare( "SELECT id, ten, dong_cua FROM $t_cs WHERE id=%d", $id ), ARRAY_A );
		if ( ! $cs ) { return array( 'ok' => false, 'error' => 'Không thấy cơ sở.' ); }
		$ten = (string) $cs['ten'];

		$ghe = $wpdb->get_results( $wpdb->prepare( "SELECT ma, an FROM $t_may WHERE coso_id=%d ORDER BY ma", $id ), ARRAY_A );
		$song = array(); $an = array();
		foreach ( (array) $ghe as $g ) { if ( empty( $g['an'] ) ) { $song[] = (string) $g['ma']; } else { $an[] = (string) $g['ma']; } }

		/* Sổ còn gì nói về cơ sở này — chỉ để NGƯỜI đọc trước khi bấm, không phải chốt chặn. */
		$key = VHG_BaoCao::squash( $ten );
		$so_bc = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHG_DB::t( 'bc' ) . ' WHERE coso_key=%s', $key ) );
		$tien_bc = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COALESCE(SUM(d.tong),0) FROM ' . VHG_DB::t( 'bc_dong' ) . ' d JOIN ' . VHG_DB::t( 'bc' )
			. ' h ON h.report_id=d.report_id WHERE h.coso_key=%s', $key ) );
		$co_misa = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHG_DB::t( 'bc_ma_misa' ) . ' WHERE coso_key=%s', $key ) );

		if ( count( $song ) && ! $cuong_che ) {
			return array( 'ok' => false, 'xem_truoc' => ! $that, 'coso' => $ten, 'ghe_song' => $song, 'ghe_an' => $an,
				'can_cuong_che' => 1,
				'error' => 'Cơ sở còn ' . count( $song ) . ' ghế ĐANG CHẠY (' . implode( ', ', array_slice( $song, 0, 8 ) )
					. ( count( $song ) > 8 ? '…' : '' ) . ') — KHÔNG xoá được. Ghế ẩn thì xoá theo được, ghế đang chạy thì '
					. 'phải "Đổi cơ sở" sang nơi khác trước, không thì cả loạt rơi khỏi màn nhập.' );
		}

		if ( ! $that ) {
			return array( 'ok' => true, 'xem_truoc' => true, 'coso' => $ten, 'dong_cua' => (int) $cs['dong_cua'],
				'ghe_song' => $song, 'ghe_an' => $an, 'cuong_che' => $cuong_che ? 1 : 0,
				'so_bao_cao' => $so_bc, 'tien_bao_cao' => $tien_bc, 'co_misa' => $co_misa );
		}

		/* Ghế ẩn đi trước (chỉ dòng `may`, đúng luật của xoa_han_may: `an=1`), rồi tới danh mục. */
		$da_ghe = 0;
		foreach ( $an as $ma ) {
			$da_ghe += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM $t_may WHERE ma=%s AND coso_id=%d AND an=1", $ma, $id ) );
		}
		/* Cưỡng chế: ghế ĐANG CHẠY xoá theo — khoá theo ĐÚNG coso_id để không quét lạc ghế cùng mã ở
		   cơ sở khác (trùng mã liên cơ sở là chuyện đã xảy ra, xem 2.117.0). */
		$da_song = 0;
		if ( $cuong_che ) {
			foreach ( $song as $ma ) {
				$da_song += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM $t_may WHERE ma=%s AND coso_id=%d", $ma, $id ) );
			}
		}
		$wpdb->delete( VHG_DB::t( 'bc_ma_misa' ), array( 'coso_key' => $key ) );
		$wpdb->delete( $t_cs, array( 'id' => $id ) );
		self::quen_dem_reset_();
		return array( 'ok' => true, 'da_xoa' => 1, 'coso' => $ten, 'da_xoa_ghe' => $da_ghe, 'da_xoa_song' => $da_song,
			'ma_giai_phong' => $cuong_che ? $song : array(), 'so_bao_cao' => $so_bc,
			'thong_bao' => '🗑 Đã xoá hẳn cơ sở "' . $ten . '"'
				. ( $da_ghe ? ( ' cùng ' . $da_ghe . ' mã ghế ẩn' ) : '' )
				. ( $da_song ? ( ( $da_ghe ? ' và ' : ' cùng ' ) . $da_song . ' mã ghế ĐANG CHẠY (cưỡng chế) — mã ' . implode( ', ', $song ) . ' đã trống, tạo lại được ở cơ sở đúng' ) : '' ) . '.'
				. ( $so_bc ? ( ' ' . $so_bc . ' báo cáo cũ (' . number_format( $tien_bc, 0, ',', '.' ) . 'đ) vẫn nằm trong sổ — '
					. 'tổng tiền không đổi, xuất MISA tháng có doanh thu vẫn ra. ĐỪNG tạo lại cơ sở trùng tên.' ) : '' ) );
	}

	/**
	 * LỊCH NỘP BÁO CÁO THEO TUẦN của một cơ sở — anh Thắng 29/08/2026: "Với mỗi cơ sở sẽ set
	 * lịch nộp báo cáo theo tuần, từ đó theo lịch cơ sở nào chưa nộp báo cáo". `$thu` là mảng số
	 * thứ ISO (1=Thứ Hai…7=Chủ Nhật) — rỗng nghĩa là cơ sở KHÔNG được kỳ vọng nộp ngày nào (tạm
	 * ngưng), khác với giá trị mặc định lúc chưa ai cấu hình (mọi ngày, xem cột `lich_bc`).
	 */
	public static function luu_lich_coso( $id, $thu ) {
		global $wpdb;
		$id = (int) $id;
		if ( $id <= 0 ) { return array( 'ok' => false, 'error' => 'Thiếu cơ sở.' ); }
		$ds = array();
		foreach ( (array) $thu as $t ) {
			$t = (int) $t;
			if ( $t >= 1 && $t <= 7 && ! in_array( $t, $ds, true ) ) { $ds[] = $t; }
		}
		sort( $ds );
		$wpdb->update( VHG_DB::t( 'coso' ), array( 'lich_bc' => implode( ',', $ds ) ), array( 'id' => $id ) );
		return array( 'ok' => true, 'thong_bao' => 'Đã lưu lịch nộp báo cáo.' );
	}

	// ======================================================================= ô quảng cáo mã

	/**
	 * Ô nào trên màn ghế luân phiên hiện lời mời mua mã giảm giá, và mỗi vế bao lâu.
	 *
	 * 🔴 Anh Thắng 23/08/2026: *"nó sẽ hiện đè chỗ mệnh giá 100k — 100k hiện 30s, mã giảm giá
	 *    hiện 30s, luân phiên"*. Tem QR thì dán cứng cạnh thùng tiền, nên ô này chỉ MỜI, không
	 *    vẽ mã.
	 *
	 * ⚠️ MẶC ĐỊNH TẮT. Chưa khai bảng giảm giá mà đã mời khách mua mã là mời họ tới một trang bán
	 *    hàng không giảm đồng nào — mất lòng tin ngay lần đầu, và lần sau họ không quét nữa.
	 * ⚠️ Ô phải NẰM TRONG SỐ Ô ĐANG CÓ. Khai ô số 4 trong khi ghế chỉ hiện 3 gói là một ô quảng
	 *    cáo không bao giờ xuất hiện, mà trên web nhìn vẫn như đã bật.
	 */
	public static function qc_ma() {
		$o = get_option( 'vhg_qc_o' );
		/* ⚠️ `get_option` trả `false` khi CHƯA KHAI, và `(int) false` là 0 — tức là bật ô đầu
		   tiên thay vì tắt. Đúng ngược lại điều mình muốn, và ngược một cách im lặng: cửa hàng
		   chưa khai gì đã tự mời khách mua mã. Phải xét cả `false`. */
		$o = ( false === $o || null === $o || '' === $o ) ? -1 : (int) $o;
		$giay = (int) get_option( 'vhg_qc_giay', 30 );
		/* 5..300: dưới 5 giây là chữ nhấp nháy không ai đọc kịp; trên 5 phút thì một trong hai
		   vế coi như không tồn tại. */
		$giay = max( 5, min( 300, $giay ) );
		$n = count( self::menh_gia() );
		if ( $o < 0 || $o >= $n ) { return array( 'o' => -1, 'giay' => $giay, 'giam' => 0 ); }
		/* Giảm cao nhất trong bảng — đó là con số đáng đưa lên màn. Không có giảm nào thì tắt. */
		$giam = 0;
		foreach ( VHG_Ma::bang_giam() as $pt ) { if ( (int) $pt > $giam ) { $giam = (int) $pt; } }
		if ( $giam <= 0 ) { return array( 'o' => -1, 'giay' => $giay, 'giam' => 0 ); }
		return array( 'o' => $o, 'giay' => $giay, 'giam' => $giam );
	}

	// ======================================================================= nhật ký bật từ xa

	/**
	 * NHẬT KÝ BẬT GHẾ TỪ XA — để đối chiếu sau này.
	 *
	 * 🔴 Vì sao đây là bảng phải có, chứ không phải "tính năng thêm cho đẹp":
	 *    Mỗi lần bấm Bật là CHO KHÔNG một lượt massage. Ghế chạy, điện tốn, khách được phục vụ,
	 *    mà sổ doanh thu không có đồng nào. Cuối tháng nhìn "ghế AMTP01 chạy 180 lượt, thu 140
	 *    lượt" thì 40 lượt kia phải giải thích được — bằng con số, không bằng trí nhớ.
	 *
	 * ⚠️ Đếm cả lệnh CHƯA GỬI XUỐNG GHẾ. `gui_luc` rỗng nghĩa là ghế chưa lấy (đang mất mạng),
	 *    nhưng người bấm thì đã bấm rồi và ghế sẽ chạy khi lên mạng. Lọc bỏ nó đi là nhật ký nói
	 *    ít hơn sự thật đúng vào những ngày mạng chập chờn — tức là đúng những ngày cần tra nhất.
	 * ⚠️ CHỈ đếm `viec='on'`. Lệnh `off` không cho ai cái gì cả; gộp vào là thổi phồng con số
	 *    "cho không" bằng những lần người ta tắt ghế đi.
	 */
	/* Tên là `ds_lenh_bat` chứ không `ds_lenh`: đã có sẵn `ds_lenh()` liệt kê MỌI lệnh cho màn
	   gỡ rối. Hai hàm hai việc, và trùng tên thì PHP báo lỗi ngay — nhưng nếu chỉ khác tham số
	   thì người đọc sau này mới là người phải đoán. */
	public static function ds_lenh_bat( $ky = 'month', $gioi_han = 500 ) {
		global $wpdb;
		$t  = VHG_DB::t( 'lenh' );
		$tu = VHG_Thu::dau_ky( $ky );
		$den = VHG_Thu::cuoi_ky( $ky );
		$sql = "SELECT * FROM $t WHERE viec='on'";
		if ( '' !== $tu ) { $sql = $wpdb->prepare( $sql . ' AND tao_luc >= %s', $tu ); }
			if ( '' !== $den ) { $sql = $wpdb->prepare( $sql . ' AND tao_luc < %s', $den ); }
		$sql .= ' ORDER BY tao_luc DESC, id DESC LIMIT ' . (int) $gioi_han;
		return VHG_DB::rows( $sql );
	}

	/**
	 * Gộp theo NGÀY: mỗi ngày bật mấy lần, tổng bao nhiêu phút.
	 *
	 * Gộp bằng SQL chứ không kéo hết về rồi cộng trong PHP: bảng này chỉ có thêm, không bao giờ
	 * bớt, nên "cả năm" của 26 ghế là con số lớn dần mãi — và màn đối soát mở suốt ngày trên 4G.
	 */
	public static function tong_lenh_ngay( $ky = 'month' ) {
		global $wpdb;
		$t  = VHG_DB::t( 'lenh' );
		$tu = VHG_Thu::dau_ky( $ky );
		$den = VHG_Thu::cuoi_ky( $ky );
		$sql = "SELECT DATE(tao_luc) AS ngay, COUNT(*) AS so_lan, SUM(phut) AS tong_phut"
			. " FROM $t WHERE viec='on'";
		if ( '' !== $tu ) { $sql = $wpdb->prepare( $sql . ' AND tao_luc >= %s', $tu ); }
			if ( '' !== $den ) { $sql = $wpdb->prepare( $sql . ' AND tao_luc < %s', $den ); }
		$sql .= ' GROUP BY DATE(tao_luc) ORDER BY ngay DESC LIMIT 400';
		$ra = array();
		foreach ( VHG_DB::rows( $sql ) as $r ) {
			$ra[] = array( 'ngay' => (string) $r['ngay'], 'so_lan' => (int) $r['so_lan'],
				'tong_phut' => (int) $r['tong_phut'] );
		}
		return $ra;
	}

	/**
	 * Gộp theo GHẾ: ghế nào đã kích hoạt tay, mấy lần, tổng bao nhiêu phút, lần gần nhất khi nào.
	 *
	 * Đây là câu hỏi đầu tiên lúc đối chiếu: "ghế nào hay được bật không?". Một ghế lên đầu bảng
	 * tháng này qua tháng khác thì hoặc nó hỏng thật, hoặc có người đang quen tay — hai chuyện
	 * đều đáng biết, và không chuyện nào lộ ra từ bảng gộp theo ngày.
	 */
	public static function tong_lenh_may( $ky = 'month' ) {
		global $wpdb;
		$t  = VHG_DB::t( 'lenh' );
		$tu = VHG_Thu::dau_ky( $ky );
		$den = VHG_Thu::cuoi_ky( $ky );
		$sql = "SELECT ma_may, COUNT(*) AS so_lan, SUM(phut) AS tong_phut, MAX(tao_luc) AS lan_cuoi"
			. " FROM $t WHERE viec='on'";
		if ( '' !== $tu ) { $sql = $wpdb->prepare( $sql . ' AND tao_luc >= %s', $tu ); }
			if ( '' !== $den ) { $sql = $wpdb->prepare( $sql . ' AND tao_luc < %s', $den ); }
		$sql .= ' GROUP BY ma_may ORDER BY so_lan DESC, tong_phut DESC LIMIT 200';
		$ra  = array();
		$may = self::ds_may_theo_ma();
		foreach ( VHG_DB::rows( $sql ) as $r ) {
			$m = (string) $r['ma_may'];
			$ra[] = array( 'ma' => $m,
				'coso' => isset( $may[ $m ] ) ? (string) $may[ $m ]['coso_ten'] : '',
				'so_lan' => (int) $r['so_lan'], 'tong_phut' => (int) $r['tong_phut'],
				'lan_cuoi' => (string) $r['lan_cuoi'] );
		}
		return $ra;
	}

	/** Tổng gọn của một kỳ: bao nhiêu lần, bao nhiêu phút, trên mấy ghế. */
	public static function tong_lenh( $ky = 'month' ) {
		global $wpdb;
		$t  = VHG_DB::t( 'lenh' );
		$tu = VHG_Thu::dau_ky( $ky );
		$den = VHG_Thu::cuoi_ky( $ky );
		$sql = "SELECT COUNT(*) AS so_lan, SUM(phut) AS tong_phut, COUNT(DISTINCT ma_may) AS so_ghe"
			. " FROM $t WHERE viec='on'";
		if ( '' !== $tu ) { $sql = $wpdb->prepare( $sql . ' AND tao_luc >= %s', $tu ); }
			if ( '' !== $den ) { $sql = $wpdb->prepare( $sql . ' AND tao_luc < %s', $den ); }
		$r = $wpdb->get_row( $sql, ARRAY_A );
		return array( 'so_lan' => (int) ( $r ? $r['so_lan'] : 0 ),
			'tong_phut' => (int) ( $r ? $r['tong_phut'] : 0 ),
			'so_ghe' => (int) ( $r ? $r['so_ghe'] : 0 ) );
	}

	/**
	 * Đếm số lượt BẬT TAY (`viec='on'`) của một ghế trong khoảng NGÀY (SAU $tu_ngay, tới HẾT
	 * $den_ngay) — dùng để trừ ra khỏi doanh thu ở VHG_BaoCao::kich_xa_tru(), xem khối 🔴 ở đó.
	 *
	 * $tu_ngay rỗng = không giới hạn đầu (tính hết mọi lượt TRƯỚC đó — báo cáo đầu tiên của ghế,
	 * chưa ai trừ những lượt này bao giờ). $tu_ngay có giá trị thì LOẠI TRỪ chính ngày đó, vì đó
	 * là mốc chỉ số của báo cáo TRƯỚC — lượt kích trong ngày đó coi như đã tính ở kỳ trước rồi.
	 */
	public static function dem_luot_kich( $ma_may, $tu_ngay, $den_ngay ) {
		global $wpdb;
		$ma  = trim( (string) $ma_may );
		$den = trim( (string) $den_ngay );
		if ( '' === $ma || '' === $den || ! preg_match( '/^\d{4}-\d{2}-\d{2}/', $den ) ) { return 0; }
		$t = VHG_DB::t( 'lenh' );
		/* Mốc CUỐI = đầu ngày HÔM SAU $den — "tới hết $den" viết bằng `<` cho chắc so với chuỗi
		   giờ:phút:giây, khỏi lệ thuộc $den có kèm giờ hay không. */
		$den_moc = gmdate( 'Y-m-d', strtotime( $den . ' +1 day' ) );
		$tu = trim( (string) $tu_ngay );
		if ( '' !== $tu && preg_match( '/^\d{4}-\d{2}-\d{2}/', $tu ) ) {
			$tu_moc = gmdate( 'Y-m-d', strtotime( $tu . ' +1 day' ) );
			return (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM $t WHERE ma_may=%s AND viec='on' AND tao_luc >= %s AND tao_luc < %s",
				$ma, $tu_moc, $den_moc ) );
		}
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $t WHERE ma_may=%s AND viec='on' AND tao_luc < %s", $ma, $den_moc ) );
	}

	/**
	 * Đếm số lượt bật tay của CẢ CƠ SỞ trong ĐÚNG MỘT NGÀY — cho tab "Báo cáo hỗ trợ khách" (Hotline)
	 * xem tham khảo, đối chiếu với số họ tự gõ. KHÁC dem_luot_kich() ở trên: hàm đó cộng dồn theo
	 * MỘT GHẾ qua nhiều ngày (để trừ doanh thu); hàm này cộng theo MỘT NGÀY qua NHIỀU GHẾ của cùng
	 * cơ sở (để đối chiếu sổ tay hằng ngày) — hai trục khác nhau, không dùng lẫn được.
	 */
	public static function dem_luot_kich_coso_ngay( $coso, $ngay ) {
		global $wpdb;
		$coso = trim( (string) $coso );
		$ngay = trim( (string) $ngay );
		if ( '' === $coso || ! preg_match( '/^\d{4}-\d{2}-\d{2}/', $ngay ) ) { return 0; }
		$t_lenh = VHG_DB::t( 'lenh' ); $t_may = VHG_DB::t( 'may' ); $t_coso = VHG_DB::t( 'coso' );
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $t_lenh l JOIN $t_may m ON m.ma=l.ma_may JOIN $t_coso c ON c.id=m.coso_id"
			. " WHERE c.ten=%s AND l.viec='on' AND DATE(l.tao_luc)=%s",
			$coso, substr( $ngay, 0, 10 ) ) );
	}

	// ======================================================================= cục nhận tiền

	/**
	 * Các mã lỗi cục nhận tiền mà ghế được phép khai. Kèm câu người đứng quầy đọc là hiểu phải
	 * làm gì — "lỗi E03" thì ai cũng chịu.
	 *
	 * ⚠️ CHỈ NHẬN MÃ TRONG DANH SÁCH NÀY. Ghế nói gì cũng ghi vào cột là mở đường cho một chuỗi
	 *    lạ chui thẳng vào màn quản trị; mà cổng máy chỉ có một khoá chung, ai biết khoá là gửi
	 *    được. Mã lạ -> coi như không có lỗi, và điều đó AN TOÀN: bỏ sót một cảnh báo còn hơn
	 *    tin một cảnh báo bịa.
	 */
	const LOI_TIEN = array(
		/* --- Cổng tiền SERIAL (bản mới, cong_tien.h) --------------------------------------- */
		'ket'   => 'Tờ tiền vào khay tạm mà KHÔNG nuốt được — cục nhận báo có tiền nhưng quá lâu '
			. 'không xong (lúc ghế đang rảnh). Cục nhận kẹt/lỗi, hoặc ghế không phản hồi. Rút điện '
			. 'cục nhận 10 giây rồi cắm lại; còn nữa thì kiểm dây bus tiền và mạch chia mức về ghế.',
		'qr'    => 'Bơm QR mà ghế KHÔNG ăn — ghế không đáp xác nhận. Kiểm dây bus tiền (IO27 sang '
			. 'ghế), rơ-le bypass có đang ở chế độ ESP không, và mạch chia mức 3,3→5V.',
		'ghekhongchay' => 'ĐÃ TRẢ TIỀN MÀ GHẾ KHÔNG CHẠY — khách đã trả tiền nhưng motor ghế không '
			. 'hoạt động (chân báo-chạy của bo ghế vẫn ở mức tắt), nên đồng hồ QR ĐANG CHỜ, CHƯA trừ '
			. 'giờ. Nguyên nhân: ghế lỗi/kẹt cơ/mất nguồn động cơ, hoặc lệnh chưa xuống (mạng chập '
			. 'chờn). RA KIỂM NGAY kẻo khách trả tiền mà không được dùng.',
		'ghedungdotngot' => 'GHẾ DỪNG ĐỘT NGỘT giữa chừng — đang massage mà ghế ngừng chạy trong khi '
			. 'khách CÒN giờ. Ghế dừng quá 30 giây không chạy lại nên phiên ĐÃ TỰ KẾT THÚC (tắt QR). '
			. 'Ghế kẹt/lỗi/mất nguồn động cơ, hoặc có người bấm dừng. RA KIỂM; nếu khách chưa dùng '
			. 'hết giờ thì xử lý bù cho khách.',
		/* --- Cục nhận tiền ICT tự báo bệnh (mã 0x2X đo thật trên bus) ---------------------- */
		'ictgiay' => 'Cục nhận tiền báo: có tờ NHÉT VÀO nhưng KHÔNG PHẢI TIỀN (giấy lạ/tờ giả/rách '
			. 'quá). Rút tờ đó ra. Nếu tờ tiền thật vẫn báo vậy thì lau cảm biến hoặc kiểm cấu hình mệnh giá.',
		'ictcbd'  => 'Cục nhận tiền: KẸT CẢM BIẾN LỐI RA DƯỚI — có dị vật/tờ tiền chắn cảm biến phía '
			. 'dưới. Mở cục nhận, lấy dị vật, lau cảm biến.',
		'ictlt'   => 'Cục nhận tiền: KẸT ĐẦU RA LỐI TRÊN — tờ tiền/dị vật kẹt ở đường ra phía trên '
			. '(chỗ đẩy vào thùng). Mở lấy ra, kiểm đường tiền.',
		'ictnc'   => 'Cục nhận tiền: KẸT TỜ TIỀN NỬA CHỪNG — tờ tiền mắc giữa đường, chưa vào chưa ra. '
			. 'Rút tờ ra, kiểm con lăn/băng tải.',
		'ictla'   => 'Cục nhận tiền BÁO LỖI (mã chưa rõ tên) — mở xem có kẹt/dị vật/đầy thùng không, '
			. 'và xem log Serial của ghế để biết mã cụ thể rồi báo kỹ thuật.',
		/* --- Đường XUNG cũ (giữ lại phòng bo còn chạy pulse; firmware serial không sinh nữa) - */
		'lech'  => 'Đếm xung lệch — một đợt tiền ra số không chia hết cho 10.000đ, tức là mất '
			. 'hoặc thừa xung. TIỀN ĐANG ĐẾM SAI: đối chiếu két với sổ ngay.',
		'khoa'  => 'Đã khoá mà vẫn nhận tiền — dây INHIBIT tuột hoặc sai cực. Tiền vào két mà ghế '
			. 'không tính giờ, và trên sổ sẽ không có dòng nào.',
		'nhieu' => 'Nhiễu trên đường xung — nhiều cạnh giả bị lọc trong một đợt. Chưa chắc đã sai '
			. 'tiền, nhưng là dấu hiệu dây tín hiệu đi sát dây nguồn hoặc mát kém.',
	);

	/** Bản tiếng Anh, khai cùng chỗ với bản tiếng Việt — hai tệp là hai lần quên sửa một bên. */
	const LOI_TIEN_EN = array(
		'ket'   => 'A bill sat in escrow but was NOT stacked — the acceptor reported a bill but never '
			. 'finished (while the chair was idle). The acceptor is jammed/faulty, or the chair did '
			. 'not respond. Unplug the acceptor for 10s and plug it back in; if it persists, check '
			. 'the money-bus wiring and the level shifter to the chair.',
		'qr'    => 'QR credit was injected but the chair did NOT accept it (no acknowledgement). Check '
			. 'the money bus (IO27 to the chair), that the bypass relay is in ESP mode, and the '
			. '3.3->5V level shifter.',
		'ghekhongchay' => 'PAID AND TIMING BUT THE CHAIR IS NOT RUNNING — the customer paid, the timer '
			. 'is counting, but the chair motor is not running (the chair board\'s run pin is still low). '
			. 'The chair may be faulty, mechanically jammed, or lost motor power. CHECK NOW so the '
			. 'customer is not charged without service.',
		'ghedungdotngot' => 'CHAIR STOPPED MID-SESSION — the chair stopped while the customer still had '
			. 'time left. It stayed stopped for over 30s without resuming, so the session AUTO-ENDED (QR '
			. 'off). The chair is jammed/faulty/lost motor power, or someone pressed stop. CHECK; if the '
			. 'customer had unused time, compensate them.',
		'ictgiay' => 'Bill acceptor: a NON-CASH item was inserted (paper/fake/too torn). Remove it. If '
			. 'a real bill still triggers this, clean the sensor or check the denomination config.',
		'ictcbd'  => 'Bill acceptor: LOWER EXIT SENSOR JAMMED — debris/a bill is blocking the lower '
			. 'sensor. Open the acceptor, remove it, clean the sensor.',
		'ictlt'   => 'Bill acceptor: UPPER EXIT JAM — a bill/debris is stuck at the upper exit (into the '
			. 'stacker). Open and clear it.',
		'ictnc'   => 'Bill acceptor: BILL JAMMED MIDWAY — a bill is stuck in the path. Remove it, check '
			. 'the rollers/belt.',
		'ictla'   => 'Bill acceptor reported an error (code not yet named) — open and check for a jam/'
			. 'debris/full stacker, and read the chair Serial log for the exact code.',
		'lech'  => 'Pulse count is off — one batch came to an amount not divisible by 10,000đ, so a '
			. 'pulse was lost or added. MONEY IS BEING MISCOUNTED: reconcile the cash box now.',
		'khoa'  => 'Credited while inhibited — the INHIBIT wire is loose or has the wrong polarity. '
			. 'Cash reaches the box but the chair does not credit it, and no entry is recorded.',
		'nhieu' => 'Noise on the pulse line — many false edges filtered out in one batch. It may not '
			. 'have miscounted yet, but the signal wire is running too close to power, or the '
			. 'ground is poor.',
	);

	public static function ma_loi_tien( $v ) {
		$s = strtolower( trim( (string) $v ) );
		return isset( self::LOI_TIEN[ $s ] ) ? $s : '';
	}

	public static function loi_tien_chu( $ma, $nn = 'vi' ) {
		$ma = self::ma_loi_tien( $ma );
		if ( '' === $ma ) { return ''; }
		return 'en' === $nn ? self::LOI_TIEN_EN[ $ma ] : self::LOI_TIEN[ $ma ];
	}

	/**
	 * Ghế khai TUỔI (bao nhiêu giây trước) -> máy chủ đổi ra giờ tuyệt đối của mình.
	 * `-1` (hoặc số âm) = chưa từng xảy ra, trả về null chứ không phải "vừa xong".
	 */
	public static function luc_tu_tuoi( $giay ) {
		$g = (int) $giay;
		if ( $g < 0 ) { return null; }
		/* Chặn trên 1 năm: ghế chạy lâu thì millis() rất lớn, mà một con số vượt tầm DATETIME
		   làm hỏng cả hàng nhịp — mất luôn thứ quan trọng hơn vì một cái mốc chỉ để tham khảo. */
		if ( $g > 31536000 ) { return null; }
		return gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - $g );
	}

	// ======================================================================= máy

	public static function ds_may() {
		$may  = VHG_DB::t( 'may' );
		$coso = VHG_DB::t( 'coso' );
		$nhip = VHG_DB::t( 'nhip' );
		$ds = VHG_DB::rows(
			"SELECT m.*, c.ten AS coso_ten, n.trang_thai, n.nguon AS nhip_nguon, n.con_lai,"
			. " n.fw, n.ip, n.nd_tien_to, n.tre_ms, n.tm_loi, n.tm_cuoi, n.tm_lan,"
			. " n.tm_luc, n.tm_to, n.khoa, n.kt, n.luc AS nhip_luc FROM $may m"
			. " LEFT JOIN $coso c ON c.id = m.coso_id"
			. " LEFT JOIN $nhip n ON n.ma_may = m.ma"
			. ' ORDER BY c.ten ASC, m.ma ASC' );
		$gio = current_time( 'timestamp' );
		foreach ( $ds as $i => $x ) {
			$ds[ $i ]['coso_ten'] = (string) $x['coso_ten'];
			$tt = self::tinh_trang_nhip( isset( $x['nhip_luc'] ) ? $x['nhip_luc'] : '', $gio );
			/* ==================================================================================
			 * SỐ GIÂY CÒN LẠI PHẢI TRỪ ĐI TUỔI CỦA CHÍNH CON SỐ ĐÓ.
			 *
			 * 🔴 Anh Thắng 22/08/2026: *"bấm thử điều khiển ghế thì lệch 12s — thời gian máy QR
			 *    nhanh hơn 11s"*. Không phải cố ý chừa thời gian cho khách lên ghế; đó là tuổi
			 *    của dữ liệu.
			 *
			 *    Ghế gửi nhịp 30 giây một lần. Nó nói "còn 300 giây" lúc 21:46:00. Web hỏi lúc
			 *    21:46:11 và nhận đúng con số 300 đó — nhưng ghế đã chạy thêm 11 giây rồi. Web
			 *    tự trừ mỗi giây từ 300, nên nó chậm hơn ghế đúng 11 giây, mãi mãi, cho tới lượt
			 *    nhịp sau. Trung bình lệch nửa chu kỳ nhịp = 15 giây.
			 *
			 * Máy chủ biết nhịp đó tới lúc nào, nên trừ được. Sửa ở ĐÂY chứ không bắt ghế gửi
			 * nhịp dày hơn: ghế chạy 4G, mỗi lượt nhịp là tiền, và 26 ghế × mỗi 5 giây là một
			 * khoản không nhỏ cho một con số chỉ để nhìn.
			 *
			 * ⚠️ Chỉ trừ khi ghế ĐANG CHẠY. Ghế rảnh thì `con_lai` vốn là 0; ghế mất kết nối thì
			 *    con số nào cũng vô nghĩa — trừ tiếp chỉ tạo ra một đồng hồ chạy lùi trông như
			 *    thật, mà thật ra không ai biết ghế còn chạy hay không.
			 * ================================================================================== */
			$con = (int) ( isset( $x['con_lai'] ) ? $x['con_lai'] : 0 );
			if ( $tt['song'] && 'running' === (string) $x['trang_thai'] && null !== $tt['giay'] ) {
				/* Trừ HAI phần, hai nguồn khác nhau:
				   · tuổi của nhịp: từ lúc máy chủ nhận tới bây giờ — máy chủ tự biết.
				   · nửa quãng đi: ghế tính con số TRƯỚC khi gọi, dấu giờ đóng LÚC NHẬN. Máy chủ
				     không thấy quãng này, nên ghế phải tự khai (`tre_ms` = lượt trước mất bao lâu).
				     Nửa chứ không trọn: `tre_ms` là cả đi lẫn về, chỉ chiều đi mới nằm giữa hai mốc. */
				$con = max( 0, $con - (int) $tt['giay']
					- (int) round( (int) ( isset( $x['tre_ms'] ) ? $x['tre_ms'] : 0 ) / 2000 ) );
			}
			$ds[ $i ]['con_lai']      = $con;
			$ds[ $i ]['nhip_giay']    = $tt['giay'];
			$ds[ $i ]['con_song']     = $tt['song'];
			$ds[ $i ]['chua_bao_gio'] = $tt['chua_bao_gio'];
			$ds[ $i ]['nhip_chu']     = $tt['chu'];
			$ds[ $i ]['cho']          = self::so_cho( $x['ma'] );
			$ds[ $i ]['khoa']         = ! empty( $x['khoa'] ) ? 1 : 0;
			$ds[ $i ]['kt']           = ! empty( $x['kt'] ) ? 1 : 0;
		}
		return $ds;
	}

	/** Bản đồ mã máy -> thông tin, để tra nhanh khi tổng hợp doanh thu. */
	public static function ds_may_theo_ma() {
		$ra = array();
		foreach ( self::ds_may() as $m ) {
			$ra[ $m['ma'] ] = $m;
			/* Tra được cả bằng TÊN KHAI: giao dịch của Tingo mang tên "AMTP 03" chứ không mang
			   mã ghế, nên không có khoá này thì cơ sở của chúng luôn là "chưa gán". */
			if ( '' !== (string) $m['ten_khai'] ) {
				$ra[ VHG_Doc::chuan_ten( $m['ten_khai'] ) ] = $m;
			}
		}
		return $ra;
	}

	/**
	 * Ghế này đang thế nào, NÓI BẰNG CÂU NGƯỜI ĐỌC ĐƯỢC.
	 *
	 * 🔴 Anh Thắng 22/08/2026: *"đã add, nhưng máy chưa nhận"*. Màn hình lúc đó chỉ nói "Mất kết
	 *    nối" — đúng, nhưng vô dụng, vì nó gộp BA ca đi sửa ở ba nơi khác hẳn:
	 *      · CHƯA BAO GIỜ gửi nhịp  -> ghế chưa nạp firmware mới, hoặc nạp rồi mà sai địa chỉ
	 *                                  web / sai khoá. Đi kiểm cổng USB và secrets.h.
	 *      · Gửi rồi, vừa mới im    -> mạng chập. Đợi một lượt nhịp (~30 giây) rồi xem lại.
	 *      · Gửi rồi, im đã lâu     -> ghế mất điện, rớt 4G, hoặc treo. Đi tới nơi.
	 *    Ba câu đó khác nhau ở chỗ NGƯỜI ĐỌC PHẢI LÀM GÌ TIẾP. Gộp làm một là bắt người ta đoán.
	 *
	 * @return array [ 'song' => bool, 'chua_bao_gio' => bool, 'giay' => int|null, 'chu' => string ]
	 */
	public static function tinh_trang_nhip( $luc, $bay_gio = null ) {
		$luc = trim( (string) $luc );
		if ( null === $bay_gio ) { $bay_gio = current_time( 'timestamp' ); }
		if ( '' === $luc ) {
			return array( 'song' => false, 'chua_bao_gio' => true, 'giay' => null,
				'chu' => 'chưa bao giờ gửi nhịp' );
		}
		$t = strtotime( $luc );
		if ( ! $t ) {
			return array( 'song' => false, 'chua_bao_gio' => true, 'giay' => null,
				'chu' => 'chưa bao giờ gửi nhịp' );
		}
		$giay = max( 0, (int) ( $bay_gio - $t ) );
		if ( $giay <= self::HET_SONG ) {
			return array( 'song' => true, 'chua_bao_gio' => false, 'giay' => $giay,
				'chu' => 'đang sống · ' . self::truoc_day( $giay ) );
		}
		return array( 'song' => false, 'chua_bao_gio' => false, 'giay' => $giay,
			'chu' => 'im từ ' . self::truoc_day( $giay ) );
	}

	/** "12 giây trước" / "5 phút trước" / "3 giờ trước" / "2 ngày trước". */
	public static function truoc_day( $giay ) {
		$giay = max( 0, (int) $giay );
		if ( $giay < 60 )    { return $giay . ' giây trước'; }
		if ( $giay < 3600 )  { return (int) floor( $giay / 60 ) . ' phút trước'; }
		if ( $giay < 86400 ) { return (int) floor( $giay / 3600 ) . ' giờ trước'; }
		return (int) floor( $giay / 86400 ) . ' ngày trước';
	}

	public static function con_song( $luc, $bay_gio = null ) {
		if ( '' === trim( (string) $luc ) ) { return false; }
		$t = strtotime( $luc );
		if ( ! $t ) { return false; }
		if ( null === $bay_gio ) { $bay_gio = current_time( 'timestamp' ); }
		return ( $bay_gio - $t ) <= self::HET_SONG;
	}

	/**
	 * MỆNH GIÁ khách bấm trên màn ghế. Khai ở WEB, không nạp cứng vào firmware.
	 *
	 * 🔴 Anh Thắng ngày 22/08/2026: *"có nhiều mệnh giá quét trên máy qr để chọn mà"*. Đúng —
	 *    ghế có bốn nút. Nhưng bản đầu bốn con số đó nằm CỨNG trong firmware, nên đổi giá là
	 *    phải mang USB đi 26 cửa hàng. Ghế lại không có OTA, nên đó là chuyến đi thật.
	 *
	 * ⚠️ `gia`/`phut` KHÔNG phải một mệnh giá — chúng là TỈ LỆ QUY ĐỔI. Ghế tính
	 *    `phút = tiền × phut / gia`, nên 10.000đ=6′ thì bấm 50.000đ ra 30 phút. Nhãn cũ ghi
	 *    "Giá một lượt" là sai, và làm người đọc tưởng ghế chỉ có một mệnh giá.
	 */
	const SO_O_MAN_GHE = 4;   // màn ghế 320×240 vẽ được đúng bốn ô

	/* Bảng giá anh Thắng dựng (ảnh 22/08/2026). Đúng tỉ lệ 50.000đ = 15 phút cho cả bốn gói. */
	const MENH_GIA_MAC_DINH = array(
		array( 'tien' => 50000,  'ten' => 'Gói cơ bản',      'phut' => 0, 'mo_ta' => 'Khởi động & thư giãn nhẹ', 'vip' => 0 ),
		array( 'tien' => 100000, 'ten' => 'Gói phổ biến',    'phut' => 0, 'mo_ta' => 'Sâu & phục hồi',           'vip' => 0 ),
		array( 'tien' => 150000, 'ten' => 'Gói chuyên sâu',  'phut' => 0, 'mo_ta' => 'Trị liệu & giảm đau',      'vip' => 0 ),
		array( 'tien' => 200000, 'ten' => 'Gói thượng hạng', 'phut' => 0, 'mo_ta' => 'Đẳng cấp & quà tặng',      'vip' => 1 ),
	);

	/**
	 * Bốn gói trên màn ghế: [ ['tien','ten','phut'], … ]
	 *
	 * `phut = 0` nghĩa là TÍNH THEO TỈ LỆ QUY ĐỔI của ghế. Để 0 là cách đúng trong hầu hết
	 * trường hợp: đổi tỉ lệ một lần thì cả bốn gói theo, không phải sửa bốn ô rồi lệch một ô.
	 * Chỉ khai số phút cụ thể khi gói đó CỐ Ý không theo tỉ lệ (gói khuyến mãi, gói kèm quà).
	 */
	public static function menh_gia() {
		$ds = get_option( 'vhg_menh_gia' );
		if ( ! is_array( $ds ) ) { return self::MENH_GIA_MAC_DINH; }
		$ra   = array();
		$thay = array();
		foreach ( $ds as $v ) {
			/* Bản 1.3.0 lưu một mảng SỐ trơn. Đọc được cả hai dạng — nếu không thì nâng cấp
			   plugin là bốn gói đang chạy biến mất và ghế về bộ mặc định, âm thầm. */
			$hang = is_array( $v ) ? $v : array( 'tien' => $v, 'ten' => '', 'phut' => 0 );
			$tien = (int) ( isset( $hang['tien'] ) ? $hang['tien'] : 0 );
			if ( $tien < 1000 || isset( $thay[ $tien ] ) ) { continue; }
			$thay[ $tien ] = 1;
			$ra[] = array(
				'tien'  => $tien,
				'ten'   => trim( (string) ( isset( $hang['ten'] ) ? $hang['ten'] : '' ) ),
				'phut'  => max( 0, (int) ( isset( $hang['phut'] ) ? $hang['phut'] : 0 ) ),
				'mo_ta' => trim( (string) ( isset( $hang['mo_ta'] ) ? $hang['mo_ta'] : '' ) ),
				'vip'   => empty( $hang['vip'] ) ? 0 : 1,
			);
		}
		usort( $ra, function ( $a, $b ) { return $a['tien'] - $b['tien']; } );
		/* Rỗng thì về mặc định, KHÔNG để rỗng: ghế không còn nút nào để bấm, tức là đường QR
		   chết hẳn ở 26 cửa hàng mà máy chủ vẫn báo mọi thứ bình thường. */
		if ( ! $ra ) { return self::MENH_GIA_MAC_DINH; }
		/* Màn ghế chỉ có BỐN ô. Nhiều hơn là những ô sau không vẽ ra được — cắt ở đây để cái
		   người ta thấy trên web đúng bằng cái ghế hiện. */
		return array_slice( $ra, 0, self::SO_O_MAN_GHE );
	}

	/** Số phút thực của một gói với một ghế: khai cứng nếu có, không thì theo tỉ lệ quy đổi. */
	public static function phut_goi( $goi, $gia_quy_doi, $phut_quy_doi ) {
		$goi = (array) $goi;
		if ( ! empty( $goi['phut'] ) ) { return (int) $goi['phut']; }
		$gia = (int) $gia_quy_doi;
		if ( $gia <= 0 ) { return 0; }
		return (int) floor( (int) $goi['tien'] * (int) $phut_quy_doi / $gia );
	}

	/* ============================================================================================
	 * 🔴 CHỮ DÀI QUÁ Ô THÌ TRÀN RA NGOÀI, VÀ PHẦN TRÀN KHÔNG AI XOÁ ĐƯỢC.
	 *
	 * Ô gói trên màn ghế rộng 150px, font 1 ăn 6px mỗi ký tự -> vừa đúng 25 ký tự. Cắt ở 24 để
	 * chừa mép. Trước đây cắt ở 30 (tên) và 40 (mô tả) — tức là cho phép chuỗi 180px và 240px
	 * nằm trong ô 150px.
	 *
	 * Vì sao tràn lại KHÔNG TỰ HẾT: ô luân phiên vẽ lại bằng cách tô đúng hình chữ nhật 150×84
	 * của nó. Phần chữ đã vẽ RA NGOÀI hình đó thì nét tô không chạm tới, nên nó nằm lại trên màn
	 * cho tới lần vẽ toàn màn kế tiếp. Anh Thắng chụp được đúng kiểu này 23/08/2026: một dòng chữ
	 * của vế quảng cáo còn nằm đè lên dòng mô tả và dải chữ dưới cùng khi ô đã quay về mệnh giá.
	 *
	 * Chưa lộ ra chỉ vì tên đang gõ ngắn. Gõ một cái tên 30 ký tự là dính ngay.
	 * ============================================================================================ */
	const CHU_VUA_O = 24;

	public static function luu_menh_gia( $ds ) {
		$ra   = array();
		$thay = array();
		foreach ( (array) $ds as $v ) {
			$v    = (array) $v;
			$tien = (int) preg_replace( '/\D+/', '', (string) ( isset( $v['tien'] ) ? $v['tien'] : '' ) );
			if ( $tien < 1000 ) { continue; }
			if ( isset( $thay[ $tien ] ) ) {
				return array( 'ok' => false, 'error' => 'Hai gói cùng số tiền ' . number_format( $tien, 0, ',', '.' )
					. 'đ. Khách bấm hai nút giống hệt nhau thì không biết mình chọn gì.' );
			}
			$thay[ $tien ] = 1;
			$ra[] = array(
				'tien'  => $tien,
				'ten'   => mb_substr( trim( (string) ( isset( $v['ten'] ) ? $v['ten'] : '' ) ), 0, self::CHU_VUA_O ),
				'phut'  => max( 0, min( 240, (int) ( isset( $v['phut'] ) ? $v['phut'] : 0 ) ) ),
				'mo_ta' => mb_substr( trim( (string) ( isset( $v['mo_ta'] ) ? $v['mo_ta'] : '' ) ), 0, self::CHU_VUA_O ),
				'vip'   => empty( $v['vip'] ) ? 0 : 1,
			);
		}
		usort( $ra, function ( $a, $b ) { return $a['tien'] - $b['tien']; } );
		if ( ! $ra ) { return array( 'ok' => false, 'error' => 'Phải có ít nhất một gói từ 1.000đ.' ); }
		if ( count( $ra ) > self::SO_O_MAN_GHE ) {
			return array( 'ok' => false, 'error' => 'Màn ghế chỉ có ' . self::SO_O_MAN_GHE
				. ' ô — khai tối đa ' . self::SO_O_MAN_GHE . ' gói.' );
		}
		update_option( 'vhg_menh_gia', $ra );
		return array( 'ok' => true, 'thong_bao' => 'Đã lưu ' . count( $ra ) . ' gói. '
			. 'Ghế lấy về ở lượt nhịp kế tiếp (~30 giây).' );
	}

	/**
	 * Bốn gói ở dạng ghế đọc được: khoá ngắn, và TÊN ĐÃ BỎ DẤU.
	 *
	 * 🔴 Font của màn ghế (TFT_eSPI) KHÔNG vẽ được dấu tiếng Việt — "Gói phổ biến" hiện ra
	 *    thành một hàng ô vuông. Bỏ dấu ở MÁY CHỦ chứ không ở ghế: ghế không có OTA, nên mọi
	 *    thứ sửa được bằng máy chủ thì phải sửa ở máy chủ.
	 *
	 * ⚠️ Khoá một chữ (`t`,`n`,`p`) vì gói nhịp đi qua 4G và ghế giải mã trong bộ đệm cố định.
	 *    Tên khoá dài là tốn đúng chỗ mà một cái tên gói cần.
	 */
	public static function menh_gia_cho_ghe( $gia_quy_doi, $phut_quy_doi ) {
		$ra = array();
		foreach ( self::menh_gia() as $g ) {
			$ra[] = array(
				't' => (int) $g['tien'],
				'n' => self::bo_dau_hoa( $g['ten'], 16 ),
				'p' => self::phut_goi( $g, $gia_quy_doi, $phut_quy_doi ),
				/* Mô tả dài hơn tên: nó nằm trên một dòng riêng dưới đáy thẻ, font nhỏ nhất.
				   24 ký tự là bề ngang một thẻ 148px ở font 1. */
				'm' => self::bo_dau_hoa( $g['mo_ta'], 24 ),
				'v' => (int) $g['vip'],
			);
		}
		return $ra;
	}

	/** Bỏ dấu, viết hoa, cắt cho vừa bề ngang một ô trên màn ghế. */
	public static function bo_dau_hoa( $s, $dai = 18 ) {
		$s = mb_strtolower( trim( (string) $s ), 'UTF-8' );
		$cap = array(
			'a' => 'áàảãạăắằẳẵặâấầẩẫậ', 'e' => 'éèẻẽẹêếềểễệ', 'i' => 'íìỉĩị',
			'o' => 'óòỏõọôốồổỗộơớờởỡợ', 'u' => 'úùủũụưứừửữự', 'y' => 'ýỳỷỹỵ', 'd' => 'đ',
		);
		foreach ( $cap as $tron => $co ) {
			$s = str_replace( preg_split( '//u', $co, -1, PREG_SPLIT_NO_EMPTY ), $tron, $s );
		}
		/* Còn ký tự ngoài ASCII nghĩa là bảng trên thiếu chữ đó — BỎ ĐI chứ đừng gửi xuống ghế,
		   vì màn sẽ vẽ ra ô vuông và người ta tưởng ghế hỏng. */
		$s = preg_replace( '/[^\x20-\x7E]/', '', $s );
		$s = trim( preg_replace( '/\s+/', ' ', $s ) );
		return mb_strtoupper( mb_substr( $s, 0, max( 1, (int) $dai ) ), 'UTF-8' );
	}

	/**
	 * TÀI KHOẢN NHẬN TIỀN — khai MỘT LẦN cho cả hệ thống, từng ghế chỉ khai khi cần khác.
	 *
	 * 🔴 Anh Thắng: *"liên kết qua sepay và vietqr mà liên quan gì đến số tk"*. Số tài khoản vẫn
	 *    cần — mã QR phải nói tiền đi về đâu, SePay chỉ BÁO TIN tiền đã về. Nhưng bắt khai lại
	 *    cho từng ghế là thiết kế sai: 26 ghế là 26 lần gõ lại cùng một con số, và đổi tài khoản
	 *    là phải sửa đúng 26 chỗ — sót một chỗ thì tiền của ghế đó chảy về tài khoản cũ, âm thầm.
	 *
	 * Ô của từng ghế giữ lại làm NGOẠI LỆ (ghế đặt ở điểm có tài khoản riêng). Rỗng = dùng chung.
	 */
	public static function nhan_tien_chung() {
		return array(
			'bin'    => trim( (string) get_option( 'vhg_bin', '' ) ),
			'so_tk'  => trim( (string) get_option( 'vhg_so_tk', '' ) ),
			'ten_tk' => trim( (string) get_option( 'vhg_ten_tk', '' ) ),
		);
	}

	/**
	 * TỈ LỆ QUY ĐỔI CHUNG — bao nhiêu tiền ra bao nhiêu phút.
	 *
	 * 🔴 Anh Thắng 22/08/2026: *"không điều chỉnh được loại mệnh giá à"*. Bốn gói thì khai được,
	 *    nhưng SỐ PHÚT của chúng lại do tỉ lệ quyết định — mà tỉ lệ nằm tận ô "Thêm / sửa máy",
	 *    tách khỏi chỗ khai gói và phải lưu lại từng máy một. Nên nhìn bảng gói thì tưởng đã
	 *    khai xong, mà số phút vẫn là số cũ.
	 *
	 *    Tệ hơn: bảng xem trước lúc đó gọi cứng `menh_gia_cho_ghe(10000, 6)` — nó in ra một
	 *    bảng số phút KHÔNG phải số ghế sẽ chạy. Một bảng "xem trước" nói sai còn hại hơn không
	 *    có bảng nào, vì người ta tin nó rồi thôi không đi kiểm.
	 *
	 * Nên tỉ lệ đi cùng đường với tài khoản nhận tiền: khai MỘT LẦN, ghế nào cần khác mới khai
	 * riêng. `gia`/`phut` của máy bằng 0 = dùng chung.
	 */
	const GIA_MAC_DINH  = 50000;
	const PHUT_MAC_DINH = 15;

	public static function ty_le_chung() {
		$gia  = (int) get_option( 'vhg_gia', 0 );
		$phut = (int) get_option( 'vhg_phut', 0 );
		return array(
			'gia'  => $gia > 0 ? $gia : self::GIA_MAC_DINH,
			'phut' => $phut > 0 ? $phut : self::PHUT_MAC_DINH,
		);
	}

	/** Tỉ lệ THỰC DÙNG của một ghế: ô riêng nếu có (>0), không thì ô chung. */
	public static function ty_le_cua( $m ) {
		$c = self::ty_le_chung();
		$m = (array) $m;
		$gia  = isset( $m['gia'] ) ? (int) $m['gia'] : 0;
		$phut = isset( $m['phut'] ) ? (int) $m['phut'] : 0;
		return array(
			'gia'  => $gia > 0 ? $gia : $c['gia'],
			'phut' => $phut > 0 ? $phut : $c['phut'],
		);
	}

	public static function luu_ty_le( $gia, $phut ) {
		$gia  = (int) preg_replace( '/\D+/', '', (string) $gia );
		$phut = (int) preg_replace( '/\D+/', '', (string) $phut );
		if ( $gia < 1000 )              { return array( 'ok' => false, 'error' => 'Số tiền quy đổi phải từ 1.000đ.' ); }
		if ( $phut < 1 || $phut > 240 ) { return array( 'ok' => false, 'error' => 'Số phút quy đổi phải từ 1 đến 240.' ); }
		update_option( 'vhg_gia', $gia );
		update_option( 'vhg_phut', $phut );
		return array( 'ok' => true, 'thong_bao' => 'Đã lưu tỉ lệ ' . number_format( $gia, 0, ',', '.' )
			. 'đ = ' . $phut . ' phút. Ghế lấy về ở lượt nhịp kế tiếp (~30 giây).' );
	}

	/**
	 * Bỏ hết tỉ lệ khai riêng của từng ghế, cho tất cả dùng chung.
	 * Có nút này vì những ghế khai từ bản cũ đều mang tỉ lệ riêng (bản cũ không có ô chung), nên
	 * đổi ô chung mà chúng không theo — và không có gì trên màn nói vì sao.
	 */
	public static function bo_ty_le_rieng() {
		global $wpdb;
		$n = (int) $wpdb->query( 'UPDATE ' . VHG_DB::t( 'may' ) . ' SET gia=0, phut=0 WHERE gia>0 OR phut>0' );
		return array( 'ok' => true, 'thong_bao' => $n
			? 'Đã cho ' . $n . ' ghế dùng tỉ lệ chung.'
			: 'Tất cả ghế vốn đã dùng tỉ lệ chung.' );
	}

	/** Tài khoản THỰC DÙNG của một ghế: ô riêng nếu có, không thì ô chung. */
	public static function nhan_tien_cua( $m ) {
		$c = self::nhan_tien_chung();
		$m = (array) $m;
		/* Bản đồ ô-của-ghế -> ô-chung. Tên cột khác tên khoá (`bank_bin` vs `bin`), nên viết ra
		   một chỗ chứ đừng lặp ba lần — lặp là chỗ thứ ba gõ nhầm và ghế đó âm thầm dùng tài
		   khoản rỗng. */
		$ra = array();
		foreach ( array( 'bin' => 'bank_bin', 'so_tk' => 'so_tk', 'ten_tk' => 'ten_tk' ) as $khoa => $cot ) {
			$rieng   = isset( $m[ $cot ] ) ? trim( (string) $m[ $cot ] ) : '';
			$ra[ $khoa ] = '' !== $rieng ? $rieng : $c[ $khoa ];
		}
		return $ra;
	}

	/**
	 * Nhớ số tài khoản mà BÊN GỬI báo là đã nhận tiền.
	 *
	 * 🔴 VÌ SAO CẦN. Ngày 22/08/2026 anh Thắng quét thử mã QR bằng app BIDV và bị chối: *"Định
	 *    dạng tài khoản định danh không hợp lệ (174)"*. Nguyên nhân: ô số tài khoản khai tay
	 *    thiếu MỘT chữ số — `888815678` thay vì `8888815678`.
	 *
	 *    Một chữ số. Không có gì trên màn hình sai cả: mã QR vẫn dựng ra, vẫn trông như thật,
	 *    vẫn dán được lên 26 cái ghế. Chỉ tới lúc có khách đứng quét mới lộ — và lúc đó thì đã
	 *    mất một buổi bán hàng ở 26 cửa hàng.
	 *
	 *    Không có cách nào kiểm số tài khoản bằng luật chữ số: mỗi ngân hàng một khuôn, BIDV còn
	 *    có mấy loại tài khoản định danh dài ngắn khác nhau. NHƯNG mình có một sự thật đối chứng
	 *    miễn phí: mỗi lượt webhook, SePay nói rõ tiền vừa vào TÀI KHOẢN NÀO. Nếu số đó khác số
	 *    đang khai thì một trong hai sai — và đó là câu duy nhất đáng nói ra.
	 */
	public static function nho_tk_ben_gui( $so_tk, $tk_ao = '' ) {
		$so_tk = trim( (string) $so_tk );
		if ( '' === $so_tk ) { return; }
		update_option( 'vhg_tk_ben_gui', array( 'so' => $so_tk,
			'va' => trim( (string) $tk_ao ), 'luc' => current_time( 'mysql' ) ) );
	}

	/**
	 * Số đang khai có khớp số bên gửi báo không.
	 * @return array [ 'co' => bool đã từng thấy, 'khop' => bool, 'ben_gui' => string, 'luc' => string ]
	 */
	public static function doi_chieu_tk() {
		$g = get_option( 'vhg_tk_ben_gui' );
		$ben_gui = is_array( $g ) && isset( $g['so'] ) ? trim( (string) $g['so'] ) : '';
		if ( '' === $ben_gui ) {
			return array( 'co' => false, 'khop' => true, 'ben_gui' => '', 'va' => '', 'luc' => '' );
		}
		$khai = self::nhan_tien_chung();
		/* So bằng CHỮ VÀ SỐ, không chỉ chữ số.
		 *
		 * 🔴 Bản trước bỏ hết chữ cái. Tài khoản ảo của SePay là chuỗi CÓ CHỮ (`96247POSH`), nên
		 *    khai VA vào đây là nó biến thành `96247` rồi so với `8888815678` — báo đỏ oan cho
		 *    đúng cấu hình chạy được. Chỉ bỏ dấu cách và gạch: bên gửi có khi trả
		 *    "888 881 5678", khác cách viết không phải khác tài khoản. */
		$a = strtoupper( preg_replace( '/[^0-9A-Za-z]/', '', (string) $khai['so_tk'] ) );
		$b = strtoupper( preg_replace( '/[^0-9A-Za-z]/', '', $ben_gui ) );
		$va = is_array( $g ) && isset( $g['va'] ) ? trim( (string) $g['va'] ) : '';
		/* Khớp NẾU trùng số tài khoản HOẶC trùng tài khoản ảo: mã QR trỏ vào cái nào cũng được,
		   miễn là cái SePay đang theo dõi. Chỉ đòi trùng đúng một ô là báo đỏ oan cho cấu hình
		   đang chạy tốt — và một cảnh báo oan là một cảnh báo bị bỏ qua mãi về sau. */
		$c = strtoupper( preg_replace( '/[^0-9A-Za-z]/', '', $va ) );
		$khop = ( '' !== $a && $a === $b ) || ( '' !== $c && $c === $a );
		return array( 'co' => true, 'khop' => $khop, 'ben_gui' => $ben_gui, 'va' => $va,
			'luc' => is_array( $g ) && isset( $g['luc'] ) ? (string) $g['luc'] : '' );
	}

	/**
	 * TIỀN TỐ BẮT BUỘC TRONG NỘI DUNG CHUYỂN KHOẢN.
	 *
	 * 🔴 MẮT XÍCH CUỐI CÙNG, tìm ra 22/08/2026 trên chính trang Tạo QR của SePay:
	 *
	 *      "SEVQR — VietinBank cá nhân/hộ kinh doanh BẮT BUỘC nội dung CK phải chứa `sevqr`
	 *       để định tuyến giao dịch qua SePay."
	 *
	 *    Không có chuỗi đó thì tiền vẫn vào tài khoản, ngân hàng vẫn báo thành công, nhưng
	 *    SePay KHÔNG BAO GIỜ THẤY — nên không có webhook, và ghế không chạy. Đúng cái đã xảy
	 *    ra: lượt 2.000đ quét từ trang SePay (có SEVQR) thì về, lượt 10.000đ quét chỗ khác
	 *    (không có SEVQR) thì biến mất không dấu vết.
	 *
	 *    Đây là kiểu hỏng tệ nhất trong cả hệ thống: KHÔNG AI BÁO GÌ CẢ. Khách trả tiền xong,
	 *    ngân hàng nói "thành công", ghế đứng im, và trong sổ của mình không có một dòng nào —
	 *    kể cả dòng "có gói lạ bắn tới". Không có gì để đi tìm.
	 *
	 * ⚠️ Tiền tố tuỳ NGÂN HÀNG và tuỳ LOẠI tài khoản, nên KHÔNG gán cứng "SEVQR" trong mã:
	 *    tài khoản doanh nghiệp, hay ngân hàng khác, có thể không cần — mà thừa một chuỗi lạ
	 *    trong nội dung là tốn chỗ của mã lượt (VietQR chỉ cho 25 ký tự).
	 */
	public static function tien_to_nd() {
		return trim( (string) get_option( 'vhg_tien_to_nd', '' ) );
	}

	public static function luu_tien_to_nd( $v ) {
		/* Chỉ chữ và số: nội dung chuyển khoản đi qua nhiều hệ thống, dấu và ký tự lạ là chỗ
		   bị cắt hoặc bị đổi mà không ai báo. */
		$v = strtoupper( preg_replace( '/[^0-9A-Za-z]/', '', (string) $v ) );
		if ( strlen( $v ) > 10 ) {
			return array( 'ok' => false, 'error' => 'Tiền tố tối đa 10 ký tự — nội dung chuyển khoản '
				. 'chỉ có 25 chỗ, để dành cho mã ghế và mã lượt.' );
		}
		update_option( 'vhg_tien_to_nd', $v );
		return array( 'ok' => true, 'thong_bao' => '' === $v
			? 'Đã bỏ tiền tố nội dung chuyển khoản.'
			: 'Đã đặt tiền tố "' . $v . '". Ghế lấy về ở lượt nhịp kế tiếp (~30 giây).' );
	}

	public static function luu_nhan_tien( $bin, $so_tk, $ten_tk ) {
		$bin   = preg_replace( '/\D+/', '', (string) $bin );
		$so_tk = trim( (string) $so_tk );
		if ( '' !== $bin && ! preg_match( '/^\d{6}$/', $bin ) ) {
			return array( 'ok' => false, 'error' => 'Mã ngân hàng (BIN) phải đúng 6 chữ số. VD 970418 = BIDV.' );
		}
		update_option( 'vhg_bin', $bin );
		update_option( 'vhg_so_tk', $so_tk );
		update_option( 'vhg_ten_tk', trim( (string) $ten_tk ) );
		return array( 'ok' => true, 'thong_bao' => 'Đã lưu tài khoản nhận tiền chung. '
			. 'Ghế lấy về ở lượt nhịp kế tiếp (~30 giây), không phải nạp lại firmware.' );
	}

	/**
	 * GÁN MÃ THẬT cho một ghế đã tự hiện ra (mã còn bắt đầu bằng '?').
	 *
	 * 🔴 Đổi mã KHÔNG chỉ là đổi một ô. `ma` là khoá mà doanh thu, hàng chờ, nhịp và lệnh đều
	 *    trỏ tới. Đổi mỗi bảng `may` thì lịch sử của ghế đó mồ côi: lượt khách ĐÃ TRẢ TIỀN mà
	 *    ghế chưa nhận sẽ nằm lại dưới mã cũ, ghế hỏi bằng mã mới nên không bao giờ thấy —
	 *    khách trả tiền xong ghế không chạy, và không có gì trên màn hình nói vì sao.
	 *    Nên dời TẤT CẢ trong cùng một lượt.
	 */
	public static function gan_ma( $ma_cu, $ma_moi, $coso_id = null ) {
		global $wpdb;
		$ma_cu  = trim( (string) $ma_cu );
		$ma_moi = trim( (string) $ma_moi );
		if ( '' === $ma_cu || '' === $ma_moi ) { return array( 'ok' => false, 'error' => 'Thiếu mã.' ); }
		if ( ! preg_match( '/^[A-Za-z0-9]{1,20}$/', $ma_moi ) ) {
			return array( 'ok' => false, 'error' => 'Mã mới chỉ được gồm chữ và số, không dấu, không '
				. 'khoảng trắng. Mã này đi vào nội dung chuyển khoản khách gõ tay.' );
		}
		if ( $ma_cu === $ma_moi ) { return array( 'ok' => true, 'thong_bao' => 'Mã không đổi.' ); }
		$bang = VHG_DB::t( 'may' );
		if ( ! $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $bang WHERE ma=%s LIMIT 1", $ma_cu ) ) ) {
			return array( 'ok' => false, 'error' => 'Không thấy ghế ' . $ma_cu . '.' );
		}
		if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $bang WHERE ma=%s LIMIT 1", $ma_moi ) ) ) {
			return array( 'ok' => false, 'error' => 'Mã ' . $ma_moi . ' đã có ghế khác dùng. '
				. 'Hai ghế cùng mã là tiền của ghế này chạy ghế kia.' );
		}
		$dat = array( 'ma' => $ma_moi, 'cap_nhat' => current_time( 'mysql' ) );
		/* Gán cơ sở CÙNG LÚC với gán mã. Người đi lắp ghế biết nó đang ở đâu ngay lúc đó; bắt
		   quay lại một màn khác để chọn cơ sở là bước dễ quên nhất, mà quên thì doanh thu ghế
		   đó rơi vào ô "(chưa gán)" và bảng theo cơ sở sai âm thầm. */
		if ( null !== $coso_id ) { $dat['coso_id'] = (int) $coso_id; }
		$wpdb->update( $bang, $dat, array( 'ma' => $ma_cu ) );
		/* Dời hết những gì trỏ tới mã cũ. `thu` để CUỐI: nó là sổ tiền, và nếu có gì hỏng giữa
		   chừng thì thà sổ tiền còn nguyên mã cũ (đối soát tay được) hơn là hàng chờ mồ côi.
		   🔴 09/09/2026 — THÊM `bc_dong` + `chot`: đây là 2 bảng `chi_so_truoc()` đọc để tra chỉ số
		      kỳ trước THEO ma_may. Trước đây đổi mã không dời chúng -> mất lịch sử chỉ số -> chỉ số
		      kỳ sau tính từ 0, nhảy vọt (anh Thắng: "tạo lại máy chỉ số nhảy sai"). Mã mới chắc chắn
		      chưa có ghế khác (đã chặn ở trên) nên không lo đụng khoá. */
		/* 🔴 12/09/2026 — DỜI ĐỦ MỌI BẢNG CÓ `ma_may`, không chỉ 6 bảng cũ. Trước đây thiếu
		   `chot_tien, bat_tat, nhat_ky, vi_so, bc_denghi, bc_rac` (và `ma.dung_may` tên cột khác):
		   đổi mã xong mấy bảng ấy còn trỏ mã CŨ → lịch sử/đề nghị/thùng rác/ví mồ côi, tra theo mã
		   mới không thấy. Mã mới đã chắc chắn chưa ai dùng (chặn ở trên) nên không đụng khoá UNIQUE. */
		$dem = 0;
		foreach ( array( 'cho', 'nhip', 'lenh', 'chot', 'bc_dong', 'chot_tien', 'bat_tat',
				'nhat_ky', 'vi_so', 'bc_denghi', 'bc_rac', 'thu' ) as $b ) {
			$dem += (int) $wpdb->query( $wpdb->prepare(
				'UPDATE ' . VHG_DB::t( $b ) . ' SET ma_may=%s WHERE ma_may=%s', $ma_moi, $ma_cu ) );
		}
		/* Bảng mã trả trước dùng cột `dung_may` (ghế đã tiêu mã), không phải `ma_may`. */
		$dem += (int) $wpdb->query( $wpdb->prepare(
			'UPDATE ' . VHG_DB::t( 'ma' ) . ' SET dung_may=%s WHERE dung_may=%s', $ma_moi, $ma_cu ) );
		return array( 'ok' => true, 'thong_bao' => 'Đã gán mã ' . $ma_moi . ' cho ghế ' . $ma_cu
			. ' và dời ' . $dem . ' dòng lịch sử sang mã mới.' );
	}

	/**
	 * ĐỔI BOARD (MAC) cho một mã ghế ĐÃ CÓ — thay ESP32 mà GIỮ NGUYÊN chỉ số + lịch sử.
	 *
	 * Khi thay board hỏng: board mới lên mạng tạo một dòng CHỜ GÁN (ma '?<mac>'). Thay vì gán
	 * mã mới cho nó (mất chỉ số cũ), ta CHUYỂN mã cũ sang MAC mới:
	 *   · Dòng mã cũ (AMTP01) giữ nguyên id -> giữ moc_chiso + mọi lịch sử theo ma_may. Chỉ đổi `mac`.
	 *   · Dòng placeholder của board mới bị xoá (đã nhường MAC cho mã cũ).
	 *
	 * ⚠️ KHÔNG xoá dòng mã cũ (xoá là mất chỉ số — đúng điều anh Thắng dặn). Chỉ thay MAC.
	 */
	public static function doi_mac( $ma, $mac_moi ) {
		global $wpdb;
		$ma  = trim( (string) $ma );
		$mac = self::chuan_mac( (string) $mac_moi );
		$bang = VHG_DB::t( 'may' );
		if ( '' === $ma )  { return array( 'ok' => false, 'error' => 'Thiếu mã ghế.' ); }
		if ( '' === $mac ) { return array( 'ok' => false, 'error' => 'MAC mới không đúng khuôn (12 ký tự 0-9/A-F).' ); }

		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, mac FROM $bang WHERE ma=%s LIMIT 1", $ma ), ARRAY_A );
		if ( ! $row ) { return array( 'ok' => false, 'error' => 'Không thấy ghế ' . $ma . '.' ); }

		/* MAC mới đang thuộc dòng nào? */
		$chu = $wpdb->get_row( $wpdb->prepare( "SELECT id, ma FROM $bang WHERE mac=%s LIMIT 1", $mac ), ARRAY_A );
		if ( $chu && (int) $chu['id'] !== (int) $row['id'] ) {
			if ( 0 === strpos( (string) $chu['ma'], '?' ) ) {
				/* Board mới đang nằm chờ gán -> xoá dòng tạm để nhường MAC cho mã cũ. */
				$wpdb->delete( $bang, array( 'id' => (int) $chu['id'] ) );
			} else {
				return array( 'ok' => false, 'error' => 'MAC này đang là ghế ' . $chu['ma']
					. ' — không thể gán cho hai ghế. Gỡ ghế đó trước nếu thật sự muốn chuyển.' );
			}
		}

		$wpdb->update( $bang, array( 'mac' => $mac, 'cap_nhat' => current_time( 'mysql' ) ), array( 'ma' => $ma ) );
		return array( 'ok' => true, 'thong_bao' => 'Đã chuyển ghế ' . $ma . ' sang board mới (MAC ' . $mac
			. '). Giữ nguyên chỉ số + lịch sử.' );
	}

	public static function luu_may( $d ) {
		global $wpdb;
		$ma = trim( (string) ( isset( $d['ma'] ) ? $d['ma'] : '' ) );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu mã máy.' ); }
		/* Mã máy đi vào nội dung chuyển khoản mà khách gõ tay ("GHE3 T1ABC"). Dấu và khoảng
		   trắng ở đó là khách gõ sai, gõ sai là tiền vào mà ghế không chạy. Chặn ngay lúc khai. */
		if ( ! preg_match( '/^[A-Za-z0-9]{1,20}$/', $ma ) ) {
			return array( 'ok' => false, 'error' => 'Mã máy chỉ được gồm chữ và số, không dấu, không '
				. 'khoảng trắng (tối đa 20 ký tự). Mã này đi vào nội dung chuyển khoản khách gõ tay — '
				. 'có dấu là khách gõ sai và ghế không chạy.' );
		}
		$mac_go = trim( (string) ( isset( $d['mac'] ) ? $d['mac'] : '' ) );
		if ( '' !== $mac_go && '' === self::chuan_mac( $mac_go ) ) {
			/* Im lặng bỏ qua một MAC gõ sai là tệ nhất: người ta tưởng đã gắn ghế, còn ghế thật
			   thì vẫn hiện ra như một ghế mới ở danh sách chờ. */
			return array( 'ok' => false, 'error' => 'Địa chỉ MAC không đúng khuôn — phải là 12 ký tự '
				. '0-9/A-F, ví dụ AA:BB:CC:DD:EE:FF. Đang nhận: "' . esc_html( $mac_go ) . '".' );
		}
		$hang = array(
			'ma'       => $ma,
			'mac'      => self::chuan_mac( isset( $d['mac'] ) ? $d['mac'] : '' ),
			'coso_id'  => (int) ( isset( $d['coso_id'] ) ? $d['coso_id'] : 0 ),
			/* 0 = DÙNG CHUNG (xem ty_le_cua). Không ép về mặc định nữa: ép là mọi ghế thành
			   "khai riêng" và ô chung mất tác dụng ngay lúc khai máy đầu tiên. */
			'gia'      => max( 0, (int) ( isset( $d['gia'] ) ? $d['gia'] : 0 ) ),
			'phut'     => max( 0, (int) ( isset( $d['phut'] ) ? $d['phut'] : 0 ) ),
			'so_tk'    => trim( (string) ( isset( $d['so_tk'] ) ? $d['so_tk'] : '' ) ),
			'ten_tk'   => trim( (string) ( isset( $d['ten_tk'] ) ? $d['ten_tk'] : '' ) ),
			'bank_bin' => trim( (string) ( isset( $d['bank_bin'] ) ? $d['bank_bin'] : '' ) ),
			'ten_khai' => VHG_Doc::chuan_ten( isset( $d['ten_khai'] ) ? $d['ten_khai'] : '' ),
			'cap_nhat' => current_time( 'mysql' ),
		);
		$bang = VHG_DB::t( 'may' );
		/* MAC rỗng thì đừng ghi đè MAC đang có — người sửa giá không nên vô tình cắt đứt liên
		   kết giữa ghế thật và dòng cấu hình của nó. */
		if ( '' === $hang['mac'] ) { unset( $hang['mac'] ); }
		$co = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $bang WHERE ma=%s LIMIT 1", $ma ) );
		/* Gán mã thật cho một ghế đang chờ: tìm theo MAC rồi ĐỔI mã của chính dòng đó, chứ không
		   tạo dòng mới — tạo mới là ghế cũ nằm lại mãi trong danh sách chờ gán. */
		if ( ! $co && isset( $hang['mac'] ) ) {
			$cu_mac = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $bang WHERE mac=%s LIMIT 1", $hang['mac'] ) );
			if ( $cu_mac ) { $co = $cu_mac; }
		}
		/* 🔴 CƠ SỞ RỖNG (0) KHI SỬA MÁY ĐÃ CÓ = ĐỪNG GHI ĐÈ — cùng một lẽ với MAC ở trên, và là gốc
		   của lỗi "tự nhiên mất máy Bạc Liêu" (anh Thắng). Form "Thêm/sửa máy" bên wp-admin là form
		   TRẮNG: gõ lại đúng mã cũ = sửa máy đó, nhưng ô Cơ sở luôn mặc định "— chưa gán —". Ai mở
		   form để sửa giá/số tài khoản mà không chọn lại cơ sở thì coso_id bị đặt về 0 → ghế thành
		   "chưa gán" → rơi khỏi phạm vi PIN (trong_pham_vi) và biến mất khỏi màn nhập của nhân viên
		   lẫn nhóm cơ sở trong bảng. Đổi cơ sở CÓ CHỦ Ý đi qua đường riêng (dat_coso/dat_coso_lo);
		   ở đây 0 nghĩa là "không đụng tới", giữ nguyên cơ sở đang có. Máy MỚI (insert) vẫn cho 0. */
		if ( $co && 0 === (int) $hang['coso_id'] ) { unset( $hang['coso_id'] ); }
		if ( $co ) { $wpdb->update( $bang, $hang, array( 'id' => (int) $co ) ); }
		else { $wpdb->insert( $bang, $hang ); }
		return array( 'ok' => true, 'thong_bao' => 'Đã lưu máy ' . $ma . '.' );
	}

	/**
	 * THÊM GHẾ MỚI — CHẶN TRÙNG MÃ. Anh Thắng 11/09/2026: *"nếu trùng mã thì không cho tạo"*.
	 *
	 * 🔴 KHÁC luu_may(): luu_may coi "gõ lại đúng mã cũ = SỬA máy đó" (dùng cho form cấu hình
	 *    giá/tài khoản). Nhưng nút "Thêm ghế vào <cơ sở>" bên trang quản lý là THÊM MỚI — nếu nó
	 *    cũng đi qua luu_may thì gõ nhầm một mã đã có (VD ghế VHM 80134) sẽ ÂM THẦM kéo ghế đó sang
	 *    cơ sở đang mở và xoá trắng tên/cấu hình của nó (payload thêm ghế không có ten_khai). Đúng
	 *    vụ "tự nhiên bên Bạc Liêu mọc ra mấy ghế 'vd VHM' không tên" — thực ra là ghế VHM bị nhầm
	 *    mã, kéo qua, mất tên. Mỗi mã chỉ một ghế (UNIQUE KEY ma), nên thêm mà trùng = từ chối,
	 *    chỉ đường đi tìm ghế cũ thay vì tạo lại.
	 */
	public static function them_may( $ma, $coso_id, $ten_khai = '' ) {
		global $wpdb;
		$ma = trim( (string) $ma );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu mã ghế.' ); }
		if ( ! preg_match( '/^[A-Za-z0-9]{1,20}$/', $ma ) ) {
			return array( 'ok' => false, 'error' => 'Mã chỉ gồm chữ và số, không dấu, không khoảng trắng '
				. '(mã đi vào nội dung chuyển khoản khách gõ tay).' );
		}
		$bang = VHG_DB::t( 'may' );
		$cu = $wpdb->get_row( $wpdb->prepare(
			"SELECT m.an, c.ten AS coso_ten FROM $bang m LEFT JOIN " . VHG_DB::t( 'coso' )
			. ' c ON c.id = m.coso_id WHERE m.ma=%s LIMIT 1', $ma ), ARRAY_A );
		if ( $cu ) {
			$noi = trim( (string) $cu['coso_ten'] );
			$noi = ( '' !== $noi ) ? ( 'cơ sở "' . $noi . '"' ) : 'trạng thái chưa gán cơ sở';
			$an  = ! empty( $cu['an'] ) ? ' (đang ẩn — đã điều chuyển)' : '';
			return array( 'ok' => false, 'trung' => 1,
				'error' => 'Mã ' . $ma . ' ĐÃ CÓ ghế ở ' . $noi . $an . '. Mỗi mã chỉ MỘT ghế nên không '
					. 'tạo trùng được. Nếu muốn chuyển ghế đó về đây: tìm nó ở ô "Tìm ghế" (gõ mã), rồi '
					. 'đổi Địa điểm (hoặc bấm "Đưa về" nếu đang ẩn) — đừng tạo lại mã.' );
		}
		$ten_khai = VHG_Doc::chuan_ten( (string) $ten_khai );   // tên ghế (tuỳ chọn) — anh Thắng 12/09/2026
		$wpdb->insert( $bang, array( 'ma' => $ma, 'coso_id' => (int) $coso_id,
			'ten_khai' => $ten_khai, 'cap_nhat' => current_time( 'mysql' ) ) );
		return array( 'ok' => true, 'thong_bao' => 'Đã thêm ghế ' . $ma
			. ( '' !== $ten_khai ? ( ' (' . $ten_khai . ')' ) : '' ) . '.' );
	}

	/**
	 * NHÂN BẢN GHẾ SANG MÃ MỚI — GIỮ CHỈ SỐ (không nhảy về 0). Anh Thắng 12/09/2026: *"2 cơ sở chung
	 * 1 mã, chuyển mã này thì mất mã kia… nhập mã mới nó tự nhân bản ra để giữ lại chỉ số, chứ xoá
	 * tạo nó nhảy chỉ số hết"*.
	 *
	 * Cách gỡ trùng mã AN TOÀN: giữ NGUYÊN ghế/mã cũ (cho cơ sở kia), tạo GHẾ MỚI với mã khác cho cơ
	 * sở này, và ĐẶT MỐC CHỈ SỐ (`moc_chiso`) của ghế mới = chỉ số MỚI NHẤT của ghế nguồn. Nhờ mốc
	 * này, báo cáo đầu tiên của mã mới nối tiếp đúng số máy đang chạy thay vì bắt đầu từ 0
	 * (xem chi_so_truoc_ct_: không có bc_dong/chot thì lấy moc_chiso).
	 *
	 * ⚠️ KHÔNG chép MAC (một MAC = một thiết bị thật; nhân đôi MAC là hai ghế tranh nhau một máy).
	 * ⚠️ KHÔNG đụng lịch sử cũ: doanh thu/chỉ số cũ vẫn nằm dưới mã nguồn — mã mới bắt đầu SẠCH từ
	 *    mốc, nên không kéo nhầm tiền của ai. Đây chính là chỗ khác "xoá tạo": xoá tạo mất mốc → về 0.
	 */
	public static function nhan_ban( $ma_nguon, $ma_moi, $coso_id = 0, $ten = '' ) {
		global $wpdb;
		$ma_nguon = trim( (string) $ma_nguon );
		$ma_moi   = trim( (string) $ma_moi );
		if ( '' === $ma_nguon || '' === $ma_moi ) { return array( 'ok' => false, 'error' => 'Thiếu mã ghế nguồn hoặc mã mới.' ); }
		if ( $ma_moi === $ma_nguon ) { return array( 'ok' => false, 'error' => 'Mã mới phải KHÁC mã nguồn.' ); }
		if ( ! preg_match( '/^[A-Za-z0-9]{1,20}$/', $ma_moi ) ) {
			return array( 'ok' => false, 'error' => 'Mã mới chỉ gồm chữ và số, không dấu, không khoảng trắng.' );
		}
		$bang  = VHG_DB::t( 'may' );
		$nguon = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $bang WHERE ma=%s LIMIT 1", $ma_nguon ), ARRAY_A );
		if ( ! $nguon ) { return array( 'ok' => false, 'error' => 'Không tìm thấy ghế nguồn ' . $ma_nguon . '.' ); }
		if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $bang WHERE ma=%s LIMIT 1", $ma_moi ) ) ) {
			return array( 'ok' => false, 'trung' => 1, 'error' => 'Mã ' . $ma_moi . ' ĐÃ CÓ ghế — chọn mã khác.' );
		}
		$coso_id = (int) $coso_id;
		if ( $coso_id <= 0 ) { $coso_id = (int) $nguon['coso_id']; }
		if ( $coso_id <= 0 ) { return array( 'ok' => false, 'error' => 'Chưa chọn cơ sở đích cho mã mới.' ); }
		/* Chỉ số MỚI NHẤT của ghế nguồn (đọc cả lượt thu trong hôm nay: $toi=true, mốc = ngày mai). */
		$moc = null;
		if ( class_exists( 'VHG_BaoCao' ) ) {
			$mai = gmdate( 'Y-m-d', current_time( 'timestamp' ) + 86400 );
			$moc = VHG_BaoCao::chi_so_truoc( $ma_nguon, $mai, true );
		}
		$ten  = VHG_Doc::chuan_ten( '' !== (string) $ten ? $ten : (string) ( isset( $nguon['ten_khai'] ) ? $nguon['ten_khai'] : '' ) );
		$hang = array(
			'ma'       => $ma_moi,
			'coso_id'  => $coso_id,
			'ten_khai' => $ten,
			'gia'      => (int) ( isset( $nguon['gia'] ) ? $nguon['gia'] : 0 ),
			'phut'     => (int) ( isset( $nguon['phut'] ) ? $nguon['phut'] : 0 ),
			'so_tk'    => (string) ( isset( $nguon['so_tk'] ) ? $nguon['so_tk'] : '' ),
			'ten_tk'   => (string) ( isset( $nguon['ten_tk'] ) ? $nguon['ten_tk'] : '' ),
			'bank_bin' => (string) ( isset( $nguon['bank_bin'] ) ? $nguon['bank_bin'] : '' ),
			'cap_nhat' => current_time( 'mysql' ),
		);
		if ( null !== $moc ) {
			$hang['moc_chiso']      = (int) $moc;
			$hang['moc_chiso_ngay'] = current_time( 'Y-m-d' );
		}
		$wpdb->insert( $bang, $hang );
		return array( 'ok' => true, 'thong_bao' => 'Đã nhân bản ghế ' . $ma_nguon . ' → mã mới ' . $ma_moi
			. ( null !== $moc
				? ( ' (giữ chỉ số ' . number_format( (int) $moc, 0, ',', '.' ) . ').' )
				: ' (ghế nguồn chưa có chỉ số nào để giữ).' )
			. ' Ghế/mã cũ giữ nguyên cho cơ sở kia.' );
	}

	/** Chuyển ghế sang cơ sở khác — CHỈ đổi coso_id, giữ nguyên giá/thời lượng/số tài khoản.
	 *  (gan_ma trả về sớm khi mã không đổi nên không dùng để đổi mỗi cơ sở được.) */
	/** Đặt/đổi TÊN ghế (ten_khai — tên trên sao kê). CHỈ đụng cột tên, không đụng giá/tài khoản
	 *  (khác luu_may vốn cần đủ mọi ô, để trống là xoá trắng cấu hình). */
	public static function dat_ten( $ma, $ten ) {
		global $wpdb;
		$ma = trim( (string) $ma );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu mã ghế.' ); }
		$ten = VHG_Doc::chuan_ten( (string) $ten );
		$wpdb->update( VHG_DB::t( 'may' ),
			array( 'ten_khai' => $ten, 'cap_nhat' => current_time( 'mysql' ) ),
			array( 'ma' => $ma ) );
		return array( 'ok' => true, 'thong_bao' => '' === $ten
			? ( 'Đã xoá tên ghế ' . $ma . '.' ) : ( 'Đã đặt tên ghế ' . $ma . ' = "' . $ten . '".' ) );
	}

	/**
	 * TÊN THƯỜNG GỌI — anh Thắng 14/09/2026: *"thêm tên thường gọi cho ghế để nhân viên dễ biết,
	 * nhiều khi lấy mã cố định thành tra tên không ra ràng"*.
	 *
	 * 🔴 ĐÂY LÀ CỘT RIÊNG, KHÔNG PHẢI `ten_khai`. `ten_khai` = "Tên trên sao kê", phải khớp nội
	 *    dung chuyển khoản để đối soát ngân hàng ghép tiền về đúng ghế. Đổi nó thành một cái tên
	 *    dễ đọc là mọi giao dịch của ghế đó thôi ghép được — âm thầm, và chỉ lộ ra lúc cuối tháng
	 *    thấy một đống tiền không biết của ghế nào.
	 * ⚠️ `ten_goi` KHÔNG được dùng làm khoá ghép ở bất kỳ đâu. Nó chỉ để hiện cho người đọc.
	 */
	public static function dat_ten_goi( $ma, $ten_goi ) {
		global $wpdb;
		$ma = trim( (string) $ma );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu mã ghế.' ); }
		$tg = mb_substr( trim( (string) $ten_goi ), 0, 190 );
		$wpdb->update( VHG_DB::t( 'may' ),
			array( 'ten_goi' => $tg, 'cap_nhat' => current_time( 'mysql' ) ),
			array( 'ma' => $ma ) );
		return array( 'ok' => true, 'thong_bao' => '' === $tg
			? ( 'Đã xoá tên thường gọi của ghế ' . $ma . '.' )
			: ( 'Ghế ' . $ma . ' nay gọi là "' . $tg . '".' ) );
	}

	/**
	 * LƯU MỘT LÔ tên ghế / tên thường gọi — anh Thắng 14/09/2026: *"khi nào bấm lưu mới nhé, chứ
	 * cứ gõ vào phát bấm chuột ra nhảy đi đâu mất"*.
	 *
	 * 🔴 GỐC CỦA PHIỀN PHỨC KHÔNG PHẢI Ở "TỰ LƯU", MÀ Ở CHỖ LƯU XONG VẼ LẠI CẢ TRANG. Đường cũ đi
	 *    qua `lam()` → `tai()` → `ve()`, tức mỗi lần rời một ô là dựng lại toàn bộ màn: mất chỗ
	 *    đang cuộn, mất ô đang gõ dở ở hàng khác. Với một bảng 12 ghế × 2 ô thì đó là 24 lần nhảy.
	 *    Nên đổi HAI thứ cùng lúc: (1) chỉ lưu khi bấm nút, (2) lưu xong CẬP NHẬT TẠI CHỖ.
	 *
	 * @param array $ds [ { ma, ten?, ten_goi? } ] — CHỈ chạm những khoá THẬT SỰ có mặt.
	 *
	 * ⚠️ `array_key_exists` chứ không `isset`/`empty`: xoá trắng một cái tên là ý định hợp lệ
	 *    (bỏ tên thường gọi), mà `empty('')` là true nên `isset`-kiểu sẽ lặng lẽ bỏ qua — người ta
	 *    xoá xong bấm Lưu, báo "đã lưu", mà tên vẫn còn nguyên.
	 * ⚠️ Hai cột VẪN TÁCH BẠCH: `ten` là tên trên sao kê (đi vào đối soát ngân hàng), `ten_goi`
	 *    chỉ để người đọc. Gộp lô KHÔNG có nghĩa là gộp ý nghĩa.
	 */
	public static function dat_ten_lo( $ds ) {
		global $wpdb;
		$ds = is_array( $ds ) ? $ds : array();
		if ( ! $ds ) { return array( 'ok' => false, 'error' => 'Không có thay đổi nào để lưu.' ); }
		$bang = VHG_DB::t( 'may' );
		$xong = 0; $loi = array(); $da = array();
		foreach ( $ds as $x ) {
			$ma = trim( (string) ( isset( $x['ma'] ) ? $x['ma'] : '' ) );
			if ( '' === $ma ) { $loi[] = 'thiếu mã ghế'; continue; }
			$data = array();
			if ( array_key_exists( 'ten', $x ) )     { $data['ten_khai'] = VHG_Doc::chuan_ten( (string) $x['ten'] ); }
			if ( array_key_exists( 'ten_goi', $x ) ) { $data['ten_goi']  = mb_substr( trim( (string) $x['ten_goi'] ), 0, 190 ); }
			if ( ! $data ) { continue; }
			$data['cap_nhat'] = current_time( 'mysql' );
			$wpdb->update( $bang, $data, array( 'ma' => $ma ) );
			/* Trả lại ĐÚNG giá trị sau khi chuẩn hoá — `chuan_ten()` có thể sửa chữ người gõ (bỏ
			   dấu, gộp khoảng trắng). Không trả về thì ô trên màn giữ chữ THÔ, lần sau so với
			   `data-goc` lại thấy "khác" và hiện là chưa lưu, dù đã lưu rồi. */
			$mot = array();
			if ( array_key_exists( 'ten_khai', $data ) ) { $mot['ten']     = (string) $data['ten_khai']; }
			if ( array_key_exists( 'ten_goi', $data ) )  { $mot['ten_goi'] = (string) $data['ten_goi']; }
			$da[ $ma ] = $mot;
			$xong++;
		}
		return array( 'ok' => true, 'xong' => $xong, 'loi' => $loi, 'da' => $da,
			'thong_bao' => '💾 Đã lưu ' . $xong . ' ghế.' . ( $loi ? ( ' ⚠ ' . count( $loi ) . ' dòng lỗi.' ) : '' ) );
	}

	public static function dat_coso( $ma, $coso_id, $ai = '' ) {
		global $wpdb;
		$ma = trim( (string) $ma );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu mã ghế.' ); }
		/* 🔴 KHÔNG cho đổi về coso_id=0 — ghế thành "chưa gán" là rơi khỏi màn nhập, đúng vụ "ghế
		   tự nhiên mất". Ô cơ sở còn ở "— chưa gán —" thì router gửi 0; chặn ngay tại đây. */
		if ( (int) $coso_id <= 0 ) {
			return array( 'ok' => false, 'error' => 'Chưa chọn cơ sở đích — không đổi (để tránh ghế thành "chưa gán", mất khỏi màn nhập).' );
		}
		/* 🔴 CHUYỂN GHẾ SANG MỘT CƠ SỞ THÌ GỠ LUÔN CỜ ẨN — anh Thắng 18/09/2026.
		   Trước đây `dat_coso()` chỉ ghi `coso_id`; cờ `an` chỉ gỡ được bằng một nút KHÁC ("Đưa
		   về"). Nên có một đường đi lặng lẽ: ghế bị ẩn ở cơ sở A → ai đó đổi Địa điểm sang B →
		   sang B rồi mà vẫn `an=1` → nhân viên ở B không bao giờ thấy, trong khi màn quản trị
		   hiện nó nằm đúng cơ sở B. Chuyển ghế về một nơi tức là định DÙNG nó ở đó; bắt người ta
		   nhớ bấm thêm một nút nữa mới thấy ghế là một cái bẫy, không phải một bước. */
		$hien_lai = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT an FROM ' . VHG_DB::t( 'may' ) . ' WHERE ma=%s LIMIT 1', $ma ) ) === 1;
		$dat = array( 'coso_id' => (int) $coso_id, 'cap_nhat' => current_time( 'mysql' ), 'an' => 0 );
		if ( $hien_lai ) {
			$dat['an_luc'] = current_time( 'mysql' );
			$dat['an_ai']  = mb_substr( (string) $ai, 0, 190 );
		}
		$wpdb->update( VHG_DB::t( 'may' ), $dat, array( 'ma' => $ma ) );
		return array( 'ok' => true, 'thong_bao' => 'Đã chuyển cơ sở cho ghế ' . $ma . '.'
			. ( $hien_lai ? ' Ghế đang bị ẩn nên đã HIỆN LẠI luôn ở màn thu tiền của nhân viên.' : '' ) );
	}

	/**
	 * XOÁ HẲN MỘT GHẾ KHỎI DANH MỤC — chỉ khi nó CHƯA TỪNG CÓ ĐỒNG NÀO.
	 *
	 * Anh Thắng 05/09/2026: *"khi lọc cơ sở ghế, có thể thêm xoá sửa được ghế luôn"*.
	 *
	 * 🔴 GHẾ CÓ DOANH THU THÌ KHÔNG XOÁ, VÀ ĐÂY LÀ CHỖ NGUY NHẤT CỦA CẢ MÀN NÀY. Bản trước xoá
	 *    thẳng, không hỏi gì. Doanh thu cũ nằm ở `bc_dong`/`thu` theo `ma_may` chứ không theo id,
	 *    nên xoá ghế không làm mất tiền — nhưng làm mất TÊN: bảng chéo, báo cáo tổng, đối chiếu
	 *    kế toán còn nguyên mấy trăm dòng mang một mã ghế mà tra ra không còn ghế nào. Số vẫn
	 *    đúng, chỉ là không ai biết nó của cái ghế nào nữa.
	 *
	 * ⚠️ LỐI ĐÚNG CHO GHẾ ĐANG CHẠY LÀ "ĐIỀU CHUYỂN". Nó ẩn ghế khỏi màn thu tiền của nhân viên
	 *    mà giữ nguyên chỉ số, doanh thu, và đưa về lại được. Xoá chỉ để dọn ca gõ nhầm mã lúc
	 *    thêm — ghế chưa có lượt nào.
	 */
	/**
	 * XOÁ = ẨN MỀM, KHÔNG XOÁ CỨNG (anh Thắng 10/09/2026: "điều chuyển hay xoá nên để lịch sử máy
	 * chìm xuống ẩn mờ để check được"). Trước đây xoá cứng ghế chưa-có-lịch-sử → biến mất không dấu
	 * vết, đúng vụ "hôm nay tự nhiên mất máy 2". Nay mọi trường hợp đều đánh cờ `an=1`: ghế rơi
	 * xuống khối "Ghế đã điều chuyển" (hiện mờ) ở cuối bảng, chỉ số/doanh thu/log giữ nguyên, bấm
	 * "Đưa về" là phục hồi. Không còn đường nào làm mất một ghế khỏi hệ.
	 */
	/**
	 * XOÁ HẲN mã ghế CHƯA GÁN CƠ SỞ — anh Thắng 14/09/2026: *"xoá mã ghế không có cơ sở"*.
	 *
	 * 🔴 `xoa_may()` KHÔNG XOÁ, nó chỉ đặt `an=1`. Đó là chủ ý (chỉ số, doanh thu, log của ghế
	 *    giữ nguyên) và ĐÚNG cho ghế đang chạy thật. Nhưng mã rác chưa gán cơ sở — kiểu "AMBT01"
	 *    còn sót từ đợt đổi cách đặt mã — thì ẩn đi vẫn nằm đó, không giải quyết được việc anh
	 *    cần. Hàm này là đường DUY NHẤT xoá hẳn, và nó bị bó rất chặt:
	 *
	 *      1. CHỈ ghế `coso_id = 0` (chưa gán). Ghế đang thuộc một cơ sở thì không đụng tới.
	 *      2. CHỈ ghế KHÔNG CÒN DẤU VẾT ở bất kỳ bảng nào mang cột `ma_may`. Còn một dòng doanh
	 *         thu / báo cáo / lệnh / nhịp là KHÔNG xoá — xoá là dòng tiền đó mất chỗ bám, tra
	 *         ngược ra một mã không còn tồn tại.
	 *      3. Ghế bị từ chối thì BÁO RÕ còn dấu vết ở đâu, bao nhiêu dòng. Im lặng bỏ qua là anh
	 *         bấm xong thấy mã vẫn còn mà không hiểu vì sao.
	 *
	 * ⚠️ DANH SÁCH BẢNG DÒ TỪ CHÍNH CSDL (`information_schema`), không chép tay. Chép tay là sau
	 *    này thêm một bảng mới có cột `ma_may` mà quên cập nhật ở đây -> hàm tưởng "sạch" rồi xoá,
	 *    và dữ liệu ở bảng mới thành mồ côi. Dò động thì bảng nào có cột đó là tự được tính.
	 *
	 * @param array $ds_ma    danh sách mã
	 * @param bool  $that     false = CHỈ XEM TRƯỚC (không xoá gì), true = xoá thật
	 * @param bool  $buoc_qua CƯỠNG CHẾ: xoá cả mã còn dữ liệu. Anh Thắng 14/09/2026:
	 *                        *"admin có quyền xoá hẳn"*.
	 *
	 * 🔴 CƯỠNG CHẾ CHỈ BỎ CHỐT SỐ 2, KHÔNG BỎ CHỐT SỐ 1. Mã đang thuộc một cơ sở thì vẫn không
	 *    xoá được, kể cả admin — anh xin quyền xoá "mã không có cơ sở", không phải xoá ghế đang
	 *    chạy. Muốn xoá ghế đang chạy thì gỡ nó khỏi cơ sở trước, để thao tác đó hiện ra rõ ràng.
	 *
	 * 🔴 CƯỠNG CHẾ CHỈ XOÁ DÒNG Ở BẢNG `may`. 237 dòng ở `thu`/`lenh`/`nhip`… VẪN NẰM NGUYÊN.
	 *    Vì sao không xoá luôn: `thu` là TIỀN ĐÃ THU. Xoá đi là tổng doanh thu của những tháng đã
	 *    chốt đổi số — không ai đi đối soát lại một con số tự nhiên nhỏ đi. Giữ lại thì tổng tiền
	 *    không đổi, chỉ là mấy dòng ấy không còn tra ngược ra ghế nào.
	 * ⚠️ HỆ QUẢ PHẢI BIẾT: sau này nếu TẠO LẠI một ghế TRÙNG MÃ cũ, nó sẽ NHẶT LẠI toàn bộ lịch
	 *    sử ấy (mọi bảng nối bằng chuỗi `ma_may`, không bằng id). Đừng dùng lại mã đã xoá.
	 * ⚠️ Mã còn nhiều dòng `thu` gần như luôn là MÃ CŨ của một ghế đã đổi tên — việc đúng là
	 *    `gan_ma()` (đổi mã, lịch sử theo sang) chứ không phải xoá. Màn hình có nói câu này.
	 */
	public static function xoa_han_may( $ds_ma, $that = false, $buoc_qua = false ) {
		global $wpdb;

		$ma_sach = array();
		foreach ( (array) $ds_ma as $m ) {
			$m = trim( (string) $m );
			if ( '' !== $m && ! in_array( $m, $ma_sach, true ) ) { $ma_sach[] = $m; }
		}
		if ( ! $ma_sach ) { return array( 'ok' => false, 'error' => 'Chưa chọn mã ghế nào.' ); }

		/* Bảng nào của plugin có cột `ma_may` — hỏi thẳng CSDL. */
		$tien = $wpdb->prefix . 'vhg\_%';
		$bang_ref = $wpdb->get_col( $wpdb->prepare(
			'SELECT DISTINCT TABLE_NAME FROM information_schema.COLUMNS'
			. ' WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_NAME = %s AND TABLE_NAME LIKE %s',
			'ma_may', $tien ) );
		$bang_ref = is_array( $bang_ref ) ? $bang_ref : array();

		$t_may = VHG_DB::t( 'may' );
		$xoa = array(); $giu = array(); $khong_thay = array(); $mo_coi = array();

		foreach ( $ma_sach as $ma ) {
			$hang = $wpdb->get_row( $wpdb->prepare(
				"SELECT ma, coso_id, an FROM $t_may WHERE ma=%s LIMIT 1", $ma ), ARRAY_A );
			if ( ! $hang ) { $khong_thay[] = $ma; continue; }
			/* 🔴 XOÁ HẲN ĐƯỢC CẢ GHẾ ĐANG NẰM TRONG KHỐI "ĐÃ ẨN" — anh Thắng 19/09/2026: *"cho xoá
			   hẳn được không"*, *"dữ liệu tiền bạc mà cứ sinh rác"*. Vạn Hạnh Mall có 18 mã trong
			   khối ẩn, phần lớn là mã cũ của chính những ghế đang chạy (VHM-11 có cả 80145 lẫn
			   80192). Trước đây hàm này chỉ chịu xoá mã CHƯA GÁN, mà mã rác thì vẫn dính cơ sở —
			   nên không có đường nào dọn, rác nằm đó mãi.
			   Nới đúng một bậc: ghế ĐANG ẨN cũng xoá hẳn được. Không nới cho ghế đang chạy — xoá
			   nhầm một ghế đang thu tiền là mất cả lối vào doanh thu của nó.
			   ⚠️ CHỐT DỮ LIỆU GIỮ NGUYÊN (khối ngay dưới): còn một dòng dữ liệu là KHÔNG xoá. Mã
			      rác mà có tiền thì phải GỘP vào ghế đang chạy trước (đổi mã), xoá thẳng là bỏ
			      lại mấy dòng tiền không tra ra ghế nào. */
			if ( (int) $hang['coso_id'] !== 0 && empty( $hang['an'] ) ) {
				$giu[] = array( 'ma' => $ma, 'ly_do' => 'đang thuộc một cơ sở và KHÔNG bị ẩn — chỉ xoá hẳn được mã chưa gán hoặc mã trong khối "đã ẩn"' );
				continue;
			}
			$dau_vet = array(); $tong = 0;
			foreach ( $bang_ref as $b ) {
				/* Tên bảng không nhét được qua %s (nó sẽ bị bọc nháy) — nhưng danh sách này lấy từ
				   chính information_schema với tiền tố của plugin, không phải từ người dùng. */
				$n = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM `' . str_replace( '`', '', $b ) . '` WHERE ma_may=%s', $ma ) );
				if ( $n > 0 ) { $dau_vet[] = str_replace( $wpdb->prefix . 'vhg_', '', $b ) . ' (' . $n . ')'; $tong += $n; }
			}
			if ( $tong > 0 && ! $buoc_qua ) {
				$giu[] = array( 'ma' => $ma, 'ly_do' => 'còn ' . $tong . ' dòng dữ liệu: ' . implode( ' · ', $dau_vet ),
					'so_dong' => $tong, 'chi_vi_du_lieu' => 1 );
				continue;
			}
			if ( $tong > 0 ) { $mo_coi[ $ma ] = array( 'so_dong' => $tong, 'o' => implode( ' · ', $dau_vet ) ); }
			$xoa[] = $ma;
		}

		if ( ! $that ) {
			return array( 'ok' => true, 'xem_truoc' => true, 'se_xoa' => $xoa, 'giu_lai' => $giu,
				'mo_coi' => $mo_coi, 'buoc_qua' => $buoc_qua ? 1 : 0,
				'khong_thay' => $khong_thay, 'so_bang_da_do' => count( $bang_ref ) );
		}

		$da = 0;
		foreach ( $xoa as $ma ) {
			$da += (int) $wpdb->query( $wpdb->prepare(
				"DELETE FROM $t_may WHERE ma=%s AND (coso_id=0 OR an=1)", $ma ) );
		}
		$tong_mo_coi = 0;
		foreach ( $mo_coi as $mc ) { $tong_mo_coi += (int) $mc['so_dong']; }
		return array( 'ok' => true, 'da_xoa' => $da, 'se_xoa' => $xoa, 'giu_lai' => $giu,
			'khong_thay' => $khong_thay, 'mo_coi' => $mo_coi, 'buoc_qua' => $buoc_qua ? 1 : 0,
			'thong_bao' => '🗑 Đã xoá hẳn ' . $da . ' mã ghế chưa gán.'
				. ( $giu ? ( ' · GIỮ LẠI ' . count( $giu ) . ' mã còn dữ liệu.' ) : '' )
				. ( $tong_mo_coi ? ( ' ⚠ ' . $tong_mo_coi . ' dòng dữ liệu của ' . count( $mo_coi )
					. ' mã vẫn nằm trong CSDL (tổng tiền KHÔNG đổi) nhưng không còn tra ngược ra ghế. '
					. 'ĐỪNG tạo lại ghế trùng mã đã xoá — nó sẽ nhặt lại toàn bộ lịch sử ấy.' ) : '' ) );
	}

	public static function xoa_may( $ma, $ai = '' ) {
		/* "Xoá" ở đây xưa nay chỉ là đặt an=1 — cùng một cửa với ẩn ghế, nên khoá cùng lúc. */
		return self::chan_an_();
		global $wpdb;
		$ma = trim( (string) $ma );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu mã ghế.' ); }

		if ( ! $wpdb->get_var( $wpdb->prepare(
			'SELECT id FROM ' . VHG_DB::t( 'may' ) . ' WHERE ma=%s LIMIT 1', $ma ) ) ) {
			return array( 'ok' => false, 'error' => 'Không có ghế nào mang mã ' . $ma . '.' );
		}

		$so_dong = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHG_DB::t( 'bc_dong' ) . ' WHERE ma_may=%s', $ma ) );
		$so_thu  = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHG_DB::t( 'thu' ) . ' WHERE ma_may=%s', $ma ) );

		$wpdb->update( VHG_DB::t( 'may' ), array( 'an' => 1,
			'an_luc' => current_time( 'mysql' ), 'an_ai' => mb_substr( (string) $ai, 0, 190 ) ),
			array( 'ma' => $ma ) );

		$co_su = ( $so_dong > 0 || $so_thu > 0 );
		return array( 'ok' => true, 'thong_bao' => 'Đã ẩn ghế ' . $ma . ' — nằm mờ trong khối '
			. '"Ghế đã điều chuyển" ở cuối bảng, KHÔNG mất dữ liệu'
			. ( $co_su ? ' (chỉ số và lịch sử còn nguyên)' : '' )
			. '. Cần dùng lại thì mở khối đó ra bấm "Đưa về".' );
	}

	/**
	 * GHẾ ĐÃ DỌN/ĐIỀU CHUYỂN nơi khác — anh Thắng 29/08/2026: "Tích chọn ghế đã dọn/điều chuyển
	 * nơi khác: Ghế sẽ bị ẩn khỏi trang thu tiền của nhân viên, nhưng vẫn lưu trong dữ liệu."
	 *
	 * ĐÁNH DẤU, KHÔNG XOÁ (giống `huy` ở bảng `thu`) — cấu hình máy, doanh thu cũ, log kích/nhịp
	 * đều giữ nguyên. Chỉ đúng MỘT chỗ đọc cờ này: `VHG_BaoCao::ds_ghe()`, nơi dựng danh sách
	 * ghế cho nhân viên nhập chỉ số — trang quản trị (bảng "Máy (ghế)", đối chiếu, kế toán…) vẫn
	 * gọi thẳng `ds_may()` không lọc, nên vẫn thấy đủ ghế kể cả đã dọn.
	 */
	/**
	 * ĐIỀU CHUYỂN NHIỀU GHẾ MỘT LƯỢT — tích chọn rồi ấn đi. Đánh dấu ẩn/hiện hàng loạt, KHÔNG xoá:
	 * chỉ số, doanh thu, log của từng ghế giữ nguyên (xem `dat_an`). `$an=false` = đưa về dùng lại.
	 */
	public static function dat_an_lo( $ds_ma, $an, $ai = '' ) {
		if ( $an ) { return self::chan_an_(); }
		global $wpdb;
		$sach = array();
		foreach ( (array) $ds_ma as $m ) {
			$m = trim( (string) $m );
			if ( '' !== $m && ! in_array( $m, $sach, true ) ) { $sach[] = $m; }
		}
		if ( ! $sach ) { return array( 'ok' => false, 'error' => 'Chưa chọn ghế nào.' ); }
		$bang = VHG_DB::t( 'may' );
		$cho  = implode( ',', array_fill( 0, count( $sach ), '%s' ) );
		$wpdb->query( $wpdb->prepare(
			"UPDATE $bang SET an=%d, an_luc=%s, an_ai=%s WHERE ma IN ($cho)",
			array_merge( array( $an ? 1 : 0, current_time( 'mysql' ),
				mb_substr( (string) $ai, 0, 190 ) ), $sach ) ) );
		return array( 'ok' => true, 'so' => count( $sach ), 'thong_bao' => $an
			? ( 'Đã điều chuyển (ẩn) ' . count( $sach ) . ' ghế — nhân viên hết thấy ở trang thu tiền. '
				. 'Chỉ số và doanh thu cũ giữ nguyên.' )
			: ( 'Đã đưa ' . count( $sach ) . ' ghế về dùng lại — hiện lại ở trang thu tiền.' ) );
	}

	/**
	 * ĐỔI CƠ SỞ NHIỀU GHẾ MỘT LƯỢT — cùng cách giữ chỉ số như `dat_coso`, chỉ là chuyển cả cụm sang
	 * một cơ sở đang có trong hệ thống (khác với `dat_an_lo` là ẩn ghế đã dời khỏi hệ).
	 */
	public static function dat_coso_lo( $ds_ma, $coso_id, $ai = '' ) {
		global $wpdb;
		$sach = array();
		foreach ( (array) $ds_ma as $m ) {
			$m = trim( (string) $m );
			if ( '' !== $m && ! in_array( $m, $sach, true ) ) { $sach[] = $m; }
		}
		if ( ! $sach ) { return array( 'ok' => false, 'error' => 'Chưa chọn ghế nào.' ); }
		/* 🔴 CHẶN coso_id=0 — xem dat_coso(). Đổi lô mà ô cơ sở để trống là orphan CẢ CỤM ghế một
		   lượt (router mặc định 0). Đây là một trong ba đường làm "cả loạt ghế mất một lúc". */
		if ( (int) $coso_id <= 0 ) {
			return array( 'ok' => false, 'error' => 'Chưa chọn cơ sở đích — không đổi lô (để tránh cả cụm ghế thành "chưa gán", mất khỏi màn nhập).' );
		}
		$bang = VHG_DB::t( 'may' );
		$cho  = implode( ',', array_fill( 0, count( $sach ), '%s' ) );
		/* Gỡ cờ ẩn cho cả lô — cùng lý do với dat_coso(): chuyển về một cơ sở là để dùng. */
		$hien_lai = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $bang WHERE an=1 AND ma IN ($cho)", $sach ) );
		$wpdb->query( $wpdb->prepare(
			"UPDATE $bang SET coso_id=%d, cap_nhat=%s, an=0, an_luc=%s, an_ai=%s WHERE ma IN ($cho)",
			array_merge( array( (int) $coso_id, current_time( 'mysql' ), current_time( 'mysql' ),
				mb_substr( (string) $ai, 0, 190 ) ), $sach ) ) );
		return array( 'ok' => true, 'so' => count( $sach ),
			'thong_bao' => 'Đã đổi cơ sở cho ' . count( $sach ) . ' ghế.'
				. ( $hien_lai ? ( ' Trong đó ' . $hien_lai . ' ghế đang bị ẩn đã HIỆN LẠI ở màn thu tiền.' ) : '' ) );
	}

	/* ══════════════════════════════ GHẾ CẦN BẢO TRÌ (đọc/đóng/xoá) — quản trị ══════════════════
	   Nguồn: nhân viên báo ở màn thu tiền (VHG_BaoCao::bao_tri). Anh Thắng 12/09/2026. */
	public static function bao_tri_ds( $trang_thai = '' ) {
		global $wpdb; $t = VHG_DB::t( 'bao_tri' );
		$tt = trim( (string) $trang_thai );
		if ( 'cho' === $tt || 'xong' === $tt ) {
			return VHG_DB::rows( $wpdb->prepare(
				"SELECT * FROM $t WHERE trang_thai=%s ORDER BY id DESC LIMIT 300", $tt ) );
		}
		return VHG_DB::rows( "SELECT * FROM $t ORDER BY CASE trang_thai WHEN 'cho' THEN 0 ELSE 1 END, id DESC LIMIT 300" );
	}
	public static function bao_tri_xong( $id, $boi ) {
		global $wpdb; $id = (int) $id;
		if ( $id <= 0 ) { return array( 'ok' => false, 'error' => 'Thiếu id.' ); }
		$wpdb->update( VHG_DB::t( 'bao_tri' ), array( 'trang_thai' => 'xong',
			'xong_luc' => current_time( 'mysql' ), 'xong_boi' => (string) $boi ), array( 'id' => $id ) );
		return array( 'ok' => true, 'thong_bao' => 'Đã đánh dấu ghế đã sửa xong.' );
	}
	public static function bao_tri_mo( $id ) {
		global $wpdb; $id = (int) $id;
		if ( $id <= 0 ) { return array( 'ok' => false, 'error' => 'Thiếu id.' ); }
		$wpdb->update( VHG_DB::t( 'bao_tri' ), array( 'trang_thai' => 'cho', 'xong_luc' => null, 'xong_boi' => '' ), array( 'id' => $id ) );
		return array( 'ok' => true, 'thong_bao' => 'Đã mở lại (còn lỗi).' );
	}
	public static function bao_tri_xoa( $id ) {
		global $wpdb; $id = (int) $id;
		if ( $id <= 0 ) { return array( 'ok' => false, 'error' => 'Thiếu id.' ); }
		$wpdb->delete( VHG_DB::t( 'bao_tri' ), array( 'id' => $id ) );
		return array( 'ok' => true, 'thong_bao' => 'Đã xoá dòng báo bảo trì.' );
	}

	/**
	 * 🔴 MỖI LẦN ĐỔI CỜ ẨN PHẢI ĐỂ LẠI DẤU VẾT (`an_luc`, `an_ai`) — anh Thắng 18/09/2026.
	 *
	 * Ghế 80111 nằm im ở cờ ẩn từ 13/09; cơ sở nộp báo cáo thiếu một ghế suốt mấy ngày mà không
	 * ai truy được ai bật cờ, lúc nào. Nhật ký `nhat_ky` CÓ ghi câu chữ, nhưng nó chỉ giữ 500
	 * dòng và bị log tiền vào đẩy trôi trong ngày — tức là đúng lúc cần thì không còn. Dấu vết
	 * phải nằm NGAY TRÊN DÒNG GHẾ mới sống lâu bằng chính cái ghế.
	 *
	 * @param string $ai Ai bấm (tên người đăng nhập). Rỗng = không rõ, vẫn ghi mốc thời gian.
	 */
	/**
	 * 🔴 KHOÁ TÍNH NĂNG ẨN GHẾ — anh Thắng 19/09/2026: *"không có dữ liệu xoá nào, khoá lại ẩn
	 *    ghế đi"*.
	 *
	 * Cờ `an` là nguồn của mọi vụ "tự nhiên mất ghế": ghế 80111 nằm im ở cờ ẩn từ 13/09 khiến
	 * một cơ sở 2 ghế nộp báo cáo 1 ghế suốt năm ngày. Mà nghiệp vụ thì KHÔNG cần nó nữa: từ
	 * 2.115.0 màn nhập dựng danh sách theo LỊCH SỬ THU TIỀN (xem VHG_BaoCao::ds_ghe) — ghế nào
	 * còn thu thì còn hiện, ghế tháo thật thì hết GHE_LS_NGAY ngày không thu là tự rụng. Tức là
	 * việc mà nút "ẩn" từng làm, nay dữ liệu tự làm, và làm đúng hơn: không ai phải nhớ bấm, và
	 * không ai bấm nhầm được.
	 *
	 * Vẫn cho GỠ cờ (đưa về) để dọn những ghế đang mắc kẹt cờ cũ. Chỉ chặn chiều BẬT.
	 */
	private static function chan_an_() {
		return array( 'ok' => false, 'error' => 'Tính năng ẩn/điều chuyển ghế đã khoá từ bản 2.115.0. '
			. 'Màn nhập nay dựng theo lịch sử thu tiền: ghế còn thu thì còn hiện, ghế tháo thật thì '
			. 'sau ' . VHG_BaoCao::GHE_LS_NGAY . ' ngày không thu sẽ tự rụng — không cần ẩn tay nữa. '
			. 'Ghế gán nhầm cơ sở thì đổi Địa điểm, đừng ẩn.' );
	}

	public static function dat_an( $ma, $an, $ai = '' ) {
		if ( $an ) { return self::chan_an_(); }
		global $wpdb;
		$ma = trim( (string) $ma );
		if ( '' === $ma ) { return array( 'ok' => false, 'error' => 'Thiếu mã máy.' ); }
		$wpdb->update( VHG_DB::t( 'may' ), array( 'an' => $an ? 1 : 0,
			'an_luc' => current_time( 'mysql' ), 'an_ai' => mb_substr( (string) $ai, 0, 190 ) ),
			array( 'ma' => $ma ) );
		return array( 'ok' => true, 'thong_bao' => $an
			? ( 'Đã đánh dấu ghế ' . $ma . ' ĐÃ DỌN/ĐIỀU CHUYỂN — nhân viên hết thấy ghế này ở trang '
				. 'thu tiền. Dữ liệu cũ vẫn giữ nguyên.' )
			: ( 'Ghế ' . $ma . ' dùng lại bình thường — đã hiện lại ở trang thu tiền của nhân viên.' ) );
	}

	/**
	 * Ghế nào mang MAC này. Trả mảng dòng `may`, hoặc null.
	 *
	 * ⚠️ KHÔNG tự gán mã ghế cho MAC lạ. Ghế chưa khai thì nó hiện ra trong danh sách "chờ gán"
	 *    để người ta gán tay. Đoán bừa là hai ghế cùng nhận một mã, và tiền của ghế này chạy ghế
	 *    kia — mà nhìn từ máy chủ thì không có gì bất thường cả.
	 */
	/**
	 * MAC về ĐÚNG MỘT DẠNG: `AA:BB:CC:DD:EE:FF`.
	 *
	 * 🔴 Ghế gửi lên dạng có hai chấm và chữ hoa (`snprintf("%02X:...")`). Người gõ tay thì gõ
	 *    đủ kiểu: thường, gạch ngang, hoặc dính liền không dấu. Không chuẩn hoá thì cùng một
	 *    con ghế mà bảng có hai dòng — dòng khai tay không bao giờ khớp, và ghế hiện ra như một
	 *    ghế mới. Chuẩn hoá ở MỘT chỗ, dùng cho cả đường ghế gửi lên lẫn đường người gõ vào.
	 *
	 * Chuỗi không phải MAC -> trả RỖNG, không trả bừa: một MAC nửa vời còn tệ hơn không có MAC,
	 * vì nó trông như đã gắn ghế.
	 */
	public static function chuan_mac( $mac ) {
		$s = strtoupper( preg_replace( '/[^0-9A-Fa-f]/', '', (string) $mac ) );
		if ( 12 !== strlen( $s ) ) { return ''; }
		return implode( ':', str_split( $s, 2 ) );
	}

	public static function theo_mac( $mac ) {
		global $wpdb;
		$mac = self::chuan_mac( $mac );
		if ( '' === $mac ) { return null; }
		if ( '' === $mac ) { return null; }
		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . VHG_DB::t( 'may' ) . ' WHERE mac=%s LIMIT 1', $mac ), ARRAY_A );
	}

	/**
	 * Ghi nhận một ghế đang gọi tới. Trả mã ghế ('' nếu chưa được gán).
	 * MAC lạ -> tạo một dòng CHỜ GÁN (mã rỗng) để nó hiện lên web, chứ không im lặng bỏ qua:
	 * ghế cắm điện mà không hiện ở đâu cả thì người đi lắp không biết mình sai chỗ nào.
	 */
	public static function ghi_nhan( $mac ) {
		global $wpdb;
		$mac = self::chuan_mac( $mac );
		if ( '' === $mac ) { return ''; }
		$m = self::theo_mac( $mac );
		if ( $m ) { return (string) $m['ma']; }
		$bang = VHG_DB::t( 'may' );
		/* Mã tạm mang chính MAC: cột `ma` là UNIQUE nên không để rỗng được cho nhiều ghế. Dấu
		   hiệu "chưa gán" là mã bắt đầu bằng `?` — người ta thấy ngay trên màn. */
		$tam = '?' . substr( preg_replace( '/[^0-9A-F]/', '', $mac ), -6 );
		if ( ! $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $bang WHERE ma=%s LIMIT 1", $tam ) ) ) {
			$wpdb->insert( $bang, array( 'ma' => $tam, 'mac' => $mac, 'gia' => 10000, 'phut' => 6,
				'ghi_chu' => 'ghế tự hiện ra khi cắm điện — chưa gán mã', 'cap_nhat' => current_time( 'mysql' ) ) );
		}
		return $tam;
	}

	/** Ghế chưa được gán mã thật (mã còn bắt đầu bằng '?'). */
	public static function chua_gan() {
		$ds = VHG_DB::rows( 'SELECT * FROM ' . VHG_DB::t( 'may' ) . " WHERE ma LIKE '?%' ORDER BY id ASC" );
		/* Kèm luôn nhịp cuối: màn hình cần biết ghế này còn sống không TRƯỚC khi người ta gán mã
		   cho nó. Gán mã cho một ghế đã tháo đi là để lại một dòng cấu hình không bao giờ dùng.
		   Truy vấn để ở ĐÂY chứ không ở màn hình — màn hình không được tự viết SQL, và luật đó
		   có phép thử canh. */
		foreach ( $ds as $i => $x ) {
			$n = self::nhip_cua( $x['ma'] );
			$ds[ $i ]['nhip_luc'] = $n['luc'];
			$ds[ $i ]['fw']       = $n['fw'];
			$ds[ $i ]['ip']       = $n['ip'];
			$ds[ $i ]['con_song'] = self::con_song( $n['luc'] );
		}
		return $ds;
	}

	/** Nhịp cuối của một ghế. Luôn trả đủ ba khoá, kể cả khi ghế chưa gửi nhịp lần nào. */
	public static function nhip_cua( $ma_may ) {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare(
			'SELECT luc, fw, ip, nd_tien_to FROM ' . VHG_DB::t( 'nhip' ) . ' WHERE ma_may=%s LIMIT 1',
			(string) $ma_may ), ARRAY_A );
		return array(
			'luc' => $r ? (string) $r['luc'] : '',
			'fw'  => $r ? (string) $r['fw'] : '',
			'ip'  => $r ? (string) $r['ip'] : '',
			'nd_tien_to' => $r ? (string) $r['nd_tien_to'] : '',
		);
	}

	public static function may( $ma ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . VHG_DB::t( 'may' ) . ' WHERE ma=%s LIMIT 1', (string) $ma ), ARRAY_A );
	}

	// ======================================================================= hàng chờ chạy

	/** Tiền đã vào -> xếp cho ghế chạy. Cùng (máy, mã) tới hai lần thì chỉ một hàng. */
	public static function xep_cho_chay( $ma_may, $ma_lenh, $so_tien, $ref, $noi_dung ) {
		global $wpdb;
		$bang = VHG_DB::t( 'cho' );
		$co = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM $bang WHERE ma_may=%s AND ma_lenh=%s LIMIT 1", $ma_may, $ma_lenh ) );
		if ( $co ) { return (int) $co; }
		$wpdb->insert( $bang, array(
			'ma_may' => (string) $ma_may, 'ma_lenh' => (string) $ma_lenh,
			'so_tien' => (int) $so_tien, 'ref' => (string) $ref,
			'noi_dung' => mb_substr( (string) $noi_dung, 0, 250 ),
			'tao_luc' => current_time( 'mysql' ), 'nhan_luc' => null ) );
		return (int) $wpdb->insert_id;
	}

	public static function so_cho( $ma_may ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . VHG_DB::t( 'cho' ) . ' WHERE ma_may=%s AND nhan_luc IS NULL', $ma_may ) );
	}

	public static function ds_cho( $chi_chua_nhan = true, $gioi_han = 200 ) {
		$sql = 'SELECT * FROM ' . VHG_DB::t( 'cho' )
			. ( $chi_chua_nhan ? ' WHERE nhan_luc IS NULL' : '' )
			. ' ORDER BY id DESC LIMIT ' . (int) $gioi_han;
		return VHG_DB::rows( $sql );
	}

	/**
	 * Ghế hỏi "có ai trả tiền cho tôi chưa". Trả lượt CŨ NHẤT chưa nhận và đánh dấu đã nhận.
	 *
	 * ⚠️ ĐÁNH DẤU NGAY, KHÔNG chờ ghế báo chạy xong. Ghế mất điện giữa chừng thì khách mất lượt —
	 *    nhưng KHÔNG đánh dấu thì ghế khởi động lại là chạy lại lượt cũ, và cứ thế mãi. Giữa "mất
	 *    một lượt hiếm khi" và "một lượt chạy vô hạn", chọn cái thứ nhất; cái thứ hai còn làm
	 *    hỏng cả bảng đối soát. Người ta bù tay bằng lệnh bật.
	 */
	public static function lay_luot( $ma_may ) {
		global $wpdb;
		$bang = VHG_DB::t( 'cho' );
		$r = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM $bang WHERE ma_may=%s AND nhan_luc IS NULL ORDER BY id ASC LIMIT 1",
			(string) $ma_may ), ARRAY_A );
		if ( ! $r ) { return null; }
		$wpdb->update( $bang, array( 'nhan_luc' => current_time( 'mysql' ) ), array( 'id' => (int) $r['id'] ) );
		return $r;
	}

	// ======================================================================= nhịp sống

	public static function nhip( $ma_may, $d ) {
		global $wpdb;
		$ma_may = trim( (string) $ma_may );
		if ( '' === $ma_may ) { return false; }
		$bang = VHG_DB::t( 'nhip' );
		$hang = array(
			'ma_may'     => $ma_may,
			'trang_thai' => mb_substr( (string) ( isset( $d['trang_thai'] ) ? $d['trang_thai'] : 'idle' ), 0, 20 ),
			'nguon'      => mb_substr( (string) ( isset( $d['nguon'] ) ? $d['nguon'] : '' ), 0, 20 ),
			'con_lai'    => (int) ( isset( $d['con_lai'] ) ? $d['con_lai'] : 0 ),
			/* Chặn trên 65535 vì cột là SMALLINT UNSIGNED: quá tầm thì MySQL cắt về 65535 ở chế
			   độ lỏng, hoặc từ chối cả hàng ở chế độ chặt — mất luôn nhịp vì một con số chỉ để
			   chỉnh đồng hồ. Ghế mất mạng lâu có thể gửi lên con số rất lớn. */
			'tre_ms'     => max( 0, min( 65535, (int) ( isset( $d['tre'] ) ? $d['tre'] : 0 ) ) ),
			'tm_loi'     => self::ma_loi_tien( isset( $d['tm_loi'] ) ? $d['tm_loi'] : '' ),
			'tm_cuoi'    => self::ma_loi_tien( isset( $d['tm_cuoi'] ) ? $d['tm_cuoi'] : '' ),
			'tm_lan'     => max( 0, min( 65535, (int) ( isset( $d['tm_lan'] ) ? $d['tm_lan'] : 0 ) ) ),
			/* Ghế đếm bằng millis() của chính nó, không có đồng hồ thật — nên nó khai TUỔI
			   (bao nhiêu giây trước), còn máy chủ đổi ra giờ tuyệt đối theo đồng hồ của mình.
			   Đây là cách duy nhất đúng khi hai bên không chung đồng hồ. */
			'tm_luc'     => self::luc_tu_tuoi( isset( $d['tm_giay'] ) ? $d['tm_giay'] : -1 ),
			'tm_to'      => self::luc_tu_tuoi( isset( $d['tm_to'] ) ? $d['tm_to'] : -1 ),
			'khoa'       => ! empty( $d['khoa'] ) ? 1 : 0,   // ghế đang KHÓA lỗi (chờ hotline mở)
			'kt'         => ! empty( $d['kt'] ) ? 1 : 0,     // ghế đang CHẾ ĐỘ KỸ THUẬT (test)
			'ip'         => mb_substr( (string) ( isset( $d['ip'] ) ? $d['ip'] : '' ), 0, 60 ),
			'nd_tien_to' => mb_substr( trim( (string) ( isset( $d['nd'] ) ? $d['nd'] : '' ) ), 0, 20 ),
			/* 80, KHỚP VỚI CỘT. Cắt 40 ở đây là cách hỏng âm thầm: chuỗi phiên bản
			   "ghe-massage 2026-08-22e (tien to noi dung CK tu web)" dài 51 ký tự, cắt xong
			   thành nửa câu, và màn đối chiếu firmware chỉ đó nói ghế đang chạy bản nào. */
			'fw'         => mb_substr( (string) ( isset( $d['fw'] ) ? $d['fw'] : '' ), 0, 80 ),
			'luc'        => current_time( 'mysql' ),
		);

		/* ══════════════════════════════════════════════════════════════════════════════════
		 * TRẠNG THÁI CHẠY THẬT (chân báo-chạy của bo ghế) -> NHẬT KÝ BẬT/TẮT.
		 *
		 * ⚠️ CHỈ XÉT KHI GHẾ CÓ KHAI `chay`. Firmware cũ (chưa bật DO_GHECHAY) không gửi trường
		 *    này — coi vắng mặt là 0 thì mỗi nhịp của ghế cũ ghi một lượt "tắt" giả. Vắng mặt =
		 *    -1 = "ghế không đo được", KHÔNG đụng vào cột `chay` và KHÔNG ghi nhật ký.
		 * ⚠️ Chỉ ghi khi TRẠNG THÁI ĐỔI so với nhịp trước. Nhịp lặp lại cùng trạng thái không phải
		 *    một lần bật/tắt mới. Lần đầu một ghế gửi nhịp thì chưa có mốc để so -> không ghi
		 *    (tránh một lượt "bật" giả ngay sau khi nâng cấp cho ghế đang chạy). */
		$chay_moi = array_key_exists( 'chay', $d ) ? ( empty( $d['chay'] ) ? 0 : 1 ) : -1;
		if ( $chay_moi >= 0 ) { $hang['chay'] = $chay_moi; }

		$cu = $wpdb->get_row( $wpdb->prepare(
			"SELECT id, chay FROM $bang WHERE ma_may=%s LIMIT 1", $ma_may ), ARRAY_A );
		if ( $cu ) {
			if ( $chay_moi >= 0 && (int) $cu['chay'] !== $chay_moi ) {
				/* Ghế khai tuổi của lần đổi trạng thái (`chay_giay`); đổi ra giờ tuyệt đối. Không
				   khai được thì lấy giờ nhận làm mốc — trễ vài giây, vẫn đúng thứ tự. */
				$luc_doi = self::luc_tu_tuoi( isset( $d['chay_giay'] ) ? $d['chay_giay'] : -1 );
				if ( null === $luc_doi ) { $luc_doi = current_time( 'mysql' ); }
				self::ghi_bat_tat( $ma_may, $chay_moi ? 'bat' : 'tat', $luc_doi );
			}
			$wpdb->update( $bang, $hang, array( 'id' => (int) $cu['id'] ) );
		} else {
			$wpdb->insert( $bang, $hang );
		}
		return true;
	}

	/**
	 * GHI MỘT LẦN BẬT/TẮT vào nhật ký vận hành.
	 *
	 * `giay` chỉ có nghĩa cho dòng 'tat': đo từ lần 'bat' gần nhất của CHÍNH ghế đó tới lượt tắt
	 * này. Tính sẵn ở đây thay vì ghép cặp lúc đọc — bảng lịch sử mở trên 4G, ghép cặp mỗi lần
	 * mở là quét cả bảng chỉ để hiện một cột.
	 */
	public static function ghi_bat_tat( $ma_may, $su_kien, $luc ) {
		global $wpdb;
		$ma_may  = mb_substr( trim( (string) $ma_may ), 0, 40 );
		$su_kien = ( 'bat' === $su_kien ) ? 'bat' : 'tat';
		if ( '' === $ma_may ) { return; }
		$t   = VHG_DB::t( 'bat_tat' );
		$luc = '' !== trim( (string) $luc ) ? $luc : current_time( 'mysql' );

		$giay = 0;
		if ( 'tat' === $su_kien ) {
			$bat = $wpdb->get_var( $wpdb->prepare(
				"SELECT luc FROM $t WHERE ma_may=%s AND su_kien='bat' ORDER BY id DESC LIMIT 1", $ma_may ) );
			if ( $bat ) {
				$g = strtotime( (string) $luc ) - strtotime( (string) $bat );
				/* Chặn 0..24h: mốc lỗi hoặc ghế chạy vắt ngày làm ra con số vô lý — thà để 0 (không
				   biết) còn hơn một cột "chạy 3 ngày" mà không ai tin nổi. */
				if ( $g > 0 && $g <= 86400 ) { $giay = (int) $g; }
			}
		}
		$wpdb->insert( $t, array(
			'ma_may'  => $ma_may,
			'su_kien' => $su_kien,
			'luc'     => $luc,
			'giay'    => $giay,
			'tao_luc' => current_time( 'mysql' ),
		) );
	}

	/**
	 * LỊCH SỬ BẬT/TẮT — mới nhất trước, kèm tên cơ sở.
	 *
	 * ⚠️ Trả cả `coso` để màn lọc/gom theo cơ sở được ngay, không phải tra lại từng dòng.
	 */
	public static function ds_bat_tat( $ky = 'week', $gioi_han = 500 ) {
		global $wpdb;
		$t  = VHG_DB::t( 'bat_tat' );
		$tu = VHG_Thu::dau_ky( $ky );
		$den = VHG_Thu::cuoi_ky( $ky );
		$gh = max( 1, min( 1000, (int) $gioi_han ) );
		$sql = "SELECT * FROM $t";
		if ( '' !== $tu ) { $sql = $wpdb->prepare( $sql . ' WHERE luc >= %s', $tu ); }
		if ( '' !== $den ) { $sql .= ( '' !== $tu ? ' AND' : ' WHERE' ) . $wpdb->prepare( ' luc < %s', $den ); }
		$sql .= ' ORDER BY id DESC LIMIT ' . $gh;
		$may = self::ds_may_theo_ma();
		$ra  = array();
		foreach ( VHG_DB::rows( $sql ) as $r ) {
			$m = (string) $r['ma_may'];
			$ra[] = array(
				'id'      => (int) $r['id'],
				'ma'      => $m,
				'coso'    => isset( $may[ $m ] ) ? (string) $may[ $m ]['coso_ten'] : '',
				'su_kien' => (string) $r['su_kien'],
				'luc'     => (string) $r['luc'],
				'giay'    => (int) $r['giay'],
			);
		}
		return $ra;
	}

	/**
	 * Gộp theo GHẾ trong kỳ: mấy lần chạy, tổng bao nhiêu phút chạy thật, lần cuối khi nào.
	 * Đếm số lần chạy = số dòng 'bat'; tổng phút = tổng `giay` của các dòng 'tat'.
	 */
	public static function tong_bat_tat_may( $ky = 'week' ) {
		global $wpdb;
		$t  = VHG_DB::t( 'bat_tat' );
		$tu = VHG_Thu::dau_ky( $ky );
		$den = VHG_Thu::cuoi_ky( $ky );
		$dk = '' !== $tu ? $wpdb->prepare( ' AND luc >= %s', $tu ) : '';
		if ( '' !== $den ) { $dk .= $wpdb->prepare( ' AND luc < %s', $den ); }
		$sql = "SELECT ma_may,
			SUM(CASE WHEN su_kien='bat' THEN 1 ELSE 0 END) AS so_lan,
			SUM(CASE WHEN su_kien='tat' THEN giay ELSE 0 END) AS tong_giay,
			MAX(luc) AS lan_cuoi
			FROM $t WHERE 1=1$dk GROUP BY ma_may ORDER BY so_lan DESC LIMIT 200";
		$may = self::ds_may_theo_ma();
		$ra  = array();
		foreach ( VHG_DB::rows( $sql ) as $r ) {
			$m = (string) $r['ma_may'];
			$ra[] = array( 'ma' => $m,
				'coso' => isset( $may[ $m ] ) ? (string) $may[ $m ]['coso_ten'] : '',
				'so_lan' => (int) $r['so_lan'],
				'tong_phut' => (int) round( (int) $r['tong_giay'] / 60 ),
				'lan_cuoi' => (string) $r['lan_cuoi'] );
		}
		return $ra;
	}

	// ======================================================================= lệnh bật/tắt tay

	/**
	 * Đặt lệnh cho ghế. `$viec` = 'on' (chạy $phut phút) hoặc 'off' (tắt ngay).
	 * ⚠️ BẮT BUỘC ghi người đặt — đây là đường cho không một lượt massage, xem khối ⚠️ đầu tệp.
	 */
	public static function dat_lenh( $ma_may, $viec, $phut, $nguoi, $ly_do = '' ) {
		global $wpdb;
		$ma_may = trim( (string) $ma_may );
		if ( '' === $ma_may ) { return array( 'ok' => false, 'error' => 'Thiếu mã máy.' ); }
		if ( ! in_array( $viec, array( 'on', 'off', 'reboot', 'mokhoa', 'test' ), true ) ) {
			return array( 'ok' => false, 'error' => 'Lệnh chỉ có thể là bật (on), tắt (off), '
				. 'khởi động lại (reboot), mở khoá lỗi (mokhoa) hoặc chế độ kỹ thuật (test).' );
		}
		$nguoi = trim( (string) $nguoi );
		if ( '' === $nguoi ) { return array( 'ok' => false, 'error' => 'Thiếu tên người đặt lệnh.' ); }
		$phut = (int) $phut;
		if ( 'on' === $viec ) {
			$m = self::may( $ma_may );
			if ( $phut <= 0 ) { $phut = $m ? (int) $m['phut'] : 6; }
			/* Chặn trần: gõ nhầm 600 thay vì 6 là ghế chạy 10 tiếng và không ai ở đó để tắt. */
			if ( $phut > 60 ) {
				return array( 'ok' => false, 'error' => 'Tối đa 60 phút một lệnh. Gõ nhầm số 0 là '
					. 'ghế chạy suốt đêm mà không ai ở đó để tắt.' );
			}
		}
		$wpdb->insert( VHG_DB::t( 'lenh' ), array(
			'ma_may' => $ma_may, 'viec' => $viec, 'phut' => $phut,
			'nguoi' => mb_substr( $nguoi, 0, 190 ), 'ly_do' => mb_substr( (string) $ly_do, 0, 250 ),
			'tao_luc' => current_time( 'mysql' ), 'gui_luc' => null ) );
		if ( 'on' === $viec ) {
			return array( 'ok' => true, 'thong_bao' => 'Đã đặt lệnh cho máy ' . $ma_may . ' chạy '
				. $phut . ' phút. Máy nhận trong ~10 giây.' );
		}
		if ( 'reboot' === $viec ) {
			return array( 'ok' => true, 'thong_bao' => 'Đã đặt lệnh KHỞI ĐỘNG LẠI máy ' . $ma_may
				. '. Máy nhận trong ~10 giây rồi tự khởi động, mất khoảng 30 giây mới gửi nhịp lại.' );
		}
		if ( 'mokhoa' === $viec ) {
			return array( 'ok' => true, 'thong_bao' => 'Đã đặt lệnh MỞ KHOÁ LỖI máy ' . $ma_may
				. '. Máy nhận trong ~10 giây rồi cho quét QR lại.' );
		}
		if ( 'test' === $viec ) {
			return array( 'ok' => true, 'thong_bao' => ( $phut ? 'BẬT' : 'TẮT' )
				. ' chế độ kỹ thuật cho máy ' . $ma_may . '. Máy nhận trong ~10 giây. '
				. ( $phut ? 'Trong chế độ này ghế không khoá lỗi, tự tắt sau 15 phút.' : '' ) );
		}
		return array( 'ok' => true, 'thong_bao' => 'Đã đặt lệnh TẮT máy ' . $ma_may . '.' );
	}

	/** Ghế lấy lệnh cũ nhất chưa gửi. Lấy xong đánh dấu đã gửi. */
	public static function lay_lenh( $ma_may ) {
		global $wpdb;
		$bang = VHG_DB::t( 'lenh' );
		$r = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM $bang WHERE ma_may=%s AND gui_luc IS NULL ORDER BY id ASC LIMIT 1",
			(string) $ma_may ), ARRAY_A );
		if ( ! $r ) { return null; }
		$wpdb->update( $bang, array( 'gui_luc' => current_time( 'mysql' ) ), array( 'id' => (int) $r['id'] ) );
		return $r;
	}

	public static function ds_lenh( $gioi_han = 100 ) {
		return VHG_DB::rows( 'SELECT * FROM ' . VHG_DB::t( 'lenh' )
			. ' ORDER BY id DESC LIMIT ' . (int) $gioi_han );
	}
}
