<?php
/**
 * Tiện ích chung — cổng chuyển đổi giữa cách Google Sheet lưu giá trị và cách MySQL lưu.
 *
 * Bên Apps Script, ô trống ('') khác 0: "chưa nhập Thực mua" khác "Thực mua = 0".
 * Ở đây ô trống = NULL, nên mọi hàm đọc/ghi đều đi qua blank_or_num()/num().
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class VHCP_Util {

	/** Múi giờ app (mặc định Asia/Bangkok — giống appsscript.json của app cũ). */
	public static function tz() {
		$tz = get_option( 'vhcp_timezone' );
		if ( ! $tz ) { $tz = 'Asia/Bangkok'; }
		try { return new DateTimeZone( $tz ); } catch ( Exception $e ) { return new DateTimeZone( 'Asia/Bangkok' ); }
	}

	public static function now() {
		return new DateTime( 'now', self::tz() );
	}

	/** 'Y-m-d H:i:s' theo giờ app — dạng lưu vào cột DATETIME. */
	public static function now_sql() {
		return self::now()->format( 'Y-m-d H:i:s' );
	}

	/** 'Y-m-d' hôm nay theo giờ app. */
	public static function today_sql() {
		return self::now()->format( 'Y-m-d' );
	}

	/**
	 * Bản sao của _fmt() bên Apps Script: giá trị ngày → 'dd/MM/yyyy', còn lại giữ nguyên chuỗi.
	 * Chuỗi ISO trong DB ('2026-08-20', '2026-08-20 09:12:00') được coi là ngày.
	 */
	public static function fmt( $v ) {
		if ( $v === null || $v === '' ) { return ''; }
		if ( $v instanceof DateTimeInterface ) { return $v->format( 'd/m/Y' ); }
		$s = (string) $v;
		if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})(?:[ T]\d{2}:\d{2}(:\d{2})?)?$/', $s, $m ) ) {
			if ( $m[1] === '0000' ) { return ''; }
			return $m[3] . '/' . $m[2] . '/' . $m[1];
		}
		return $s;
	}

	/** Bản sao của _fmtDT(): 'dd/MM/yyyy HH:mm:ss'. */
	public static function fmt_dt( $v ) {
		if ( $v === null || $v === '' ) { return ''; }
		if ( $v instanceof DateTimeInterface ) { return $v->format( 'd/m/Y H:i:s' ); }
		$s = (string) $v;
		if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/', $s, $m ) ) {
			return $m[3] . '/' . $m[2] . '/' . $m[1] . ' ' . $m[4] . ':' . $m[5] . ':' . ( isset( $m[6] ) ? $m[6] : '00' );
		}
		return self::fmt( $s );
	}

	/**
	 * Đọc chuỗi ngày người dùng gửi lên ('dd/MM/yyyy', 'yyyy-mm-dd', 'dd-mm-yyyy') → 'Y-m-d'.
	 * Không đọc được → null (ô trống).
	 */
	public static function parse_date( $v ) {
		if ( $v === null || $v === '' ) { return null; }
		if ( $v instanceof DateTimeInterface ) { return $v->format( 'Y-m-d' ); }
		$s = trim( (string) $v );
		if ( $s === '' ) { return null; }
		if ( preg_match( '#^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})#', $s, $m ) ) {
			return sprintf( '%04d-%02d-%02d', $m[1], $m[2], $m[3] );
		}
		if ( preg_match( '#^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})#', $s, $m ) ) {
			$y = (int) $m[3];
			if ( $y < 100 ) { $y += 2000; }
			return sprintf( '%04d-%02d-%02d', $y, $m[2], $m[1] );
		}
		$ts = strtotime( $s );
		return $ts ? gmdate( 'Y-m-d', $ts ) : null;
	}

	/** Số (0 nếu không phải số) — tương đương Number(x)||0. */
	public static function num( $v ) {
		if ( is_bool( $v ) ) { return $v ? 1 : 0; }
		if ( $v === null || $v === '' ) { return 0; }
		if ( is_numeric( $v ) ) { return 0 + $v; }
		$s = str_replace( array( ',', ' ', "\xc2\xa0" ), '', (string) $v );
		return is_numeric( $s ) ? 0 + $s : 0;
	}

	/**
	 * Ô "có thể trống" (Thực mua / Thuế suất / Tạm ứng duyệt…):
	 * trả về null nếu trống hoặc không phải số, ngược lại trả số.
	 */
	public static function blank_or_num( $v ) {
		if ( $v === null ) { return null; }
		if ( is_bool( $v ) ) { return $v ? 1 : 0; }
		if ( is_string( $v ) && trim( $v ) === '' ) { return null; }
		if ( is_numeric( $v ) ) { return 0 + $v; }
		$s = str_replace( array( ',', ' ', "\xc2\xa0" ), '', (string) $v );
		return is_numeric( $s ) ? 0 + $s : null;
	}

	/** Ô trống → '' ; số → số (để trả về UI đúng như app cũ). */
	public static function out_num( $v ) {
		return ( $v === null || $v === '' ) ? '' : 0 + $v;
	}

	public static function s( $v ) {
		if ( $v === null || is_bool( $v ) || is_array( $v ) ) { return is_bool( $v ) ? ( $v ? 'true' : 'false' ) : ''; }
		return trim( (string) $v ) === '' ? (string) $v : (string) $v;
	}

	/** Chuỗi đã trim. */
	public static function st( $v ) {
		if ( $v === null || is_array( $v ) ) { return ''; }
		if ( is_bool( $v ) ) { return $v ? 'true' : 'false'; }
		return trim( (string) $v );
	}

	/** Bản sao của _uid(): 'D_<base36 thời gian><base36 ngẫu nhiên>'. */
	public static function uid( $prefix ) {
		$t = base_convert( (string) ( (int) ( microtime( true ) * 1000 ) ), 10, 36 );
		$r = base_convert( (string) wp_rand( 0, 46655 ), 10, 36 );
		return $prefix . '_' . $t . $r;
	}

	/** _cnFlag(): mặc định TÍCH (kế toán cá nhân xử lý). */
	public static function cn_flag( $v ) {
		if ( $v === 0 || $v === '0' || $v === false ) { return false; }
		return strtolower( trim( (string) $v ) ) !== 'false';
	}

	/** _isPhatSinh(): 1 = dòng phát sinh. */
	public static function is_phat_sinh( $v ) {
		if ( $v === 1 || $v === '1' || $v === true ) { return true; }
		return strtolower( trim( (string) $v ) ) === 'true';
	}

	/** _isNcc(): NCC nếu phân loại NCC HOẶC dòng cá nhân bị bỏ tích. */
	public static function is_ncc( $pltt, $cn ) {
		return ( $pltt === 'Nhà cung cấp' ) || ! self::cn_flag( $cn );
	}

	/** _daSan()/_mkSan(): làm sạch tên sheet/dự án. */
	public static function san( $s ) {
		$s = preg_replace( '/[\[\]\*\?\/\\\\:]/', ' ', (string) $s );
		$s = preg_replace( '/\s+/u', ' ', $s );
		$s = trim( $s );
		return mb_substr( $s, 0, 60 );
	}

	/** _quyenTruthy(). */
	public static function quyen_truthy( $v ) {
		if ( $v === 1 || $v === true || $v === '1' ) { return true; }
		$s = strtolower( trim( (string) $v ) );
		return in_array( $s, array( 'true', '✓', 'x' ), true );
	}

	/** Nối các phần không rỗng bằng dấu cách — bản sao hàm _j() dùng khi xuất MISA. */
	public static function j( $arr ) {
		$out = array();
		foreach ( $arr as $x ) {
			if ( $x === null ) { continue; }
			if ( trim( (string) $x ) === '' ) { continue; }
			$out[] = (string) $x;
		}
		return implode( ' ', $out );
	}

	/** _kyNum(): xếp thứ tự kỳ (tuần/tháng) theo ngày đầu kỳ. */
	public static function ky_num( $s ) {
		$s = trim( (string) $s );
		if ( preg_match( '#^(\d{1,2})/(\d{1,2})/(\d{4})$#', $s, $m ) ) {
			return (int) $m[3] * 10000 + (int) $m[2] * 100 + (int) $m[1];
		}
		if ( preg_match( '#\((\d{1,2})/(\d{1,2})\s*-\s*(\d{1,2})/(\d{1,2})/(\d{4})\)#', $s, $r ) ) {
			$sd = (int) $r[1]; $sm = (int) $r[2]; $em = (int) $r[4]; $yy = (int) $r[5];
			$sy = ( $sm > $em ) ? $yy - 1 : $yy;
			return $sy * 10000 + $sm * 100 + $sd;
		}
		if ( preg_match( '#(\d{1,2})/(\d{1,2})/(\d{4})#', $s, $g ) ) {
			return (int) $g[3] * 10000 + (int) $g[2] * 100 + (int) $g[1];
		}
		if ( preg_match( '#T\s*(\d{1,2})\s*/\s*(\d{4})#i', $s, $t ) ) {
			return (int) $t[2] * 10000 + (int) $t[1] * 100;
		}
		return -1;
	}

	/** Bản sao _vhParseDMY(): chuỗi ngày bất kỳ → DateTime (không giờ) hoặc null. */
	public static function vh_parse_dmy( $v ) {
		$ymd = self::parse_date( $v );
		if ( ! $ymd ) { return null; }
		$d = DateTime::createFromFormat( 'Y-m-d|', $ymd, self::tz() );
		return $d ? $d : null;
	}

	public static function vh_ymd( DateTime $d ) {
		return (int) $d->format( 'Y' ) * 10000 + (int) $d->format( 'n' ) * 100 + (int) $d->format( 'j' );
	}

	/** Thứ Hai của tuần chứa $d. */
	public static function vh_monday( DateTime $d ) {
		$x = new DateTime( $d->format( 'Y-m-d' ), self::tz() );
		$g = (int) $x->format( 'w' );              // 0 = Chủ nhật
		$shift = ( $g === 0 ) ? -6 : 1 - $g;
		if ( $shift !== 0 ) { $x->modify( ( $shift > 0 ? '+' : '' ) . $shift . ' day' ); }
		return $x;
	}

	/** Số tuần ISO. */
	public static function vh_week_no( DateTime $d ) {
		return (int) $d->format( 'W' );
	}

	/** Trả mảng JSON an toàn cho REST (chuỗi UTF-8, số là số). */
	public static function ok( $extra = array() ) {
		return array_merge( array( 'success' => true ), $extra );
	}

	public static function err( $msg ) {
		return array( 'success' => false, 'error' => $msg );
	}
}
