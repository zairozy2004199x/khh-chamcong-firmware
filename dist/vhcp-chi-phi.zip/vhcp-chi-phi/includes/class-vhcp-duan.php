<?php
/**
 * CHI PHÍ KỸ THUẬT — dự án Tháo dỡ / Setup lắp đặt + sheet "Chi phí cơ sở" chung xuyên suốt.
 *
 * App cũ mỗi dự án là 1 tab Google Sheet; ở đây là các dòng trong vhcp_da_line khóa theo
 * (ma_da, row_no). row_no vẫn bắt đầu từ 5 để giao diện gọi updateDuAnLine(maDA, row, rec) như cũ.
 *
 * Quy ước tính tiền giữ nguyên:
 *   - Hạng mục lớn (cap_cha rỗng) mang DỰ TOÁN. Thực tế của nó chỉ tính khi KHÔNG có mục con.
 *   - Mục con / (Phát sinh) chỉ mang THỰC TẾ; hình thức chi thừa hưởng của hạng mục cha.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class VHCP_DuAn {

	const DATA_ROW = 5;

	public static function find( $ma_da ) {
		global $wpdb;
		$t = VHCP_DB::t( 'da_index' );
		return VHCP_DB::row( $wpdb->prepare( "SELECT * FROM $t WHERE ma_da=%s", (string) $ma_da ) );
	}

	/**
	 * ĐƠN VỊ của một dự án — neo theo NGƯỜI TẠO, không theo cơ sở.
	 *
	 * 🔴 KHÁC HAI MẢNG KIA, VÀ ĐÂY LÀ LÝ DO. Bảng `da_index` KHÔNG có cột cơ sở: một dự án
	 *    (setup/tháo dỡ) trải qua nhiều gian, cơ sở chỉ nằm trên từng DÒNG (`da_line.gian`),
	 *    và các dòng ấy có thể thuộc nhiều gian khác nhau. Neo theo cơ sở thì phải trả lời
	 *    "dự án chạm gian của cả hai bên thì của ai" — không có câu trả lời đúng, và câu nào
	 *    cũng làm lộ số của một bên.
	 *
	 *    Người lập thì luôn có đúng một nhà. Dự án là việc của một bên đứng ra làm, nên neo
	 *    vào nhà của người ấy là đúng nghiệp vụ và không có ca nhập nhằng.
	 *
	 * ⚠️ Người tạo rỗng (dữ liệu cũ, nhập từ sổ) -> `cua_nguoi()` trả nhà mặc định = K&H.
	 *    Đúng: trước khi có POSH thì mọi dự án đều là dự án K&H.
	 */
	public static function don_vi_cua( $khoa, $kieu = 'ma_da' ) {
		if ( 'ma_da' !== $kieu ) { return null; }
		$r = self::find( $khoa );
		if ( ! $r ) { return null; }
		return VHCP_DonVi::cua_nguoi( isset( $r['nguoi_tao'] ) ? $r['nguoi_tao'] : '' );
	}

	private static function lines_of( $ma_da ) {
		global $wpdb;
		$t = VHCP_DB::t( 'da_line' );
		return VHCP_DB::rows( $wpdb->prepare( "SELECT * FROM $t WHERE ma_da=%s ORDER BY row_no ASC", (string) $ma_da ) );
	}

	private static function next_row( $ma_da ) {
		global $wpdb;
		$t   = VHCP_DB::t( 'da_line' );
		$max = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(row_no) FROM $t WHERE ma_da=%s", (string) $ma_da ) );
		return max( self::DATA_ROW, $max + 1 );
	}

	/** Dòng "có nội dung": bỏ hàng trống hoàn toàn (giống điều kiện lọc của app cũ). */
	private static function is_real( $r ) {
		return ! ( trim( (string) $r['noi_dung'] ) === '' && ! ( VHCP_Util::num( $r['du_toan'] ) || VHCP_Util::num( $r['thuc_te'] ) ) );
	}

	// ---------------------------------------------------------------- tạo / danh sách

	public static function create_du_an( $loai, $ten, $nguoi ) {
		global $wpdb;
		$loai = trim( (string) $loai );
		if ( $loai === 'Chi phí cơ sở' ) { return self::ensure_co_so_chung( $nguoi ); }
		$ten = VHCP_Util::san( $ten );
		if ( ! in_array( $loai, array( 'Tháo dỡ', 'Setup lắp đặt' ), true ) ) { return VHCP_Util::err( 'Loại không hợp lệ' ); }
		if ( $ten === '' ) { return VHCP_Util::err( 'Nhập tên dự án' ); }
		$ma = VHCP_Util::uid( 'DA' );
		$wpdb->insert( VHCP_DB::t( 'da_index' ), array(
			'ma_da'      => $ma,
			'ten'        => $ten,
			'loai'       => $loai,
			'trang_thai' => 'Đang làm',
			'ngay_tao'   => VHCP_Util::now_sql(),
			'nguoi_tao'  => (string) $nguoi,
		) );
		return VHCP_Util::ok( array( 'maDA' => $ma, 'ten' => $ten, 'loai' => $loai, 'sheet' => '', 'trangThai' => 'Đang làm', 'url' => '' ) );
	}

	/** ensureCoSoChung(): chi phí cơ sở kỹ thuật = 1 "sheet" CHUNG duy nhất, xuyên suốt. */
	public static function ensure_co_so_chung( $nguoi ) {
		global $wpdb;
		$t = VHCP_DB::t( 'da_index' );
		$r = VHCP_DB::row( $wpdb->prepare( "SELECT * FROM $t WHERE loai=%s ORDER BY stt ASC LIMIT 1", 'Chi phí cơ sở' ) );
		if ( $r ) {
			return VHCP_Util::ok( array(
				'maDA'      => $r['ma_da'],
				'ten'       => $r['ten'],
				'loai'      => 'Chi phí cơ sở',
				'sheet'     => '',
				'trangThai' => ( $r['trang_thai'] !== '' ? $r['trang_thai'] : 'Đang làm' ),
				'url'       => '',
			) );
		}
		$ma  = VHCP_Util::uid( 'DA' );
		$ten = 'Chi phí cơ sở (Kỹ thuật · chung)';
		$wpdb->insert( VHCP_DB::t( 'da_index' ), array(
			'ma_da'      => $ma,
			'ten'        => $ten,
			'loai'       => 'Chi phí cơ sở',
			'trang_thai' => 'Đang làm',
			'ngay_tao'   => VHCP_Util::now_sql(),
			'nguoi_tao'  => (string) $nguoi,
		) );
		return VHCP_Util::ok( array( 'maDA' => $ma, 'ten' => $ten, 'loai' => 'Chi phí cơ sở', 'sheet' => '', 'trangThai' => 'Đang làm', 'url' => '' ) );
	}

	/**
	 * MỌI "ĐƠN" (hạng mục lớn) CỦA MỌI DỰ ÁN, GOM CHO KẾ TOÁN.
	 *
	 * Anh Thắng 10/09/2026: *"Chỗ duyệt tạm ứng và quyết toán của kế toán cũng sẽ hiện 2 bảng
	 * để kế toán phân biệt đơn theo cơ sở (theo tuần), đơn theo dự án (theo thời gian setup
	 * linh động mà nhân viên sẽ nhập vào)"*, và *"kế toán phải biết đơn nào hoàn thành và chưa
	 * hoàn thành để nhắc nhân viên chốt sớm để tránh sót và quên"*.
	 *
	 * 🔴 KHÔNG LỌC BỎ HẠNG MỤC ĐANG "nhap". Kế toán cần thấy CẢ những cái chưa ai đụng tới —
	 *    đó chính là loại bị quên. Lọc sạch cho gọn là giấu đúng thứ họ đi tìm.
	 *
	 * ⚠️ Tôn trọng tầm nhìn đơn vị như `list_du_an()`: dự án neo theo NGƯỜI TẠO.
	 */
	public static function list_don_hm() {
		$out    = array();
		$dv_xem = VHCP_DonVi::xem_duoc();
		foreach ( self::all_with_lines() as $r ) {
			if ( null !== $dv_xem
				&& ! VHCP_DonVi::duoc_xem( VHCP_DonVi::cua_nguoi( isset( $r['nguoi_tao'] ) ? $r['nguoi_tao'] : '' ) ) ) { continue; }
			$ma_da = (string) $r['ma_da'];
			$hm_all = self::get_hm( $ma_da );
			/* Tiền của một "đơn": hạng mục có con thì tiền nằm ở CON, không có con thì ở chính
			   nó. Cộng cả hai là đếm hai lần — và đây là con số kế toán chuẩn bị tiền. */
			$con = array();
			foreach ( $r['lines'] as $x ) {
				$cap = trim( (string) $x['cap_cha'] );
				if ( '' !== $cap && '(Phát sinh)' !== $cap ) {
					$con[ $cap ] = ( isset( $con[ $cap ] ) ? $con[ $cap ] : 0 ) + VHCP_Util::num( $x['thuc_te'] );
				}
			}
			foreach ( $r['lines'] as $x ) {
				if ( ! self::is_real( $x ) ) { continue; }
				if ( trim( (string) $x['cap_cha'] ) !== '' ) { continue; }   // chỉ hạng mục LỚN
				$nd  = trim( (string) $x['noi_dung'] );
				$row = (int) $x['row_no'];
				$k   = (string) $row;
				$h   = isset( $hm_all[ $k ] ) ? self::hm_cua( $ma_da, $row ) : self::hm_cua( $ma_da, $row );
				$out[] = array(
					'maDA'      => $ma_da,
					'tenDA'     => (string) $r['ten'],
					'loaiDA'    => (string) $r['loai'],
					'nguoiTao'  => isset( $r['nguoi_tao'] ) ? (string) $r['nguoi_tao'] : '',
					'row'       => $row,
					'noiDung'   => $nd,
					'gian'      => trim( (string) $x['gian'] ),
					'hinhThuc'  => trim( (string) $x['hinh_thuc'] ),
					'duToan'    => VHCP_Util::num( $x['du_toan'] ),
					'thucTe'    => ( isset( $con[ $nd ] ) && $con[ $nd ] > 0 ) ? $con[ $nd ] : VHCP_Util::num( $x['thuc_te'] ),
					'hm'        => $h,
					'kyDA'      => self::get_ky_da( $ma_da ),
				);
			}
		}
		return VHCP_Util::ok( array( 'items' => $out ) );
	}

	public static function list_du_an() {
		$out = array();
		$sc_tong = VHCP_SoChi::tong_theo_du_an();   // 1 lệnh DB cho mọi dự án
		$dv_xem  = VHCP_DonVi::xem_duoc();
		foreach ( self::all_with_lines() as $r ) {
			/* Dự án neo theo NGƯỜI TẠO — xem chốt dài ở `don_vi_cua()`. */
			if ( null !== $dv_xem
				&& ! VHCP_DonVi::duoc_xem( VHCP_DonVi::cua_nguoi( isset( $r['nguoi_tao'] ) ? $r['nguoi_tao'] : '' ) ) ) { continue; }
			$lines = $r['lines'];
			$dt = 0; $tt = 0; $child = array();
			foreach ( $lines as $x ) {
				$cap = trim( (string) $x['cap_cha'] );
				if ( $cap !== '' && $cap !== '(Phát sinh)' ) { $child[ $cap ] = ( isset( $child[ $cap ] ) ? $child[ $cap ] : 0 ) + VHCP_Util::num( $x['thuc_te'] ); }
			}
			foreach ( $lines as $x ) {
				if ( ! self::is_real( $x ) ) { continue; }
				$nd  = trim( (string) $x['noi_dung'] );
				$cap = trim( (string) $x['cap_cha'] );
				if ( $cap === '' ) {
					$dt += VHCP_Util::num( $x['du_toan'] );
					if ( ! ( isset( $child[ $nd ] ) && $child[ $nd ] > 0 ) ) { $tt += VHCP_Util::num( $x['thuc_te'] ); }
				} else {
					$tt += VHCP_Util::num( $x['thuc_te'] );
				}
			}
			// Cộng thêm phần nằm ở SỔ CHI PHÍ mang mã dự án này (khớp theo mã hoặc theo tên)
			$sc = self::sc_cua( $sc_tong, $r['ma_da'], $r['ten'] );
			$out[] = array(
				'maDA'       => $r['ma_da'],
				'ten'        => $r['ten'],
				'loai'       => $r['loai'],
				'sheet'      => '',
				'trangThai'  => ( $r['trang_thai'] !== '' ? $r['trang_thai'] : 'Đang làm' ),
				'ngayTao'    => VHCP_Util::fmt( $r['ngay_tao'] ),
				'nguoi'      => $r['nguoi_tao'],
				'tongDuToan' => $dt + $sc['duToan'],
				'tongThucTe' => $tt + $sc['tien'],
				'soDongSoChi' => $sc['n'],
				'chenh'      => ( $tt + $sc['tien'] ) - ( $dt + $sc['duToan'] ),
				'url'        => '',
			);
		}
		$coso = array();
		foreach ( VHCP_Cfg::cfg_static()['coso'] as $x ) { $coso[] = $x['ten']; }
		return VHCP_Util::ok( array( 'items' => array_reverse( $out ), 'coso' => $coso ) );
	}

	/** Lấy phần sổ chi phí của 1 dự án trong bảng tổng (khớp theo mã dự án hoặc theo tên). */
	private static function sc_cua( $sc_tong, $ma_da, $ten ) {
		$k0 = array( 'tien' => 0, 'duToan' => 0, 'n' => 0 );
		foreach ( array( $ma_da, $ten ) as $key ) {
			$k = mb_strtolower( trim( (string) $key ) );
			if ( $k !== '' && isset( $sc_tong[ $k ] ) ) { return $sc_tong[ $k ]; }
		}
		return $k0;
	}

	public static function rename_du_an( $ma_da, $ten ) {
		global $wpdb;
		$ten = VHCP_Util::san( $ten );
		if ( $ten === '' ) { return VHCP_Util::err( 'Tên trống' ); }
		$f = self::find( $ma_da );
		if ( ! $f ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		if ( (string) $f['loai'] === 'Chi phí cơ sở' ) { return VHCP_Util::err( 'Sheet Chi phí cơ sở chung không đổi tên' ); }
		$wpdb->update( VHCP_DB::t( 'da_index' ), array( 'ten' => $ten ), array( 'ma_da' => (string) $ma_da ) );
		return VHCP_Util::ok( array( 'ten' => $ten ) );
	}

	// ---------------------------------------------------------------- chi tiết

	public static function get_du_an( $ma_da ) {
		$f = self::find( $ma_da );
		if ( ! $f ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }

		$lines = array();
		foreach ( self::lines_of( $ma_da ) as $r ) {
			if ( ! self::is_real( $r ) ) { continue; }
			$lines[] = array(
				'row'       => (int) $r['row_no'],
				'noiDung'   => (string) $r['noi_dung'],
				'duToan'    => VHCP_Util::num( $r['du_toan'] ),
				'thucTe'    => VHCP_Util::num( $r['thuc_te'] ),
				'soLuong'   => VHCP_Util::num( $r['so_luong'] ),
				'donGia'    => VHCP_Util::num( $r['don_gia'] ),
				'thanhTien' => VHCP_Util::num( $r['thanh_tien'] ),
				'vat'       => (string) $r['vat'],
				'anh'       => (string) $r['anh'],
				'gian'      => (string) $r['gian'],
				'note'      => (string) $r['note'],
				'capCha'    => trim( (string) $r['cap_cha'] ),
				'hinhThuc'  => trim( (string) $r['hinh_thuc'] ),
				'hoSo'      => trim( (string) $r['ho_so'] ),
				'loaiCp'    => (string) $r['loai_cp'],
				'tkNo'      => (string) $r['tk_no'],
				'tkCo'      => (string) $r['tk_co'],
				'maDt'      => (string) $r['ma_dt'],
			);
			/* Trạng thái "đơn" của hạng mục lớn — mục con đi theo cha nên không mang riêng. */
			if ( trim( (string) $r['cap_cha'] ) === '' ) {
				$lines[ count( $lines ) - 1 ]['hm'] = self::hm_cua( $ma_da, (int) $r['row_no'] );
			}
		}

		$child_tt = array(); $parent_ht = array();
		foreach ( $lines as $l ) {
			if ( $l['capCha'] !== '' && $l['capCha'] !== '(Phát sinh)' ) { $child_tt[ $l['capCha'] ] = ( isset( $child_tt[ $l['capCha'] ] ) ? $child_tt[ $l['capCha'] ] : 0 ) + $l['thucTe']; }
			if ( $l['capCha'] === '' ) { $parent_ht[ $l['noiDung'] ] = $l['hinhThuc']; }
		}
		foreach ( $lines as $i => $l ) {
			if ( $l['capCha'] !== '' && $l['capCha'] !== '(Phát sinh)' && isset( $parent_ht[ $l['capCha'] ] ) && $parent_ht[ $l['capCha'] ] !== '' ) {
				$lines[ $i ]['hinhThuc'] = $parent_ht[ $l['capCha'] ];
			}
		}

		$dt = 0; $tt = 0; $du_tu = 0; $du_tt = 0; $tt_tu = 0; $tt_tt = 0; $tt_vat = 0; $tt_novat = 0;
		foreach ( $lines as $l ) {
			$has_child = ( isset( $child_tt[ $l['noiDung'] ] ) && $child_tt[ $l['noiDung'] ] > 0 );
			$is_pay    = ( $l['capCha'] !== '' ) || ( $l['capCha'] === '' && ! $has_child );
			$is_tt     = ( $l['hinhThuc'] === 'Trực tiếp' );
			if ( $l['capCha'] === '' ) {
				$dt += $l['duToan'];
				if ( ! $has_child ) { $tt += $l['thucTe']; }
				if ( $is_tt ) { $du_tt += $l['duToan']; } else { $du_tu += $l['duToan']; }
			} else {
				$tt += $l['thucTe'];
			}
			if ( $is_pay ) {
				if ( $is_tt ) {
					$tt_tt += $l['thucTe'];
					if ( mb_strpos( (string) $l['vat'], 'Có' ) !== false ) { $tt_vat += $l['thucTe']; } else { $tt_novat += $l['thucTe']; }
				} else {
					$tt_tu += $l['thucTe'];
				}
			}
		}

		// Phần nằm ở sổ chi phí: khớp theo MÃ dự án, không có thì khớp theo TÊN
		$sc_lines = VHCP_SoChi::theo_du_an( (string) $ma_da );
		if ( ! count( $sc_lines ) ) { $sc_lines = VHCP_SoChi::theo_du_an( (string) $f['ten'] ); }
		$sc_tien = 0; $sc_du_toan = 0;
		foreach ( $sc_lines as $x ) {
			$sc_tien    += VHCP_Util::num( $x['soTien'] );
			$sc_du_toan += VHCP_Util::num( $x['duToan'] );
		}

		$st  = (string) ( $f['trang_thai'] !== '' ? $f['trang_thai'] : 'Đang làm' );
		$pay = self::get_pay( $ma_da );   // đọc MỘT lần, dùng cho cả 'pay' lẫn 'payTong'
		return VHCP_Util::ok( array(
			'maDA'            => (string) $ma_da,
			'ten'             => $f['ten'],
			'loai'            => $f['loai'],
			'trangThai'       => $st,
			'url'             => '',
			'isCoSo'          => ( $f['loai'] === 'Chi phí cơ sở' ),
			// Dự án chi trực tiếp: chỉ còn 2 trạng thái thật là Đang làm / Đã đóng.
			// Chưa đóng thì nhập được — không còn khoá theo bước duyệt tạm ứng.
			'editable'        => ( $st !== 'Đã đóng' ),
			'pending'         => false,
			'approved'        => ( $st !== 'Đã đóng' ),
			'thiCong'         => ( $st !== 'Đã đóng' ),
			'closed'          => ( $st === 'Đã đóng' ),
			'lines'           => $lines,
			// Dòng chi của dự án nay nằm ở SỔ CHI PHÍ (mang mã dự án). Không cộng vào đây
			// thì gian nào cũng hiện 0đ dù dữ liệu đã nạp xong.
			'soChi'           => $sc_lines,
			'tongSoChi'       => $sc_tien,
			// Tách riêng để màn dự án ghi rõ tổng gồm những gì — đối chiếu hệ cũ mới biết
			// lệch ở bảng hạng mục hay ở sổ chi phí.
			'duToanSoChi'     => $sc_du_toan,
			'tongDuToan'      => $dt + $sc_du_toan,
			'tongThucTe'      => $tt + $sc_tien,
			'chenh'           => ( $tt + $sc_tien ) - ( $dt + $sc_du_toan ),
			/* Con số dự phòng của kế toán + phần đã ứng thật, để màn tính ra "còn dự phòng". */
			'duToanDA'        => self::get_du_toan_da( $ma_da ),
			'kyDA'            => self::get_ky_da( $ma_da ),
			'canTamUng'       => $du_tu,
			'traTrucTiep'     => $du_tt,
			'ttTamUng'        => $tt_tu,
			'ttTrucTiep'      => $tt_tt,
			'ttTrucTiepVAT'   => $tt_vat,
			'ttTrucTiepNoVAT' => $tt_novat,
			'thieuTamUng'     => $tt_tu - $du_tu,
			'thieuTrucTiep'   => $tt_tt - $du_tt,
			'pay'             => $pay,
			/* Tổng ĐÃ CHI theo từng phần — màn và bài kiểm đọc số này chứ không tự cộng lại.
			   Tự cộng ở màn là hai nơi cùng giữ một phép tính, và hai nơi thì lệch. */
			'payTong'         => array(
				'tamUng'    => array( 'tu' => self::pay_tong( $pay, 'tamUng', 'tu' ),
				                      'tt' => self::pay_tong( $pay, 'tamUng', 'tt' ) ),
				'quyetToan' => array( 'tu' => self::pay_tong( $pay, 'quyetToan', 'tu' ),
				                      'tt' => self::pay_tong( $pay, 'quyetToan', 'tt' ) ),
			),
			'noiDungList'     => self::nd_list( $f['loai'] ),
		) );
	}

	// ---------------------------------------------------------------- gợi ý hạng mục con

	private static function nd_list( $loai ) {
		$o = VHCP_Meta::get_json( 'da_ndlist_v1', array() );
		return isset( $o[ $loai ] ) ? $o[ $loai ] : array();
	}

	private static function push_nd( $loai, $nd ) {
		$nd = trim( (string) $nd );
		if ( $nd === '' ) { return; }
		$o = VHCP_Meta::get_json( 'da_ndlist_v1', array() );
		$a = isset( $o[ $loai ] ) ? (array) $o[ $loai ] : array();
		$low = mb_strtolower( $nd );
		foreach ( $a as $x ) { if ( mb_strtolower( (string) $x ) === $low ) { return; } }
		array_unshift( $a, $nd );
		if ( count( $a ) > 300 ) { $a = array_slice( $a, 0, 300 ); }
		$o[ $loai ] = $a;
		VHCP_Meta::set_json( 'da_ndlist_v1', $o );
	}

	// ---------------------------------------------------------------- kế toán chi tiền

	public static function get_pay( $ma_da ) {
		return VHCP_Meta::get_json( 'daPay_' . $ma_da, array() );
	}

	/**
	 * TỔNG DỰ TOÁN CẢ DỰ ÁN — con số kế toán DỰ PHÒNG tiền.
	 *
	 * Anh Thắng 10/09/2026: *"Thêm ô nhập tổng dự toán (nó là con số dự tính tổng dự án để làm
	 * để kế toán biết dự phòng. Chứ nó chưa phải là con tạm ứng, con số tạm ứng là tổng thực tế
	 * sau khi lên đơn. Sau khi kế toán tạm ứng lần 1, sẽ trừ này ra để còn biết thừa thiếu"*.
	 *
	 * 🔴 KHÁC HẲN "tổng dự toán hạng mục". Hạng mục cộng lên là số đã khai chi tiết; con số này
	 *    là ước lượng CẢ dự án, gõ một lần lúc mới mở, thường lớn hơn vì còn phần chưa khai.
	 *    Trộn hai thứ làm một là kế toán dự phòng theo con số chi tiết chưa đủ, rồi thiếu tiền
	 *    đúng lúc đang thi công.
	 *
	 * ⚠️ Cũng KHÔNG phải số tạm ứng. Tạm ứng là tiền THẬT đã chi, ghi ở `confirm_pay()`; con số
	 *    này chỉ để trừ ra mà biết còn dự phòng bao nhiêu.
	 */
	public static function get_du_toan_da( $ma_da ) {
		return VHCP_Util::num( VHCP_Meta::get( 'daDuToan_' . $ma_da, 0 ) );
	}

	/**
	 * THỜI GIAN SETUP — anh Thắng 10/09/2026: *"Bổ sung thêm thời gian setup (Từ ngày đến
	 * ngày)"*, đúng nguyên lý *"Đơn theo thời gian, chứ không theo tuần"* anh nêu từ đầu.
	 *
	 * ⚠️ KHÔNG ÉP PHẢI CÓ. Dự án đang chạy dở chưa ai gõ khoảng ngày; bắt buộc là mọi dự án cũ
	 *    đỏ lên một lỗi mà không ai gây ra.
	 */
	public static function get_ky_da( $ma_da ) {
		$o = VHCP_Meta::get_json( 'daKy_' . $ma_da, array() );
		return array(
			'tu'  => isset( $o['tu'] ) ? (string) $o['tu'] : '',
			'den' => isset( $o['den'] ) ? (string) $o['den'] : '',
		);
	}

	public static function set_ky_da( $ma_da, $tu, $den, $nguoi = '' ) {
		if ( ! self::find( $ma_da ) ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		$tu  = trim( (string) $tu );
		$den = trim( (string) $den );
		/* 🔴 NGÀY KẾT THÚC KHÔNG ĐƯỢC TRƯỚC NGÀY BẮT ĐẦU. Khoảng ngày ngược làm mọi phép "dự án
		   này kéo dài bao lâu" ra số âm, và không có gì trên màn nói vì sao. So bằng chuỗi
		   yyyy-mm-dd là đúng thứ tự thời gian, khỏi phải dựng đối tượng ngày. */
		if ( '' !== $tu && '' !== $den && $den < $tu ) {
			return VHCP_Util::err( 'Ngày kết thúc không được trước ngày bắt đầu.' );
		}
		VHCP_Meta::set_json( 'daKy_' . $ma_da, array( 'tu' => $tu, 'den' => $den ) );
		VHCP_Log::log_action( array(
			'actor'  => (string) ( '' !== $nguoi ? $nguoi : VHCP_Auth::nguoi() ),
			'role'   => VHCP_Auth::vai_tro(),
			'action' => 'Đặt thời gian setup dự án',
			'target' => (string) $ma_da,
			'detail' => $tu . ' → ' . $den,
		) );
		return VHCP_Util::ok( array( 'ky' => array( 'tu' => $tu, 'den' => $den ) ) );
	}

	public static function set_du_toan_da( $ma_da, $so, $nguoi = '' ) {
		if ( ! self::find( $ma_da ) ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		$n = VHCP_Util::num( $so );
		/* 🔴 SỐ ÂM LÀ VÔ NGHĨA, và nó lặng lẽ làm phần "còn dự phòng" phình ra. Chối thẳng. */
		if ( $n < 0 ) { return VHCP_Util::err( 'Tổng dự toán không được âm.' ); }
		VHCP_Meta::set( 'daDuToan_' . $ma_da, $n );
		VHCP_Log::log_action( array(
			'actor'  => (string) ( '' !== $nguoi ? $nguoi : VHCP_Auth::nguoi() ),
			'role'   => VHCP_Auth::vai_tro(),
			'action' => 'Đặt tổng dự toán dự án',
			'target' => (string) $ma_da,
			'detail' => (string) $n,
		) );
		return VHCP_Util::ok( array( 'duToanDA' => $n ) );
	}

	public static function approve_date( $ma_da ) {
		return (string) VHCP_Meta::get( 'daApp_' . $ma_da, '' );
	}

	/* ══════════════════════════════════════════════════════════════════════════════════════
	 * TẠM ỨNG NHIỀU LẦN.
	 *
	 * Anh Thắng 10/09/2026, nói về đơn của bộ phận Kỹ thuật: *"Đơn có tạm ứng nhiều lần"*.
	 *
	 * 🔴 TRƯỚC BẢN NÀY MỖI (giai đoạn × loại) CHỈ GIỮ MỘT BẢN GHI, và lượt ứng thứ hai ĐÈ MẤT
	 *    lượt đầu — không báo gì, không hỏi gì. Số "đã ứng" tụt xuống còn đúng lần cuối, nên
	 *    phần bù/thu ở quyết toán tính trên một con số nhỏ hơn thực tế đã chi. Tiền thật.
	 *
	 * 🔴 DỮ LIỆU CŨ LÀ MỘT ĐỐI TƯỢNG, DỮ LIỆU MỚI LÀ MỘT DANH SÁCH. Mọi chỗ đọc phải đi qua
	 *    `pay_ds()` — nó nhận cả hai dạng. Đọc thẳng `$p[$phase][$loai]['amount']` thì với dự án
	 *    cũ vẫn ra số đúng, còn dự án mới ra `null`: hỏng đúng ở những dự án vừa dùng tính năng
	 *    mới, mà mắt nhìn bảng cũ thì thấy bình thường.
	 * ══════════════════════════════════════════════════════════════════════════════════════ */

	/** Các lần chi của một (giai đoạn × loại), luôn trả về DANH SÁCH — nhận cả dạng cũ. */
	public static function pay_ds( $p, $phase, $loai ) {
		$v = ( isset( $p[ $phase ][ $loai ] ) && is_array( $p[ $phase ][ $loai ] ) ) ? $p[ $phase ][ $loai ] : null;
		if ( ! $v ) { return array(); }
		/* Dạng CŨ: một đối tượng có khoá 'amount'. Dạng MỚI: danh sách các đối tượng ấy. */
		if ( array_key_exists( 'amount', $v ) ) { return array( $v ); }
		$ra = array();
		foreach ( $v as $x ) { if ( is_array( $x ) && array_key_exists( 'amount', $x ) ) { $ra[] = $x; } }
		return $ra;
	}

	/** Tổng đã chi của một (giai đoạn × loại). */
	public static function pay_tong( $p, $phase, $loai ) {
		$t = 0;
		foreach ( self::pay_ds( $p, $phase, $loai ) as $x ) { $t += VHCP_Util::num( isset( $x['amount'] ) ? $x['amount'] : 0 ); }
		return $t;
	}

	public static function confirm_pay( $ma_da, $phase, $loai, $amount, $nguoi, $ghi_chu = '' ) {
		$f = self::find( $ma_da );
		if ( ! $f ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		if ( ! in_array( (string) $phase, array( 'tamUng', 'quyetToan' ), true ) ) { return VHCP_Util::err( 'Giai đoạn không hợp lệ' ); }
		if ( ! in_array( (string) $loai, array( 'tu', 'tt' ), true ) ) { return VHCP_Util::err( 'Loại chi không hợp lệ' ); }
		$st = (string) $f['trang_thai'];
		if ( $st !== 'Đã duyệt' && $st !== 'Đã đóng' ) { return VHCP_Util::err( 'Chỉ chi tiền khi dự án đã kế toán duyệt tạm ứng' ); }
		/* 🔴 SỐ 0 KHÔNG PHẢI MỘT LẦN CHI. Ghi vào là danh sách có một dòng 0đ — nhìn thì như đã
		   chi, cộng vào thì không đổi gì, và người đọc sổ mất một lượt đi tìm xem nó là cái gì. */
		$so = VHCP_Util::num( $amount );
		if ( $so <= 0 ) { return VHCP_Util::err( 'Số tiền phải lớn hơn 0.' ); }

		$p  = self::get_pay( $ma_da );
		$ds = self::pay_ds( $p, $phase, $loai );
		$ds[] = array(
			'done'   => true,
			'amount' => $so,
			'date'   => VHCP_Util::now()->format( 'd/m/Y H:i' ),
			'by'     => (string) $nguoi,
			'ghiChu' => trim( (string) $ghi_chu ),
		);
		if ( ! isset( $p[ $phase ] ) || ! is_array( $p[ $phase ] ) ) { $p[ $phase ] = array(); }
		$p[ $phase ][ $loai ] = $ds;
		VHCP_Meta::set_json( 'daPay_' . $ma_da, $p );
		return VHCP_Util::ok( array( 'pay' => $p ) );
	}

	/**
	 * Bỏ MỘT lần chi. `$idx` là vị trí trong danh sách; để trống thì bỏ lần CUỐI.
	 *
	 * ⚠️ BỎ LẦN CUỐI, KHÔNG PHẢI BỎ SẠCH. Bản trước xoá cả ô — nay ô ấy có thể chứa năm lần
	 *    ứng, nên xoá sạch là mất bốn lần không ai định đụng tới. Hoàn tác là "gỡ cái vừa ghi",
	 *    đúng nghĩa cái nút ↩ trên màn.
	 */
	public static function unconfirm_pay( $ma_da, $phase, $loai, $idx = null ) {
		if ( ! self::find( $ma_da ) ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		$p  = self::get_pay( $ma_da );
		$ds = self::pay_ds( $p, $phase, $loai );
		if ( ! $ds ) { return VHCP_Util::err( 'Chưa có lần chi nào để hoàn tác.' ); }
		$i = ( null === $idx || '' === $idx ) ? ( count( $ds ) - 1 ) : (int) $idx;
		if ( $i < 0 || $i >= count( $ds ) ) { return VHCP_Util::err( 'Không có lần chi thứ ' . ( (int) $idx + 1 ) . '.' ); }
		array_splice( $ds, $i, 1 );
		if ( ! isset( $p[ $phase ] ) || ! is_array( $p[ $phase ] ) ) { $p[ $phase ] = array(); }
		if ( $ds ) { $p[ $phase ][ $loai ] = $ds; }
		else { unset( $p[ $phase ][ $loai ] ); }
		VHCP_Meta::set_json( 'daPay_' . $ma_da, $p );
		return VHCP_Util::ok( array( 'pay' => $p ) );
	}

	// ------------------------------------------------- TRẠNG THÁI TỪNG HẠNG MỤC ("đơn")

	/**
	 * MỖI HẠNG MỤC LỚN LÀ MỘT "ĐƠN" CÓ ĐƯỜNG ĐI RIÊNG.
	 *
	 * Anh Thắng 10/09/2026: *"Nhân viên sẽ lên 10 đơn, xin tạm ứng, quản lý duyệt, kế toán gửi
	 * tạm ứng và gán ủy nhiệm chi lần 1, nếu đơn nào chính xác và hoàn thành sẽ tích hoàn thành
	 * và bổ sung hóa đơn nó sẽ khóa đơn đó lại và xác định đơn đó là chi thực tế"*, và *"Sau nv
	 * lên tiếp 10 đơn, thấy cần nhiều tiền tích vào xin tạm ứng lần 2"*.
	 *
	 * Đường đi:  nhap → xin → duyet → ung(đợt N) → xong(KHOÁ)
	 *                            ↘ tra (trả lại, quay về nhap)
	 *
	 * 🔴 KHOÁ LÀ KHOÁ THẬT. "Xong" nghĩa là đã có hoá đơn và đã chốt là chi thực tế; sửa được
	 *    nữa thì con số kế toán đã hạch toán đổi sau lưng họ. Chỉ Admin/Kế toán mở lại được.
	 *
	 * ⚠️ Lưu qua Meta, KHÔNG đổi sơ đồ CSDL — bảng dòng dự án đang có dữ liệu thật của nhiều
	 *    dự án đang chạy. Khoá là số dòng (`row`), thứ vẫn dùng để sửa/xoá dòng.
	 */
	const TT_HM = array( 'nhap', 'xin', 'duyet', 'ung', 'xong', 'tra' );

	public static function get_hm( $ma_da ) {
		$o = VHCP_Meta::get_json( 'daHM_' . $ma_da, array() );
		return is_array( $o ) ? $o : array();
	}

	/** Trạng thái của MỘT hạng mục. Chưa có gì thì là 'nhap' — dự án cũ vẫn đọc được. */
	public static function hm_cua( $ma_da, $row ) {
		$o = self::get_hm( $ma_da );
		$k = (string) (int) $row;
		$x = isset( $o[ $k ] ) && is_array( $o[ $k ] ) ? $o[ $k ] : array();
		return array(
			'tt'     => isset( $x['tt'] ) && in_array( $x['tt'], self::TT_HM, true ) ? $x['tt'] : 'nhap',
			'dot'    => isset( $x['dot'] ) ? (int) $x['dot'] : 0,
			'unc'    => isset( $x['unc'] ) ? (string) $x['unc'] : '',
			'hoaDon' => isset( $x['hoaDon'] ) ? (string) $x['hoaDon'] : '',
			'moc'    => isset( $x['moc'] ) && is_array( $x['moc'] ) ? $x['moc'] : array(),
			/* Lịch các đợt đi nhận tiền — anh Thắng 10/09/2026: *"kiểu gửi xin tạm ứng nhiều
			   lần, hoặc 1 lần, nếu 1 lần mà đi tạm ứng nhiều lần thì nv có thể lịch chọn ngày
			   đi tạm ứng lần 1,2,3"*. Xin MỘT lần nhưng nhận tiền làm nhiều đợt, mỗi đợt hẹn
			   một ngày; kế toán nhìn lịch mà chuẩn bị tiền cho đúng hôm. */
			'lich'   => isset( $x['lich'] ) && is_array( $x['lich'] ) ? array_values( $x['lich'] ) : array(),
		);
	}

	/** Hạng mục này có đang khoá không (đã chốt là chi thực tế). */
	public static function hm_khoa( $ma_da, $row ) {
		$h = self::hm_cua( $ma_da, $row );
		return 'xong' === $h['tt'];
	}

	private static function hm_ghi_( $ma_da, $row, $sua ) {
		$o = self::get_hm( $ma_da );
		$k = (string) (int) $row;
		$cu = self::hm_cua( $ma_da, $row );
		$moi = array_merge( $cu, $sua );
		/* Mốc thời gian từng bước — kế toán hỏi "cái này nằm đây bao lâu rồi" thì có chỗ tra. */
		$moi['moc'] = $cu['moc'];
		$moi['moc'][ $moi['tt'] ] = VHCP_Util::now()->format( 'd/m/Y H:i' ) . ' · ' . VHCP_Auth::nguoi();
		$o[ $k ] = $moi;
		VHCP_Meta::set_json( 'daHM_' . $ma_da, $o );
		VHCP_Log::log_action( array(
			'actor'  => VHCP_Auth::nguoi(),
			'role'   => VHCP_Auth::vai_tro(),
			'action' => 'Đổi trạng thái hạng mục dự án',
			'target' => (string) $ma_da . '#' . $k,
			'detail' => $cu['tt'] . ' → ' . $moi['tt'] . ( $moi['dot'] ? ( ' · đợt ' . $moi['dot'] ) : '' ),
		) );
		return $moi;
	}

	/**
	 * Đổi trạng thái một hạng mục.
	 *
	 * 🔴 CHỐT THEO VAI, KHÔNG THEO NÚT TRÊN MÀN. Màn ẩn nút là tiện tay; ai gọi thẳng API vẫn
	 *    phải bị chặn — nếu không thì nhân viên tự duyệt và tự cấp tạm ứng cho chính mình.
	 */
	public static function dat_hm( $ma_da, $row, $tt, $them = array() ) {
		if ( ! self::find( $ma_da ) ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		$tt = (string) $tt;
		if ( ! in_array( $tt, self::TT_HM, true ) ) { return VHCP_Util::err( 'Trạng thái không hợp lệ' ); }
		$them = (array) $them;
		$vai  = VHCP_Auth::vai_tro();
		$duyet_duoc = in_array( $vai, array( 'Admin', 'Quản lý', 'Kế toán cá nhân', 'Kế toán NCC' ), true );
		$ke_toan    = in_array( $vai, array( 'Admin', 'Kế toán cá nhân', 'Kế toán NCC' ), true );
		$cu = self::hm_cua( $ma_da, $row );

		/* Đã khoá thì mọi đường đều đóng, trừ lối mở lại của kế toán. */
		if ( 'xong' === $cu['tt'] && 'nhap' !== $tt ) {
			return VHCP_Util::err( 'Hạng mục đã chốt là chi thực tế — không đổi được nữa.' );
		}
		if ( 'xong' === $cu['tt'] && 'nhap' === $tt && ! $ke_toan ) {
			return VHCP_Util::err( 'Chỉ kế toán mở lại được hạng mục đã chốt.' );
		}
		if ( in_array( $tt, array( 'duyet', 'tra' ), true ) && ! $duyet_duoc ) {
			return VHCP_Util::err( 'Chỉ quản lý hoặc kế toán duyệt / trả lại được.' );
		}
		if ( 'ung' === $tt && ! $ke_toan ) {
			return VHCP_Util::err( 'Chỉ kế toán cấp tạm ứng được.' );
		}
		if ( 'xin' === $tt && ! in_array( $cu['tt'], array( 'nhap', 'tra' ), true ) ) {
			return VHCP_Util::err( 'Hạng mục này đã qua bước xin tạm ứng rồi.' );
		}
		if ( 'duyet' === $tt && 'xin' !== $cu['tt'] ) {
			return VHCP_Util::err( 'Chỉ duyệt được hạng mục đang xin tạm ứng.' );
		}
		if ( 'ung' === $tt && 'duyet' !== $cu['tt'] ) {
			return VHCP_Util::err( 'Chỉ cấp tạm ứng cho hạng mục đã duyệt.' );
		}
		/* 🔴 XONG PHẢI CÓ HOÁ ĐƠN. Anh Thắng: *"tích hoàn thành và bổ sung hóa đơn nó sẽ khóa
		   đơn đó lại"*. Khoá mà chưa có chứng từ là chốt một con số không có gì đỡ. */
		$hd = isset( $them['hoaDon'] ) ? trim( (string) $them['hoaDon'] ) : $cu['hoaDon'];
		if ( 'xong' === $tt && '' === $hd ) {
			return VHCP_Util::err( 'Phải đính hoá đơn trước khi chốt hoàn thành.' );
		}

		$sua = array( 'tt' => $tt );
		if ( 'ung' === $tt ) {
			$sua['dot'] = isset( $them['dot'] ) ? max( 1, (int) $them['dot'] ) : ( $cu['dot'] > 0 ? $cu['dot'] : 1 );
			if ( isset( $them['unc'] ) ) { $sua['unc'] = trim( (string) $them['unc'] ); }
		}
		if ( isset( $them['hoaDon'] ) ) { $sua['hoaDon'] = $hd; }
		/* Lịch đợt: chỉ nhận lúc XIN (đó là lúc nhân viên biết mình cần tiền hôm nào). Dòng
		   thiếu ngày thì bỏ — một đợt không ngày thì kế toán chuẩn bị tiền vào hôm nào? */
		if ( 'xin' === $tt && isset( $them['lich'] ) && is_array( $them['lich'] ) ) {
			$ds = array(); $lan = 0;
			foreach ( $them['lich'] as $x ) {
				$x = (array) $x;
				$ngay = isset( $x['ngay'] ) ? trim( (string) $x['ngay'] ) : '';
				if ( '' === $ngay ) { continue; }
				$lan++;
				$ds[] = array(
					'lan'    => $lan,
					'ngay'   => $ngay,
					'soTien' => VHCP_Util::num( isset( $x['soTien'] ) ? $x['soTien'] : 0 ),
				);
			}
			$sua['lich'] = $ds;
		}
		if ( 'nhap' === $tt ) { $sua['dot'] = 0; }
		$moi = self::hm_ghi_( $ma_da, $row, $sua );
		return VHCP_Util::ok( array( 'hm' => $moi ) );
	}

	// ---------------------------------------------------------------- dòng hạng mục

	private static function line_data( $rec ) {
		$rec = (array) $rec;
		$g   = function ( $k ) use ( $rec ) { return isset( $rec[ $k ] ) ? $rec[ $k ] : null; };
		$sl  = VHCP_Util::num( $g( 'soLuong' ) );
		$dg  = VHCP_Util::num( $g( 'donGia' ) );
		$cap = VHCP_Util::st( $g( 'capCha' ) );
		// Gắn mã tài khoản theo LOẠI CHI PHÍ ngay lúc nhập (giống sổ chi phí).
		$loai_cp = VHCP_Util::st( $g( 'loaiCp' ) );
		// Gian hàng đóng vai "cơ sở" ở mảng kỹ thuật -> mã theo mảng kinh doanh của gian đó.
		$tk      = VHCP_Cfg::resolve_tk( $loai_cp, VHCP_Util::st( $g( 'hinhThuc' ) ), array( 'tkNo' => VHCP_Util::st( $g( 'tkNo' ) ), 'tkCo' => VHCP_Util::st( $g( 'tkCo' ) ), 'maDt' => VHCP_Util::st( $g( 'maDt' ) ) ), VHCP_Util::st( $g( 'gian' ) ) );
		return array(
			'loai_cp'    => $loai_cp,
			'tk_no'      => $loai_cp !== '' ? $tk['tk_no'] : '',
			'tk_co'      => $loai_cp !== '' ? $tk['tk_co'] : '',
			'ma_dt'      => $loai_cp !== '' ? $tk['ma_dt'] : '',
			'noi_dung'   => VHCP_Util::st( $g( 'noiDung' ) ),
			'du_toan'    => ( $cap === '' ) ? VHCP_Util::num( $g( 'duToan' ) ) : 0,   // chỉ hạng mục lớn có dự toán
			'thuc_te'    => VHCP_Util::num( $g( 'thucTe' ) ),
			'so_luong'   => $sl,
			'don_gia'    => $dg,
			'thanh_tien' => $sl * $dg,
			'vat'        => VHCP_Util::st( $g( 'vat' ) ),
			'anh'        => VHCP_Util::st( $g( 'anh' ) ),
			'gian'       => VHCP_Util::st( $g( 'gian' ) ),
			'note'       => VHCP_Util::st( $g( 'note' ) ),
			'cap_cha'    => $cap,
			'hinh_thuc'  => VHCP_Util::st( $g( 'hinhThuc' ) ),
			'ho_so'      => VHCP_Util::st( $g( 'hoSo' ) ),
		);
	}

	public static function add_line( $ma_da, $rec ) {
		global $wpdb;
		$f = self::find( $ma_da );
		if ( ! $f ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		// Dự án chi trực tiếp: chỉ ĐÃ ĐÓNG mới khóa. Trước đây còn chặn cả trạng thái
		// "Chờ kế toán duyệt" của luồng duyệt đã bỏ, làm gian cũ không nhận được dữ liệu.
		$st = (string) ( $f['trang_thai'] !== '' ? $f['trang_thai'] : 'Đang làm' );
		if ( $st === 'Đã đóng' ) {
			return VHCP_Util::err( 'Dự án đã đóng — bấm "Mở lại" rồi nhập' );
		}
		$data           = self::line_data( $rec );
		$data['ma_da']  = (string) $ma_da;
		$data['row_no'] = self::next_row( $ma_da );
		$wpdb->insert( VHCP_DB::t( 'da_line' ), $data );
		self::push_nd( $f['loai'], $data['noi_dung'] );
		return VHCP_Util::ok();
	}

	public static function update_line( $ma_da, $row, $rec ) {
		global $wpdb;
		$f = self::find( $ma_da );
		if ( ! $f ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		$st = (string) ( $f['trang_thai'] !== '' ? $f['trang_thai'] : 'Đang làm' );
		if ( $st === 'Đã đóng' ) { return VHCP_Util::err( 'Dự án đã đóng — bấm "Mở lại" rồi sửa' ); }
		$row = (int) $row;
		if ( $row < self::DATA_ROW ) { return VHCP_Util::err( 'Dòng không hợp lệ' ); }
		$t   = VHCP_DB::t( 'da_line' );
		$cur = VHCP_DB::row( $wpdb->prepare( "SELECT * FROM $t WHERE ma_da=%s AND row_no=%d", (string) $ma_da, $row ) );
		if ( ! $cur ) { return VHCP_Util::err( 'Dòng không hợp lệ' ); }
		$old_name = trim( (string) $cur['noi_dung'] );
		$data     = self::line_data( $rec );
		$wpdb->update( $t, $data, array( 'ma_da' => (string) $ma_da, 'row_no' => $row ) );
		if ( $data['cap_cha'] === '' && $old_name !== '' && $old_name !== $data['noi_dung'] ) {
			self::relink_children( $ma_da, $old_name, $data['noi_dung'] );   // hạng mục lớn đổi tên -> cập nhật mục con
		}
		self::push_nd( $f['loai'], $data['noi_dung'] );
		return VHCP_Util::ok();
	}

	public static function delete_line( $ma_da, $row ) {
		global $wpdb;
		$f = self::find( $ma_da );
		if ( ! $f ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		$st = (string) ( $f['trang_thai'] !== '' ? $f['trang_thai'] : 'Đang làm' );
		if ( $st === 'Đã đóng' ) { return VHCP_Util::err( 'Dự án đã đóng — bấm "Mở lại" rồi xóa' ); }
		$row = (int) $row;
		if ( $row < self::DATA_ROW ) { return VHCP_Util::err( 'Dòng không hợp lệ' ); }
		$t   = VHCP_DB::t( 'da_line' );
		$cur = VHCP_DB::row( $wpdb->prepare( "SELECT * FROM $t WHERE ma_da=%s AND row_no=%d", (string) $ma_da, $row ) );
		if ( ! $cur ) { return VHCP_Util::err( 'Dòng không hợp lệ' ); }
		$nm  = trim( (string) $cur['noi_dung'] );
		$cap = trim( (string) $cur['cap_cha'] );
		if ( $cap === '' && $nm !== '' ) { self::relink_children( $ma_da, $nm, '(Phát sinh)' ); }   // xóa hạng mục lớn -> mục con thành phát sinh
		$wpdb->delete( $t, array( 'ma_da' => (string) $ma_da, 'row_no' => $row ) );
		return VHCP_Util::ok();
	}

	private static function relink_children( $ma_da, $old, $new ) {
		global $wpdb;
		$t = VHCP_DB::t( 'da_line' );
		$wpdb->query( $wpdb->prepare( "UPDATE $t SET cap_cha=%s WHERE ma_da=%s AND TRIM(cap_cha)=%s", (string) $new, (string) $ma_da, (string) $old ) );
	}

	// ---------------------------------------------------------------- quy trình

	private static function set_status( $ma_da, $status ) {
		global $wpdb;
		$wpdb->update( VHCP_DB::t( 'da_index' ), array( 'trang_thai' => (string) $status ), array( 'ma_da' => (string) $ma_da ) );
	}

	public static function submit( $ma_da ) {
		$f = self::find( $ma_da );
		if ( ! $f ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		if ( (string) $f['loai'] === 'Chi phí cơ sở' ) { return VHCP_Util::err( 'Chi phí cơ sở chung không cần duyệt' ); }
		if ( (string) ( $f['trang_thai'] !== '' ? $f['trang_thai'] : 'Đang làm' ) !== 'Đang làm' ) { return VHCP_Util::err( 'Chỉ gửi khi đang làm' ); }
		self::set_status( $ma_da, 'Chờ kế toán duyệt' );
		return VHCP_Util::ok();
	}

	public static function approve( $ma_da, $nguoi ) {
		$f = self::find( $ma_da );
		if ( ! $f ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		if ( (string) $f['trang_thai'] !== 'Chờ kế toán duyệt' ) { return VHCP_Util::err( 'Dự án không ở trạng thái chờ duyệt' ); }
		self::set_status( $ma_da, 'Đã duyệt' );
		VHCP_Meta::set( 'daApp_' . $ma_da, VHCP_Util::now()->format( 'd/m/Y' ) );   // ngày chứng từ khi xuất MISA
		return VHCP_Util::ok();
	}

	public static function ret( $ma_da ) {
		$f = self::find( $ma_da );
		if ( ! $f ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		if ( (string) $f['trang_thai'] !== 'Chờ kế toán duyệt' ) { return VHCP_Util::err( 'Chỉ trả khi đang chờ duyệt' ); }
		self::set_status( $ma_da, 'Đang làm' );
		return VHCP_Util::ok();
	}

	/**
	 * Đóng dự án. Dự án CHI TRỰC TIẾP — không có bước xin/duyệt tạm ứng như đơn tuần,
	 * nên đang làm là đóng được luôn, không đòi phải "Đã duyệt" trước.
	 */
	public static function close( $ma_da ) {
		$f = self::find( $ma_da );
		if ( ! $f ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		if ( (string) $f['loai'] === 'Chi phí cơ sở' ) { return VHCP_Util::err( 'Chi phí cơ sở chung không đóng' ); }
		if ( (string) $f['trang_thai'] === 'Đã đóng' ) { return VHCP_Util::err( 'Dự án đã đóng' ); }
		self::set_status( $ma_da, 'Đã đóng' );
		return VHCP_Util::ok();
	}

	public static function reopen( $ma_da ) {
		if ( ! self::find( $ma_da ) ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		self::set_status( $ma_da, 'Đang làm' );
		return VHCP_Util::ok();
	}

	public static function delete( $ma_da ) {
		global $wpdb;
		$f = self::find( $ma_da );
		if ( ! $f ) { return VHCP_Util::err( 'Không tìm thấy dự án' ); }
		if ( (string) $f['loai'] === 'Chi phí cơ sở' ) { return VHCP_Util::err( 'Không xóa sheet Chi phí cơ sở chung' ); }
		if ( (string) $f['trang_thai'] === 'Đã đóng' ) { return VHCP_Util::err( 'Dự án đã đóng — Admin "Mở lại" trước khi xóa' ); }
		$wpdb->delete( VHCP_DB::t( 'da_line' ), array( 'ma_da' => (string) $ma_da ) );
		$wpdb->delete( VHCP_DB::t( 'da_index' ), array( 'ma_da' => (string) $ma_da ) );
		VHCP_Meta::del( 'daPay_' . $ma_da );
		VHCP_Meta::del( 'daApp_' . $ma_da );
		return VHCP_Util::ok();
	}

	/** Loại dự án -> loại chi phí tương ứng trong danh mục (tên trùng khớp, không phải đoán). */
	public static function loai_cp_mac_dinh( $loai_du_an ) {
		$map = array(
			'Tháo dỡ'       => 'Chi phí tháo dỡ',
			'Setup lắp đặt' => 'Chi phí setup lắp đặt gian hàng mới',
			'Chi phí cơ sở' => 'Chi phí cơ sở',
		);
		$k = trim( (string) $loai_du_an );
		return isset( $map[ $k ] ) ? $map[ $k ] : '';
	}

	/**
	 * Gán loại chi phí + mã tài khoản cho dòng hạng mục CŨ.
	 * Dòng chưa có loại -> lấy theo loại dự án (Tháo dỡ / Setup lắp đặt / Chi phí cơ sở).
	 */
	public static function gan_ma_tai_khoan( $all = false ) {
		global $wpdb;
		$t = VHCP_DB::t( 'da_line' );
		$n = 0; $thieu = array(); $khong_suy = 0;
		foreach ( self::all_with_lines() as $p ) {
			$mac_dinh  = self::loai_cp_mac_dinh( $p['loai'] );
			$parent_ht = array();
			foreach ( $p['lines'] as $x ) {
				if ( trim( (string) $x['cap_cha'] ) === '' ) { $parent_ht[ trim( (string) $x['noi_dung'] ) ] = trim( (string) $x['hinh_thuc'] ); }
			}
			foreach ( $p['lines'] as $x ) {
				$cu   = trim( (string) $x['loai_cp'] );
				$loai = ( $cu !== '' ) ? $cu : $mac_dinh;
				if ( $loai === '' ) { $khong_suy++; continue; }
				if ( ! $all && $cu !== '' && trim( (string) $x['tk_no'] ) !== '' ) { continue; }
				$cap = trim( (string) $x['cap_cha'] );
				$ht  = ( $cap !== '' && $cap !== '(Phát sinh)' && ! empty( $parent_ht[ $cap ] ) ) ? $parent_ht[ $cap ] : trim( (string) $x['hinh_thuc'] );
				$gian_x = trim( (string) $x['gian'] );
				$giu    = VHCP_Cfg::ma_con_hop_le( $loai, $gian_x, $x['tk_no'] );
				$tk  = VHCP_Cfg::resolve_tk( $loai, $ht, array( 'tkNo' => $giu ), $gian_x );
				if ( $tk['tk_no'] === '' ) { $thieu[ $loai ] = 1; }
				if ( $loai === $cu && $tk['tk_no'] === trim( (string) $x['tk_no'] ) && $tk['tk_co'] === trim( (string) $x['tk_co'] ) ) { continue; }
				$wpdb->update( $t, array( 'loai_cp' => $loai, 'tk_no' => $tk['tk_no'], 'tk_co' => $tk['tk_co'], 'ma_dt' => $tk['ma_dt'] ), array( 'id' => (int) $x['id'] ) );
				$n++;
			}
		}
		return VHCP_Util::ok( array( 'updated' => $n, 'thieuMa' => array_keys( $thieu ), 'khongSuyDuoc' => $khong_suy ) );
	}

	/**
	 * Dùng chung cho báo cáo: mọi dự án kèm dòng hạng mục — ĐÚNG 2 LỆNH DB
	 * (1 lệnh danh mục + 1 lệnh toàn bộ dòng, rồi gom trong PHP).
	 * Trước đây mỗi dự án 1 lệnh nên 30 dự án là 31 lệnh.
	 */
	public static function all_with_lines() {
		$ti = VHCP_DB::t( 'da_index' );
		$tl = VHCP_DB::t( 'da_line' );
		$rows = VHCP_DB::rows( "SELECT * FROM $ti ORDER BY stt ASC" );
		$by   = array();
		foreach ( VHCP_DB::rows( "SELECT * FROM $tl ORDER BY ma_da ASC, row_no ASC" ) as $l ) {
			$by[ (string) $l['ma_da'] ][] = $l;
		}
		foreach ( $rows as $i => $r ) {
			$k = (string) $r['ma_da'];
			$rows[ $i ]['lines'] = isset( $by[ $k ] ) ? $by[ $k ] : array();
		}
		return $rows;
	}

	/** Toàn bộ ghi nhận chi tiền của mọi dự án — 1 lệnh DB. */
	public static function pay_map() {
		$out = array();
		foreach ( VHCP_Meta::get_prefix( 'daPay_' ) as $k => $v ) {
			$o = json_decode( (string) $v, true );
			$out[ substr( $k, 7 ) ] = is_array( $o ) ? $o : array();
		}
		return $out;
	}

	/** Ngày kế toán duyệt của mọi dự án — 1 lệnh DB. */
	public static function approve_date_map() {
		$out = array();
		foreach ( VHCP_Meta::get_prefix( 'daApp_' ) as $k => $v ) {
			$out[ substr( $k, 7 ) ] = (string) $v;
		}
		return $out;
	}
}
